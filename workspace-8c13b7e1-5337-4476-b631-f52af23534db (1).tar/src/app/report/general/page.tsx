'use client'
// General Report — halaman laporan siap-cetak (PDF via print browser)
import { Suspense, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { Loader2, Printer, ArrowLeft, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { api, PROJECT_STATUS } from '@/lib/client'
import { DEFAULT_SECTIONS, PERIOD_LABEL, periodRange, fmtIDN, type ReportPeriod, type PeriodRange } from '@/lib/report'
import type {
  Project, Employee, Attendance, WorkTask, WbsTask, QuantityItem, FabricationItem,
  EquipmentDelivery, DailyReport, WeeklyReport, ProjectDocument, KpiRecord, AiSummary,
  DrawingZone, DrawingFileMeta, DashboardData, SessionInfo,
} from '@/lib/types'
import type { ReportData } from '@/components/asei/report/shared'
import { RingkasanSection, AbsensiSection, TenagaKerjaSection, WorkTaskSection } from '@/components/asei/report/sections-a'
import { TimelineSection, GanttSection, ProgressFisikSection, LaporanHarianSection, LaporanMingguanSection, KpiSection, DokumenSection, GambarZonaSection, AiSummarySection } from '@/components/asei/report/sections-b'

const RESOURCES = ['employees', 'attendance', 'tasks', 'wbs', 'quantities', 'fabrications', 'equipment', 'daily-reports', 'weekly-reports', 'documents', 'kpi', 'summaries', 'zones'] as const

function GeneralReportContent() {
  const sp = useSearchParams()
  const projectId = sp.get('projectId') ?? ''
  const period = (['full', 'daily', 'weekly', 'monthly'].includes(sp.get('period') ?? '') ? sp.get('period') : 'full') as ReportPeriod
  const dateParam = sp.get('date')
  const secsParam = (sp.get('secs') ?? '').split(',').filter(k => DEFAULT_SECTIONS.includes(k))
  const secs = secsParam.length ? secsParam : DEFAULT_SECTIONS
  const customTitle = (sp.get('title') ?? '').trim()
  const autoPrint = sp.get('print') === '1'

  const [data, setData] = useState<ReportData | null>(null)
  const [error, setError] = useState('')
  const [authRequired, setAuthRequired] = useState(false)
  const printed = useRef(false)

  const range: PeriodRange | null = periodRange(period, dateParam)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const me = await api<{ data: SessionInfo }>('/api/auth/me').catch(() => { throw new Error('AUTH') })
        if (!projectId) throw new Error('Proyek tidak ditemukan — buka laporan dari menu Unduh di aplikasi.')
        const [projects, dash, drawings, ...rest] = await Promise.all([
          api<{ data: Project[] }>('/api/projects'),
          api<{ data: DashboardData | null }>(`/api/dashboard?projectId=${projectId}`).catch(() => ({ data: null })),
          api<{ data: DrawingFileMeta[] }>(`/api/drawings?projectId=${projectId}`).catch(() => ({ data: [] as DrawingFileMeta[] })),
          ...RESOURCES.map(r => api<{ data: unknown }>(`/api/data/${r}?projectId=${projectId}`)),
        ])
        if (cancelled) return
        const resourceMap: Record<string, unknown> = {}
        RESOURCES.forEach((r, i) => { resourceMap[r] = rest[i].data ?? [] })
        const project = projects.data.find(p => p.id === projectId) ?? projects.data.find(p => p.isDefault) ?? projects.data[0] ?? null
        setData({
          project,
          dash: dash.data,
          drawings: drawings.data ?? [],
          employees: resourceMap.employees as Employee[],
          attendance: resourceMap.attendance as Attendance[],
          tasks: resourceMap.tasks as WorkTask[],
          wbs: resourceMap.wbs as WbsTask[],
          quantities: resourceMap.quantities as QuantityItem[],
          fabrications: resourceMap.fabrications as FabricationItem[],
          equipment: resourceMap.equipment as EquipmentDelivery[],
          dailyReports: resourceMap['daily-reports'] as DailyReport[],
          weeklyReports: resourceMap['weekly-reports'] as WeeklyReport[],
          documents: resourceMap.documents as ProjectDocument[],
          kpi: resourceMap.kpi as KpiRecord[],
          summaries: resourceMap.summaries as AiSummary[],
          zones: resourceMap.zones as DrawingZone[],
          user: me.data,
        })
      } catch (e) {
        if (cancelled) return
        if (e instanceof Error && e.message === 'AUTH') setAuthRequired(true)
        else setError(e instanceof Error ? e.message : String(e))
      }
    })()
    return () => { cancelled = true }
  }, [projectId])

  useEffect(() => {
    if (!data || !autoPrint || printed.current) return
    printed.current = true
    const t = setTimeout(() => { try { window.print() } catch { /* abaikan */ } }, 1600)
    return () => clearTimeout(t)
  }, [data, autoPrint])

  if (authRequired) {
    return (
      <div className="min-h-screen bg-slate-200 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-sm text-center">
          <FileText className="h-10 w-10 mx-auto text-amber-500 mb-3" />
          <h1 className="font-bold text-slate-900 mb-1">Login Diperlukan</h1>
          <p className="text-sm text-slate-500 mb-4">Sesi Anda berakhir. Silakan login kembali untuk membuat General Report.</p>
          <Button onClick={() => { window.location.href = '/' }} className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white">Menuju Halaman Login</Button>
        </div>
      </div>
    )
  }
  if (error) {
    return (
      <div className="min-h-screen bg-slate-200 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-sm text-center">
          <p className="text-red-600 font-semibold mb-1">Gagal memuat laporan</p>
          <p className="text-sm text-slate-500">{error}</p>
        </div>
      </div>
    )
  }
  if (!data) {
    return (
      <div className="min-h-screen bg-slate-200 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-500">
          <Loader2 className="h-9 w-9 animate-spin text-amber-500" />
          <p className="text-sm">Menyusun laporan…</p>
        </div>
      </div>
    )
  }

  const project = data.project
  const appName = (project?.brandAppName ?? '').trim() || 'ASEI HR'
  const logoSrc = (project?.brandLogo ?? '').trim() || '/logo-asei.png'
  const reportTitle = customTitle || PERIOD_LABEL[period]

  document.title = `${reportTitle} — ${project?.name ?? 'Proyek'}`

  const meta: [string, string][] = [
    ['Nama Proyek', project?.name ?? '—'],
    ['Kode Proyek', project?.code || '—'],
    ['Klien', project?.client || '—'],
    ['Lokasi', project?.location || '—'],
    ['Status Proyek', PROJECT_STATUS[project?.status ?? ''] ?? project?.status ?? '—'],
    ['Jenis Laporan', PERIOD_LABEL[period]],
    ['Periode Data', range ? `${fmtIDN(range.start)} s.d. ${fmtIDN(range.end)}` : 'Seluruh periode proyek'],
    ['Rentang Jadwal', project?.startDate ? `${fmtIDN(new Date(project.startDate))} — ${project?.endDate ? fmtIDN(new Date(project.endDate)) : '…'}` : '—'],
  ]

  const RENDERERS: Record<string, (p: { data: ReportData; range: PeriodRange | null; no: number }) => React.ReactNode> = {
    ringkasan: RingkasanSection, absensi: AbsensiSection, 'tenaga-kerja': TenagaKerjaSection,
    timeline: TimelineSection, gantt: GanttSection, 'work-task': WorkTaskSection,
    'progress-fisik': ProgressFisikSection, 'laporan-harian': LaporanHarianSection,
    'laporan-mingguan': LaporanMingguanSection, kpi: KpiSection, dokumen: DokumenSection,
    'gambar-zona': GambarZonaSection, 'ai-summary': AiSummarySection,
  }
  const included = secs.filter(k => RENDERERS[k])

  return (
    <div className="min-h-screen bg-slate-200 py-5 print:py-0">
      <style dangerouslySetInnerHTML={{ __html: PRINT_CSS }} />
      {/* Toolbar layar */}
      <div className="no-print max-w-[794px] mx-auto mb-4 flex items-center justify-between gap-3 rounded-xl bg-white shadow px-4 py-3">
        <div className="flex items-center gap-2 min-w-0">
          <FileText className="h-4 w-4 text-amber-600 shrink-0" />
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-800 truncate">{reportTitle}</p>
            <p className="text-[10px] text-slate-400">{included.length} seksi dilampirkan • gunakan &quot;Simpan sebagai PDF&quot; pada dialog cetak</p>
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={() => { window.location.href = '/' }} className="gap-1.5"><ArrowLeft className="h-4 w-4" /> Kembali</Button>
          <Button size="sm" onClick={() => window.print()} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Printer className="h-4 w-4" /> Cetak / PDF</Button>
        </div>
      </div>

      {/* Kertas A4 */}
      <div className="report-page relative mx-auto w-[794px] bg-white shadow-xl print:shadow-none" style={{ padding: '0 0 28px' }}>
        {/* Kop laporan */}
        <div className="text-white px-10 pt-8 pb-6" style={{ background: 'linear-gradient(120deg,#b45309 0%,#ea580c 55%,#d97706 100%)' }}>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-white p-1.5 shadow-md flex items-center justify-center">
                <img src={logoSrc} alt="Logo" className="h-11 w-11 object-contain" />
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] opacity-90">{appName} Project Management</p>
                <h1 className="text-2xl font-extrabold tracking-tight leading-tight">GENERAL REPORT</h1>
                <p className="text-[11px] opacity-95">{reportTitle}</p>
              </div>
            </div>
            <div className="text-right text-[10px] leading-relaxed opacity-95">
              <p className="font-bold text-[11px]">{project?.name ?? '—'}</p>
              <p>{project?.code ? `Kode: ${project.code}` : ''}</p>
              <p>Dibuat: {fmtIDN(new Date())} {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</p>
              <p>Oleh: {data.user?.name || data.user?.username || '—'}</p>
            </div>
          </div>
        </div>

        {/* Info proyek */}
        <div className="px-10 pt-5">
          <div className="grid grid-cols-4 rounded-xl border border-slate-200 overflow-hidden" style={{ breakInside: 'avoid' }}>
            {meta.map(([k, v], i) => (
              <div key={k} className={`px-3 py-2 ${i % 2 === 0 ? 'border-r border-slate-200' : ''} ${i < 6 ? 'border-b border-slate-200' : ''} bg-white`}>
                <p className="text-[8.5px] font-bold uppercase tracking-wider text-slate-400">{k}</p>
                <p className="text-[10.5px] font-semibold text-slate-800 truncate" title={v}>{v}</p>
              </div>
            ))}
            <div className="px-3 py-2 bg-amber-50 col-span-2">
              <p className="text-[8.5px] font-bold uppercase tracking-wider text-amber-600">Seksi Dilampirkan</p>
              <p className="text-[9.5px] font-semibold text-amber-900">{included.length} dari 13 seksi • dipilih saat pembuatan laporan</p>
            </div>
          </div>
        </div>

        {/* Isi seksi */}
        <div className="px-10 pt-6 space-y-7">
          {included.map((k, i) => {
            const Renderer = RENDERERS[k]
            return <div key={k}>{Renderer({ data, range, no: i + 1 })}</div>
          })}
        </div>

        {/* Footer */}
        <div className="px-10 mt-8 pt-3 border-t border-slate-200 flex items-center justify-between text-[8.5px] text-slate-400">
          <span>{appName} Project Management — {project?.name ?? '—'} • Dihasilkan otomatis oleh sistem</span>
          <span>{fmtIDN(new Date())} • General Report</span>
        </div>
      </div>
    </div>
  )
}

const PRINT_CSS = `
@page { size: A4 portrait; margin: 0; }
@media print {
  html, body { background: #fff !important; }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
  .no-print { display: none !important; }
  .report-page { box-shadow: none !important; margin: 0 !important; }
  .rpt-section { break-inside: auto; }
  .rpt-card { break-inside: avoid; }
  thead { display: table-header-group; }
  tr { break-inside: avoid; }
}
`

export default function GeneralReportPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-200 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-amber-500" /></div>}>
      <GeneralReportContent />
    </Suspense>
  )
}
