'use client'
// Error boundary GLOBAL — menangkap exception di root layout/hydration.
// Wajib menyertakan <html><body> sendiri karena menggantikan seluruh dokumen.
import { useEffect } from 'react'
import { AlertTriangle, RotateCcw } from 'lucide-react'

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('[ASEI] Global client error:', error)
  }, [error])

  return (
    <html lang="id">
      <body style={{ margin: 0, fontFamily: 'system-ui, -apple-system, sans-serif' }}>
        <div style={{ minHeight: '100vh', background: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ background: '#fff', borderRadius: 16, boxShadow: '0 10px 40px rgba(0,0,0,.08)', padding: 32, maxWidth: 440, textAlign: 'center' }}>
            <div style={{ width: 56, height: 56, borderRadius: 16, background: '#fffbeb', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                <path d="M12 9v4M12 17h.01" />
              </svg>
            </div>
            <h1 style={{ fontSize: 18, fontWeight: 700, color: '#0f172a', margin: '0 0 6px' }}>Terjadi Kesalahan Tak Terduga</h1>
            <p style={{ fontSize: 14, color: '#64748b', margin: '0 0 4px' }}>
              Aplikasi gagal dimuat dengan benar. Data proyek Anda <b>aman</b> di server.
            </p>
            <p style={{ fontSize: 12, color: '#94a3b8', margin: '0 0 20px', wordBreak: 'break-word' }}>{error?.message || 'Kesalahan tidak diketahui'}</p>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
              <button
                onClick={reset}
                style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: 'linear-gradient(90deg,#f59e0b,#ea580c)', color: '#fff', fontWeight: 600, fontSize: 14, cursor: 'pointer' }}
              >
                Coba Lagi
              </button>
              <button
                onClick={() => window.location.reload()}
                style={{ padding: '8px 16px', borderRadius: 8, border: '1px solid #cbd5e1', background: '#fff', color: '#334155', fontWeight: 600, fontSize: 14, cursor: 'pointer' }}
              >
                Muat Ulang Aplikasi
              </button>
            </div>
          </div>
        </div>
      </body>
    </html>
  )
}
