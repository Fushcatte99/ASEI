import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

// Serve raw file untuk <img src> / render pdf.js / download CAD
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { id } = await ctx.params
    const row = await db.drawingFile.findUnique({ where: { id }, select: { fileData: true, mimeType: true, fileName: true, fileType: true } })
    if (!row) return NextResponse.json({ error: 'Gambar tidak ditemukan' }, { status: 404 })
    const buf = Buffer.from(row.fileData, 'base64')
    const dispo = row.fileType === 'CAD' ? 'attachment' : 'inline'
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': row.mimeType || 'application/octet-stream',
        'Content-Disposition': `${dispo}; filename="${encodeURIComponent(row.fileName)}"`,
        'Content-Length': String(buf.length),
        'Cache-Control': 'no-store',
      },
    })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
