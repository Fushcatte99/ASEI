import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

// PATCH: edit meta gambar (judul, no gambar, disiplin, catatan)
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { id } = await ctx.params
    const body = await req.json()
    const data: Record<string, unknown> = {}
    for (const k of ['title', 'drawingNo', 'discipline', 'notes']) {
      if (k in body) data[k] = String(body[k] ?? '')
    }
    if ('title' in data && !data.title) return NextResponse.json({ error: 'Judul tidak boleh kosong' }, { status: 400 })
    const row = await db.drawingFile.update({
      where: { id },
      data,
      select: {
        id: true, projectId: true, title: true, drawingNo: true, discipline: true,
        fileType: true, fileName: true, mimeType: true, sizeKb: true, notes: true,
        createdAt: true, updatedAt: true,
      },
    })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

// DELETE: hapus gambar + semua marking-nya
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { id } = await ctx.params
    await db.drawingMark.deleteMany({ where: { drawingId: id } })
    await db.drawingFile.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
