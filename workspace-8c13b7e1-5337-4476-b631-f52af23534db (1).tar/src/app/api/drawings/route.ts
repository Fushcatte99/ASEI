import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

const ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/webp', 'application/pdf']
const MAX_BASE64 = 14 * 1024 * 1024 // ~14MB base64 (~10.5MB file)

function detectType(fileName: string, mime: string): { fileType: string; mimeType: string } {
  const lower = fileName.toLowerCase()
  if (lower.endsWith('.dxf') || lower.endsWith('.dwg')) return { fileType: 'CAD', mimeType: 'application/acad' }
  if (mime === 'application/pdf' || lower.endsWith('.pdf')) return { fileType: 'PDF', mimeType: 'application/pdf' }
  if (ALLOWED_MIME.includes(mime)) return { fileType: 'IMAGE', mimeType: mime }
  if (lower.endsWith('.png')) return { fileType: 'IMAGE', mimeType: 'image/png' }
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return { fileType: 'IMAGE', mimeType: 'image/jpeg' }
  if (lower.endsWith('.webp')) return { fileType: 'IMAGE', mimeType: 'image/webp' }
  return { fileType: 'CAD', mimeType: mime || 'application/octet-stream' }
}

// GET: daftar meta gambar (tanpa fileData agar ringan)
export async function GET(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const projectId = req.nextUrl.searchParams.get('projectId') ?? ''
    const rows = await db.drawingFile.findMany({
      where: projectId ? { projectId } : undefined,
      select: {
        id: true, projectId: true, title: true, drawingNo: true, discipline: true,
        fileType: true, fileName: true, mimeType: true, sizeKb: true, notes: true,
        createdAt: true, updatedAt: true,
      },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({ data: rows })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

// POST: upload file (dataUrl base64)
export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const body = await req.json()
    const projectId = String(body.projectId ?? '')
    const dataUrl = String(body.dataUrl ?? '')
    const fileName = String(body.fileName ?? 'file').slice(0, 200)
    if (!projectId) return NextResponse.json({ error: 'projectId wajib' }, { status: 400 })
    if (!dataUrl.includes(',')) return NextResponse.json({ error: 'Format file tidak valid' }, { status: 400 })
    if (dataUrl.length > MAX_BASE64) return NextResponse.json({ error: 'Ukuran file maksimal 10 MB' }, { status: 400 })

    const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1)
    const mimePart = dataUrl.slice(0, dataUrl.indexOf(','))
    const mimeFromUrl = mimePart.includes(':') ? mimePart.slice(mimePart.indexOf(':') + 1, mimePart.indexOf(';')) : ''
    const { fileType, mimeType } = detectType(fileName, mimeFromUrl || String(body.mimeType ?? ''))
    const sizeKb = Math.round((base64.length * 3) / 4 / 1024)

    const title = String(body.title ?? '').trim() || fileName.replace(/\.[^.]+$/, '')
    const row = await db.drawingFile.create({
      data: {
        projectId,
        title,
        drawingNo: String(body.drawingNo ?? ''),
        discipline: String(body.discipline ?? 'GENERAL'),
        fileType, fileName, mimeType,
        fileData: base64,
        sizeKb,
        notes: String(body.notes ?? ''),
      },
      select: {
        id: true, projectId: true, title: true, drawingNo: true, discipline: true,
        fileType: true, fileName: true, mimeType: true, sizeKb: true, notes: true,
        createdAt: true, updatedAt: true,
      },
    })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
