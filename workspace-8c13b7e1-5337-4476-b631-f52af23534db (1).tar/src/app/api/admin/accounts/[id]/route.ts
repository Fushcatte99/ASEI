import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden, isAdmin, hashPassword } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  if (!isAdmin(session)) return forbidden()
  try {
    const { id } = await ctx.params
    const body = await req.json()
    const account = await db.userAccount.findUnique({ where: { id } })
    if (!account) return NextResponse.json({ error: 'Akun tidak ditemukan' }, { status: 404 })

    const data: Record<string, unknown> = {}
    if ('username' in body) {
      const username = String(body.username ?? '').trim().toLowerCase()
      if (username.length < 3) return NextResponse.json({ error: 'Username minimal 3 karakter' }, { status: 400 })
      if (!/^[a-z0-9._-]+$/.test(username)) return NextResponse.json({ error: 'Username hanya boleh huruf kecil, angka, titik, garis bawah, dan strip' }, { status: 400 })
      const dup = await db.userAccount.findUnique({ where: { username } })
      if (dup && dup.id !== id) return NextResponse.json({ error: `Username "${username}" sudah dipakai` }, { status: 409 })
      data.username = username
    }
    if ('name' in body) data.name = String(body.name ?? '').trim()
    if ('role' in body) {
      const role = body.role === 'MASTER_ADMIN' ? 'MASTER_ADMIN' : 'STAFF'
      // Cegah master admin menurunkan role dirinya sendiri (hindari terkunci)
      if (id === session.uid && role !== 'MASTER_ADMIN') {
        return NextResponse.json({ error: 'Tidak dapat mengubah role akun sendiri' }, { status: 400 })
      }
      data.role = role
    }
    if ('isActive' in body) {
      if (id === session.uid && body.isActive === false) {
        return NextResponse.json({ error: 'Tidak dapat menonaktifkan akun sendiri' }, { status: 400 })
      }
      data.isActive = !!body.isActive
    }
    if ('employeeId' in body) {
      const employeeId = String(body.employeeId ?? '').trim()
      if (employeeId) {
        if (!(await db.employee.findUnique({ where: { id: employeeId } }))) {
          return NextResponse.json({ error: 'Pekerja tidak ditemukan' }, { status: 400 })
        }
        const dup = await db.userAccount.findFirst({ where: { employeeId, id: { not: id } } })
        if (dup) return NextResponse.json({ error: 'Pekerja ini sudah memiliki akun' }, { status: 409 })
      }
      data.employeeId = employeeId
    }
    if ('password' in body) {
      const password = String(body.password ?? '')
      if (password) {
        if (password.length < 6) return NextResponse.json({ error: 'Password minimal 6 karakter' }, { status: 400 })
        data.passwordHash = hashPassword(password)
      }
    }
    const row = await db.userAccount.update({ where: { id }, data })
    return NextResponse.json({ data: { id: row.id, username: row.username, name: row.name, role: row.role, employeeId: row.employeeId, isActive: row.isActive } })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  if (!isAdmin(session)) return forbidden()
  try {
    const { id } = await ctx.params
    if (id === session.uid) return NextResponse.json({ error: 'Tidak dapat menghapus akun sendiri' }, { status: 400 })
    const account = await db.userAccount.findUnique({ where: { id } })
    if (!account) return NextResponse.json({ error: 'Akun tidak ditemukan' }, { status: 404 })
    if (account.role === 'MASTER_ADMIN') {
      const masters = await db.userAccount.count({ where: { role: 'MASTER_ADMIN', isActive: true } })
      if (masters <= 1) return NextResponse.json({ error: 'Minimal harus ada satu Master Admin aktif' }, { status: 400 })
    }
    await db.userAccount.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
