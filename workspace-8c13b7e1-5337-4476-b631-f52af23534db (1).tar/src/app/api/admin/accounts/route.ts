import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden, isAdmin, hashPassword } from '@/lib/auth'

export const dynamic = 'force-dynamic'

function sanitizeAccount(a: {
  id: string; username: string; name: string; role: string; employeeId: string; isActive: boolean; lastLoginAt: Date | null; createdAt: Date
}, empName: string | null) {
  return {
    id: a.id, username: a.username, name: a.name, role: a.role, employeeId: a.employeeId,
    employeeName: empName, isActive: a.isActive, lastLoginAt: a.lastLoginAt, createdAt: a.createdAt,
  }
}

export async function GET(req: NextRequest) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  if (!isAdmin(session)) return forbidden()
  try {
    const rows = await db.userAccount.findMany({ orderBy: [{ role: 'asc' }, { username: 'asc' }] })
    const empIds = rows.map(r => r.employeeId).filter(Boolean)
    const emps = empIds.length ? await db.employee.findMany({ where: { id: { in: empIds } } }) : []
    const empMap = new Map(emps.map(e => [e.id, e.name]))
    return NextResponse.json({ data: rows.map(r => sanitizeAccount(r, empMap.get(r.employeeId) ?? null)) })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  if (!isAdmin(session)) return forbidden()
  try {
    const body = await req.json()
    const username = String(body.username ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')
    const name = String(body.name ?? '').trim()
    const role = body.role === 'MASTER_ADMIN' ? 'MASTER_ADMIN' : 'STAFF'
    const employeeId = String(body.employeeId ?? '').trim()
    if (username.length < 3) return NextResponse.json({ error: 'Username minimal 3 karakter' }, { status: 400 })
    if (!/^[a-z0-9._-]+$/.test(username)) return NextResponse.json({ error: 'Username hanya boleh huruf kecil, angka, titik, garis bawah, dan strip' }, { status: 400 })
    if (password.length < 6) return NextResponse.json({ error: 'Password minimal 6 karakter' }, { status: 400 })
    if (await db.userAccount.findUnique({ where: { username } })) {
      return NextResponse.json({ error: `Username "${username}" sudah dipakai` }, { status: 409 })
    }
    if (employeeId) {
      if (!(await db.employee.findUnique({ where: { id: employeeId } }))) {
        return NextResponse.json({ error: 'Pekerja tidak ditemukan' }, { status: 400 })
      }
      if (await db.userAccount.findFirst({ where: { employeeId } })) {
        return NextResponse.json({ error: 'Pekerja ini sudah memiliki akun' }, { status: 409 })
      }
    }
    const row = await db.userAccount.create({
      data: { username, passwordHash: hashPassword(password), name, role, employeeId, isActive: body.isActive === false ? false : true },
    })
    return NextResponse.json({ data: sanitizeAccount(row, null) })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
