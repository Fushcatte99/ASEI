import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

/**
 * POST /api/kpi/recalc
 * Hitung ulang KPI periode BERJALAN (bulanan + mingguan) untuk semua karyawan
 * proyek aktif, berdasarkan data live: Attendance (kehadiran, keterlambatan,
 * skor APD) dan Work Task (progress, penyelesaian).
 * Body: { projectId: string, tzOffset?: number } — tzOffset dari
 * new Date().getTimezoneOffset() klien (mis. -420 utk WIB) agar "hari ini"
 * dihitung sesuai zona waktu pengguna, bukan zona waktu server.
 */
export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const body = await req.json().catch(() => ({}))
    const projectId: string | undefined = body?.projectId
    if (!projectId) return NextResponse.json({ error: 'projectId wajib diisi' }, { status: 400 })
    const tzOffset: number = Number.isFinite(body?.tzOffset) ? Number(body.tzOffset) : 0

    // "now" digeser ke jam lokal pengguna (dibaca via getUTC* di bawah)
    const shifted = new Date(Date.now() - tzOffset * 60000)
    const y = shifted.getUTCFullYear()
    const mo = shifted.getUTCMonth()
    const d = shifted.getUTCDate()
    // Bulan berjalan (tanggal 1 jam-lokal pengguna)
    const mStart = new Date(`${String(y).padStart(4, '0')}-${String(mo + 1).padStart(2, '0')}-01T00:00:00.000Z`)
    const mEnd = new Date(mStart)
    mEnd.setUTCMonth(mEnd.getUTCMonth() + 1)
    mEnd.setUTCMilliseconds(-1)
    // Minggu berjalan (Senin..Minggu jam-lokal pengguna)
    const dow = (shifted.getUTCDay() + 6) % 7
    const baseMidnight = Date.UTC(y, mo, d)
    const wStart = new Date(baseMidnight - dow * 86400000)
    const wEnd = new Date(baseMidnight + (6 - dow) * 86400000 + 86399999)

    const [employees, tasks, attMonth, attWeek] = await Promise.all([
      db.employee.findMany({ where: { projectId } }),
      db.workTask.findMany({ where: { projectId } }),
      db.attendance.findMany({ where: { projectId, date: { gte: mStart, lte: mEnd } } }),
      db.attendance.findMany({ where: { projectId, date: { gte: wStart, lte: wEnd } } }),
    ])

    type Att = (typeof attMonth)[number]
    type Tsk = (typeof tasks)[number]

    const compute = (att: Att[], empTasks: Tsk[]) => {
      const total = att.length
      const present = att.filter(a => a.status === 'PRESENT' || a.status === 'LATE').length
      const late = att.filter(a => a.status === 'LATE').length
      const attScore = total ? Math.round((present / total) * 100) : 0
      const ppeVals = att.filter(a => a.ppeScore > 0).map(a => a.ppeScore)
      const safety = ppeVals.length ? Math.round(ppeVals.reduce((s, v) => s + v, 0) / ppeVals.length) : 75
      const disc = total ? Math.max(40, 100 - late * 10) : 70
      const taskScore = empTasks.length ? Math.round(empTasks.reduce((s, t) => s + t.progress, 0) / empTasks.length) : 0
      const done = empTasks.filter(t => t.status === 'COMPLETED').length
      const qual = empTasks.length ? Math.round((done / empTasks.length) * 100) : 0
      // Bobot: bila tidak ada absensi sama sekali, bobot digeser ke task & quality
      const overall = total
        ? Math.round(attScore * 0.25 + taskScore * 0.25 + disc * 0.2 + qual * 0.15 + safety * 0.15)
        : Math.round(taskScore * 0.45 + qual * 0.3 + safety * 0.25)
      const notes = overall >= 85 ? 'Performa sangat baik, pertahankan.'
        : overall >= 70 ? 'Performa baik, tingkatkan konsistensi.'
        : overall >= 55 ? 'Cukup — perlu monitoring & coaching berkala.'
        : 'Di bawah standar — butuh rencana perbaikan performa.'
      return { attendanceScore: attScore, taskScore, disciplineScore: disc, qualityScore: qual, safetyScore: safety, overallScore: overall, notes }
    }

    const nextDay = (d: Date) => { const x = new Date(d); x.setDate(x.getDate() + 1); return x }

    let monthly = 0
    let weekly = 0
    for (const emp of employees) {
      const empTasks = tasks.filter(t => t.assigneeId === emp.id)
      const periods: { period: 'MONTHLY' | 'WEEKLY'; s: Date; e: Date; att: Att[] }[] = [
        { period: 'MONTHLY', s: mStart, e: mEnd, att: attMonth.filter(a => a.employeeId === emp.id) },
        { period: 'WEEKLY', s: wStart, e: wEnd, att: attWeek.filter(a => a.employeeId === emp.id) },
      ]
      for (const p of periods) {
        if (!p.att.length && !empTasks.length) continue // tidak ada data sama sekali -> lewati
        const scores = compute(p.att, empTasks)
        const existing = await db.kpiRecord.findFirst({
          where: { projectId, employeeId: emp.id, period: p.period, periodStart: { gte: p.s, lt: nextDay(p.s) } },
        })
        const data = { periodEnd: p.e, ...scores }
        if (existing) await db.kpiRecord.update({ where: { id: existing.id }, data })
        else await db.kpiRecord.create({ data: { projectId, employeeId: emp.id, period: p.period, periodStart: p.s, ...data } })
        if (p.period === 'MONTHLY') monthly++; else weekly++
      }
    }

    return NextResponse.json({ ok: true, monthly, weekly, periodStart: mStart.toISOString(), weekStart: wStart.toISOString() })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
