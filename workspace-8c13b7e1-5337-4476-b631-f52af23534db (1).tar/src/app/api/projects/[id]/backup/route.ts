import { NextRequest, NextResponse } from 'next/server'
import JSZip from 'jszip'
import { getSessionFromReq, unauthorized } from '@/lib/auth'
import { loadBackupPayload } from '@/lib/backup'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

function slug(v: string): string {
  return v.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'proyek'
}
function stamp(): string {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}

// GET /api/projects/[id]/backup -> ZIP berisi data.json + manifest.json + README.txt
// Satu file = backup lengkap satu proyek (data + foto + gambar + branding), siap di-upload ulang
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const session = await getSessionFromReq(req)
  if (!session) return unauthorized()
  try {
    const { id } = await ctx.params
    const payload = await loadBackupPayload(id)
    if (!payload) return NextResponse.json({ error: 'Proyek tidak ditemukan' }, { status: 404 })
    const proj = payload.project as { name: string; code: string; client: string; location: string }

    const zip = new JSZip()
    zip.file('data.json', JSON.stringify(payload))
    zip.file('manifest.json', JSON.stringify({
      format: payload.format,
      version: payload.version,
      exportedAt: payload.exportedAt,
      app: 'ASEI HR Project Management',
      projectName: proj.name,
      projectCode: proj.code,
      counts: payload.counts,
    }, null, 2))
    const modulLines = Object.entries(payload.counts as Record<string, number>)
      .filter(([, n]) => n > 0)
      .map(([k, n]) => ` - ${k}: ${n} record`)
    zip.file('README.txt', [
      'ASEI HR Project Management — Backup Data Proyek',
      '=================================================',
      `Proyek    : ${proj.name}${proj.code ? ` (${proj.code})` : ''}`,
      `Client    : ${proj.client || '-'}`,
      `Lokasi    : ${proj.location || '-'}`,
      `Diekspor  : ${new Date().toLocaleString('id-ID')} oleh ${session.username}`,
      '',
      'Isi paket:',
      ...modulLines,
      '',
      'Isi file:',
      ' - data.json     : seluruh data proyek (termasuk foto absensi & gambar base64)',
      ' - manifest.json : ringkasan metadata backup',
      ' - README.txt    : petunjuk ini',
      '',
      'Cara memulihkan (upload) ke aplikasi:',
      ' 1. Buka aplikasi ASEI HR dan login',
      ' 2. Klik dropdown proyek di kanan atas (tombol dengan nama proyek)',
      ' 3. Pilih "Upload / Pulihkan dari Folder"',
      ' 4. Pilih file backup .zip ini — salinan proyek lengkap akan dibuat otomatis',
      '',
      'File ini juga bisa disimpan/dipindah ke folder lokal mana pun (USB, network drive, dll).',
    ].join('\n'))

    const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="backup-proyek-${slug(proj.code || proj.name)}-${stamp()}.zip"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
