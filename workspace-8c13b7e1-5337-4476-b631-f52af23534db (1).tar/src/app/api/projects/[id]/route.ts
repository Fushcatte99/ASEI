import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { deleteProjectCascade } from '@/lib/projects'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { id } = await ctx.params
    const body = await req.json()
    const data: Record<string, unknown> = {}
    for (const k of ['code', 'name', 'client', 'location', 'description', 'status', 'brandAppName', 'brandTeamName']) {
      if (k in body) data[k] = String(body[k] ?? '')
    }
    // Branding logo: '' = hapus (pakai default), 'data:image/...' = set logo baru
    if ('brandLogo' in body) {
      const v = String(body.brandLogo ?? '')
      if (v === '') data.brandLogo = null
      else if (v.startsWith('data:image/')) {
        if (v.length > 700_000) return NextResponse.json({ error: 'Ukuran logo terlalu besar (maks ~500KB)' }, { status: 413 })
        data.brandLogo = v
      } else return NextResponse.json({ error: 'Format logo tidak valid' }, { status: 400 })
    }
    // Branding favicon: '' = hapus (pakai default), 'data:image/...' = set favicon baru
    if ('brandFavicon' in body) {
      const v = String(body.brandFavicon ?? '')
      if (v === '') data.brandFavicon = null
      else if (v.startsWith('data:image/')) {
        if (v.length > 700_000) return NextResponse.json({ error: 'Ukuran favicon terlalu besar (maks ~500KB)' }, { status: 413 })
        data.brandFavicon = v
      } else return NextResponse.json({ error: 'Format favicon tidak valid' }, { status: 400 })
    }
    // Simpan string kosong sebagai null agar fallback default bekerja konsisten
    for (const k of ['brandAppName', 'brandTeamName']) {
      if (k in data && !(data[k] as string).trim()) data[k] = null
    }
    for (const k of ['startDate', 'endDate']) {
      if (k in body) {
        const d = body[k] ? new Date(String(body[k])) : null
        data[k] = d && !isNaN(d.getTime()) ? d : null
      }
    }
    if ('name' in data && !data.name) return NextResponse.json({ error: 'Nama proyek tidak boleh kosong' }, { status: 400 })
    const row = await db.project.update({ where: { id }, data })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { id } = await ctx.params
    const project = await db.project.findUnique({ where: { id } })
    if (!project) return NextResponse.json({ error: 'Proyek tidak ditemukan' }, { status: 404 })
    if (project.isDefault) return NextResponse.json({ error: 'Proyek default tidak dapat dihapus' }, { status: 400 })
    await deleteProjectCascade(id)
    return NextResponse.json({ ok: true })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
