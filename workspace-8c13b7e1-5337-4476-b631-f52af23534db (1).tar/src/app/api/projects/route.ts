import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createProjectWithSamples } from '@/lib/projects'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const rows = await db.project.findMany({ orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }] })
    return NextResponse.json({ data: rows })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const body = await req.json()
    const name = String(body.name ?? '').trim()
    if (!name) return NextResponse.json({ error: 'Nama proyek wajib diisi' }, { status: 400 })
    const parseDate = (v: unknown) => {
      if (!v) return null
      const d = new Date(String(v))
      return isNaN(d.getTime()) ? null : d
    }
    const project = await createProjectWithSamples({
      name,
      code: body.code ? String(body.code) : undefined,
      client: body.client ? String(body.client) : undefined,
      location: body.location ? String(body.location) : undefined,
      description: body.description ? String(body.description) : undefined,
      status: body.status ? String(body.status) : undefined,
      startDate: parseDate(body.startDate),
      endDate: parseDate(body.endDate),
      withSamples: body.withSamples !== false,
    })
    return NextResponse.json({ data: project })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
