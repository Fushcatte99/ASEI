import { NextRequest, NextResponse } from 'next/server'
import { getSessionFromReq, unauthorized } from '@/lib/auth'
import { restoreProjectBackup } from '@/lib/backup'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

// POST /api/projects/import
// Body: payload data.json dari file backup (ZIP di-unzip di client)
// Hasil: proyek BARU berisi seluruh data backup (remap ID, aman diimpor berulang)
export async function POST(req: NextRequest) {
  const session = await getSessionFromReq(req)
  if (!session) return unauthorized()
  try {
    const payload = await req.json()
    const r = await restoreProjectBackup(payload)
    return NextResponse.json({ data: r })
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    const status = msg.startsWith('File backup') ? 400 : 500
    return NextResponse.json({ error: msg }, { status })
  }
}
