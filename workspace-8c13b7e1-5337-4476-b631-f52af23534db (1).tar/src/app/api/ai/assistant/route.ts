import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getZai } from '@/lib/ai'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 180

export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { messages, projectId } = await req.json()
    if (!Array.isArray(messages)) return NextResponse.json({ error: 'messages tidak valid' }, { status: 400 })
    const sc = projectId ? { projectId } : {}

    // Project context digest
    const employees = await db.employee.findMany({ where: sc })
    const tasks = await db.workTask.findMany({ where: sc })
    const wbs = await db.wbsTask.findMany({ where: sc })
    const quantities = await db.quantityItem.findMany({ where: sc })
    const equipment = await db.equipmentDelivery.findMany({ where: sc })
    const attendance = await db.attendance.findMany({ where: sc })

    const lvl2 = wbs.filter(w => w.level === 2)
    const tw = lvl2.reduce((s, w) => s + (w.weight || 0), 0) || 1
    const actual = Math.round(lvl2.reduce((s, w) => s + (w.progress || 0) * (w.weight || 0), 0) / tw * 10) / 10
    const planned = Math.round(lvl2.reduce((s, w) => s + (w.plannedProgress || 0) * (w.weight || 0), 0) / tw * 10) / 10
    const disc: Record<string, string> = {}
    for (const d of ['CIVIL', 'MECHANICAL', 'ELECTRICAL']) {
      const items = lvl2.filter(w => w.discipline === d)
      const wsum = items.reduce((s, w) => s + (w.weight || 0), 0) || 1
      disc[d] = `${Math.round(items.reduce((s, w) => s + (w.progress || 0) * (w.weight || 0), 0) / wsum * 10) / 10}%`
    }
    const roleCount: Record<string, number> = {}
    employees.filter(e => e.status === 'ACTIVE').forEach(e => { roleCount[e.role] = (roleCount[e.role] || 0) + 1 })

    const today = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    const projectName = projectId ? (await db.project.findUnique({ where: { id: projectId } }))?.name ?? 'Proyek' : 'Proyek'
    const context = `KONTEKS PROYEK (ASEI HR Project Management - ${projectName}):
- Tanggal hari ini: ${today}
- Progress proyek: aktual ${actual}% vs rencana ${planned}% | Civil ${disc.CIVIL}, Mechanical ${disc.MECHANICAL}, Electrical ${disc.ELECTRICAL}
- Tenaga kerja aktif: ${employees.filter(e => e.status === 'ACTIVE').length} orang (${Object.entries(roleCount).map(([r, n]) => `${r}:${n}`).join(', ')})
- Work task: ${tasks.length} total, ${tasks.filter(t => t.status === 'COMPLETED').length} selesai, ${tasks.filter(t => t.status !== 'COMPLETED' && t.dueDate && new Date(t.dueDate) < new Date()).length} overdue
- Quantity items: ${quantities.length} (contoh: ${quantities.slice(0, 4).map(q => `${q.name} ${q.installedQty}/${q.plannedQty} ${q.unit}`).join('; ')})
- Equipment delivery: ${equipment.length} item, ${equipment.filter(e => ['ARRIVED', 'INSTALLED'].includes(e.status)).length} tiba
- Absensi 7 hari terakhir: ${attendance.filter(a => ['PRESENT', 'LATE'].includes(a.status)).length} hadir, ${attendance.filter(a => a.status === 'LATE').length} terlambat
- Rata-rata skor APD: ${attendance.filter(a => a.ppeScore > 0).length ? Math.round(attendance.filter(a => a.ppeScore > 0).reduce((s, a) => s + a.ppeScore, 0) / attendance.filter(a => a.ppeScore > 0).length) : 0}
- Zero accident: 62 hari
- Kendala utama: delay delivery pump P-101/102 ~10 hari; kekurangan welder 6G stainless.`

    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Kamu adalah "ASEI AI Assistant" untuk software manajemen proyek konstruksi ASEI HR Project Management. Jawab pertanyaan manajemen proyek, K3, HR, progress, planning, absensi, dll. dalam Bahasa Indonesia yang ringkas dan actionable. Kamu bisa menjelaskan fitur software ini, memberi saran penjadwalan (ala Primavera), analisis produktivitas, dan rekomendasi tindakan. Gunakan data konteks proyek berikut bila relevan.\n\n${context}`,
        },
        ...messages.slice(-12).map((m: { role: string; content: string }) => ({
          role: (m.role === 'user' ? 'user' : 'assistant') as 'user' | 'assistant',
          content: String(m.content).slice(0, 4000),
        })),
      ],
      thinking: { type: 'disabled' },
    })
    const content = completion.choices[0]?.message?.content ?? 'Maaf, terjadi kesalahan.'
    return NextResponse.json({ data: { content } })
  } catch (e) {
    return NextResponse.json({ error: `Assistant gagal: ${String(e)}` }, { status: 500 })
  }
}
