import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getZai } from '@/lib/ai'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 180

const fmtDate = (d: Date | null | undefined) => d ? new Date(d).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'

export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const body = await req.json()
    const scope: string = body.scope ?? 'INDIVIDUAL' // INDIVIDUAL | TEAM | PROJECT
    const employeeId: string = body.employeeId ?? ''
    const role: string = body.role ?? ''
    const days: number = Number(body.days ?? 7)
    const projectId: string = body.projectId ?? ''
    const sc = projectId ? { projectId } : {}

    const de = new Date(); de.setHours(23, 59, 59, 999)
    const ds = new Date(); ds.setDate(ds.getDate() - days); ds.setHours(0, 0, 0, 0)

    const employees = await db.employee.findMany({ where: sc })
    const empMap = Object.fromEntries(employees.map(e => [e.id, e]))
    const attendance = (await db.attendance.findMany({ where: sc })).filter(a => { const d = new Date(a.date); return d >= ds && d <= de })
    const tasks = await db.workTask.findMany({ where: sc })
    const dailyReports = (await db.dailyReport.findMany({ where: sc })).filter(r => { const d = new Date(r.date); return d >= ds && d <= de })
    const weeklyReports = await db.weeklyReport.findMany({ where: sc })
    const wbs = await db.wbsTask.findMany({ where: sc })

    let subjects: typeof employees = []
    let title = ''
    if (scope === 'INDIVIDUAL') {
      const emp = employees.find(e => e.id === employeeId)
      if (!emp) return NextResponse.json({ error: 'Karyawan tidak ditemukan' }, { status: 404 })
      subjects = [emp]
      title = `Ringkasan AI - ${emp.name} (${emp.position})`
    } else if (scope === 'TEAM') {
      subjects = role ? employees.filter(e => e.role === role) : employees
      title = `Ringkasan AI Tim - ${role || 'Semua Posisi'}`
    } else {
      subjects = employees
      title = 'Ringkasan AI Seluruh Proyek'
    }

    const ids = new Set(subjects.map(s => s.id))
    const att = attendance.filter(a => ids.has(a.employeeId))
    const tsk = tasks.filter(t => ids.has(t.assigneeId))
    const dr = dailyReports.filter(r => ids.has(r.employeeId))
    const wr = weeklyReports.filter(r => ids.has(r.employeeId))

    // compact data digest
    const lines: string[] = []
    lines.push(`Periode data: ${fmtDate(ds)} s/d ${fmtDate(de)} (${days} hari terakhir).`)
    if (scope === 'PROJECT') {
      const lvl2 = wbs.filter(w => w.level === 2)
      const tw = lvl2.reduce((s, w) => s + (w.weight || 0), 0) || 1
      const actual = Math.round(lvl2.reduce((s, w) => s + (w.progress || 0) * (w.weight || 0), 0) / tw * 10) / 10
      const planned = Math.round(lvl2.reduce((s, w) => s + (w.plannedProgress || 0) * (w.weight || 0), 0) / tw * 10) / 10
      lines.push(`PROYEK: Progress aktual ${actual}% vs rencana ${planned}% (deviasi ${Math.round((actual - planned) * 10) / 10}%).`)
      const byDisc: Record<string, string[]> = {}
      for (const w of lvl2) { (byDisc[w.discipline] ||= []).push(`${w.name}: ${w.progress}% (plan ${w.plannedProgress}%)`) }
      for (const [d, arr] of Object.entries(byDisc)) lines.push(`  ${d}: ${arr.join('; ')}`)
      lines.push(`Total karyawan aktif: ${employees.filter(e => e.status === 'ACTIVE').length}. Task: ${tasks.filter(t => t.status === 'COMPLETED').length} selesai / ${tasks.length} total, ${tasks.filter(t => t.status !== 'COMPLETED' && t.dueDate && new Date(t.dueDate) < new Date()).length} overdue.`)
    }
    lines.push(`DATA KEHADIRAN (${att.length} record): rata-rata kehadiran hari kerja ${Math.round(att.filter(a => ['PRESENT', 'LATE'].includes(a.status)).length / Math.max(1, new Set(att.map(a => a.employeeId + a.date.toDateString())).size)) * 100 || 0}%, keterlambatan ${att.filter(a => a.status === 'LATE').length}x, rata-rata skor APD ${att.filter(a => a.ppeScore > 0).length ? Math.round(att.filter(a => a.ppeScore > 0).reduce((s, a) => s + a.ppeScore, 0) / att.filter(a => a.ppeScore > 0).length) : 0}, rata-rata mood ${att.filter(a => a.moodScore > 0).length ? Math.round(att.filter(a => a.moodScore > 0).reduce((s, a) => s + a.moodScore, 0) / att.filter(a => a.moodScore > 0).length) : 0}.`)
    const emoCount: Record<string, number> = {}
    att.forEach(a => { if (a.emotion) emoCount[a.emotion] = (emoCount[a.emotion] || 0) + 1 })
    lines.push(`Emosi terdeteksi: ${Object.entries(emoCount).map(([k, v]) => `${k}=${v}`).join(', ') || '-'}.`)

    if (scope !== 'INDIVIDUAL') {
      const perRole: Record<string, string[]> = {}
      for (const s of subjects) {
        const st = s.role + (s.discipline !== 'GENERAL' ? ` ${s.discipline}` : '')
        ;(perRole[st] ||= []).push(s.name)
      }
      lines.push(`KOMPOSISI TIM: ${Object.entries(perRole).map(([r, n]) => `${r}: ${n.length} org`).join(', ')}.`)
    }

    if (scope === 'INDIVIDUAL') {
      const emp = subjects[0]
      const myAtt = att.filter(a => a.employeeId === emp.id)
      const myTasks = tasks.filter(t => t.assigneeId === emp.id)
      lines.push(`PROFIL: ${emp.name} (${emp.nip}), posisi ${emp.position}, ${emp.role} - ${emp.discipline}${emp.subDiscipline ? '/' + emp.subDiscipline : ''}. Atasan: ${empMap[emp.managerId]?.name ?? '-'}.`)
      lines.push(`KEHADIRAN: ${myAtt.filter(a => ['PRESENT', 'LATE'].includes(a.status)).length} hadir dari ${myAtt.length} hari (terlambat ${myAtt.filter(a => a.status === 'LATE').length}x), rata-rata APD ${myAtt.filter(a => a.ppeScore > 0).length ? Math.round(myAtt.filter(a => a.ppeScore > 0).reduce((s, a) => s + a.ppeScore, 0) / myAtt.filter(a => a.ppeScore > 0).length) : 0}, mood ${myAtt.filter(a => a.moodScore > 0).length ? Math.round(myAtt.filter(a => a.moodScore > 0).reduce((s, a) => s + a.moodScore, 0) / myAtt.filter(a => a.moodScore > 0).length) : 0}, emosi dominan: ${myAtt.map(a => a.emotion).filter(Boolean).sort((a, b) => myAtt.filter(x => x.emotion === b).length - myAtt.filter(x => x.emotion === a).length)[0] || '-'}.`)
      lines.push(`TASK: ${myTasks.map(t => `"${t.title}" [${t.status} ${t.progress}%]`).join('; ') || 'tidak ada task aktif'}.`)
      const myDr = dailyReports.filter(r => r.employeeId === emp.id).slice(0, 5)
      if (myDr.length) lines.push(`LAPORAN HARIAN TERAKHIR: ${myDr.map(r => `(${fmtDate(r.date)}) ${r.activities.slice(0, 150)}${r.issues ? ` [kendala: ${r.issues.slice(0, 80)}]` : ''}`).join(' | ')}`)
      const myWr = weeklyReports.filter(r => r.employeeId === emp.id).slice(0, 3)
      if (myWr.length) lines.push(`LAPORAN MINGGUAN: ${myWr.map(r => `[${r.type}] ${r.progressSummary || r.nextWeekPlan || r.achievements}`.slice(0, 200)).join(' | ')}`)
    } else {
      lines.push(`TASK AKTIF: ${tsk.filter(t => t.status !== 'COMPLETED').slice(0, 15).map(t => `"${t.title}" (${empMap[t.assigneeId]?.name ?? '?'} [${empMap[t.assigneeId]?.role ?? '?'}], ${t.status} ${t.progress}%)`).join('; ')}`)
      lines.push(`LAPORAN HARIAN (${dr.length}): ${dr.slice(0, 10).map(r => `${empMap[r.employeeId]?.name ?? '?'} [${r.role}] ${(r.issues || r.achievements || r.activities).slice(0, 100)}`).join(' | ')}`)
      if (wr.length) lines.push(`LAPORAN/RENCANA MINGGUAN: ${wr.map(r => `${empMap[r.employeeId]?.name ?? '?'} [${r.role} ${r.type}] ${(r.progressSummary || r.nextWeekPlan).slice(0, 120)}`).join(' | ')}`)
    }

    const dataDigest = lines.join('\n')

    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Kamu adalah HR Business Partner & Management Analyst di perusahaan EPC konstruksi ASEI. Buat RINGKASAN performa profesional dalam Bahasa Indonesia berdasarkan data sistem. Format output:
## Ringkasan Umum
(2-3 paragraf analisis kondisi)
## Sorotan & Pencapaian
- (poin-poin)
## Perlu Perhatian / Risiko
- (poin-poin: kedisiplinan, APD, mood/mental, keterlambatan, kualitas)
## Rekomendasi
- (rekomendasi actionable untuk manajemen)
Gunakan angka dari data. Jangan mengarang data yang tidak ada. Maksimal 450 kata.`,
        },
        {
          role: 'user',
          content: `Buat ringkasan untuk: ${title}\n\nDATA SISTEM ASEI HR PROJECT MANAGEMENT:\n${dataDigest}`,
        },
      ],
      thinking: { type: 'disabled' },
    })

    const content = completion.choices[0]?.message?.content ?? 'Gagal generate ringkasan.'

    const saved = await db.aiSummary.create({
      data: {
        projectId,
        employeeId: scope === 'INDIVIDUAL' ? employeeId : '',
        scope, role,
        periodStart: ds, periodEnd: de,
        title, content,
      },
    })
    return NextResponse.json({ data: saved })
  } catch (e) {
    return NextResponse.json({ error: `Generate summary gagal: ${String(e)}` }, { status: 500 })
  }
}
