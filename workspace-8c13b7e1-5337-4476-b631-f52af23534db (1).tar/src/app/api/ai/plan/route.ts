import { NextRequest, NextResponse } from 'next/server'
import { getZai, extractJson } from '@/lib/ai'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 180

type SuggestedTask = {
  name: string
  discipline: string
  subDiscipline: string
  duration: number
  after?: string[] // nama task pendahulu (bisa null)
  resources?: string
  weight?: number
}

// AI WBS Plan Suggester - ala Primavera scheduling
export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { discipline = 'MECHANICAL', scope = 'Instalasi piping area proses', startDate = '' } = await req.json()
    const zai = await getZai()
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Kamu adalah senior project planner konstruksi EPC (ahli Primavera P6 & MS Project). Buat breakdown plan kerja (WBS) untuk lingkup yang diminta. Aturan: 6-10 task granular & berurutan logis, gunakan dependensi antar task, durasi realistis dalam hari kerja, sesuai standar konstruksi (consider fabrikasi, instalasi, testing, QC hold point, K3). Jawab HANYA array JSON valid tanpa teks lain, format:
[{"name":"...","discipline":"CIVIL|MECHANICAL|ELECTRICAL|GENERAL","subDiscipline":"...","duration":5,"after":["nama task pendahulu (kosong array jika tidak ada)"],"resources":"crew/equipment","weight":5}]
weight = bobot % relatif dalam scope ini (total mendekati 100).`,
        },
        {
          role: 'user',
          content: `Buatkan plan untuk:\n- Disiplin utama: ${discipline}\n- Lingkup: ${scope}\n- Rencana mulai: ${startDate || 'secepatnya'}\n- Proyek: EPC Skid Package & Utility Piping (pondasi siap, material piping CS/SS tersedia).`,
        },
      ],
      thinking: { type: 'disabled' },
    })
    const content = completion.choices[0]?.message?.content ?? ''
    const tasks = extractJson<SuggestedTask[]>(content)
    if (!Array.isArray(tasks) || tasks.length === 0) {
      return NextResponse.json({ error: 'AI tidak menghasilkan plan valid', raw: content.slice(0, 500) }, { status: 422 })
    }
    return NextResponse.json({ data: tasks })
  } catch (e) {
    return NextResponse.json({ error: `AI plan gagal: ${String(e)}` }, { status: 500 })
  }
}
