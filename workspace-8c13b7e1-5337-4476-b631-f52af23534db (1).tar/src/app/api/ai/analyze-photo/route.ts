import { NextRequest, NextResponse } from 'next/server'
import { analyzePhoto } from '@/lib/ai'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { photo } = await req.json()
    if (!photo || typeof photo !== 'string' || !photo.startsWith('data:image')) {
      return NextResponse.json({ error: 'Foto tidak valid (butuh data URL image)' }, { status: 400 })
    }
    const result = await analyzePhoto(photo)
    return NextResponse.json({ data: result })
  } catch (e) {
    return NextResponse.json({ error: `Analisis AI gagal: ${String(e)}` }, { status: 500 })
  }
}
