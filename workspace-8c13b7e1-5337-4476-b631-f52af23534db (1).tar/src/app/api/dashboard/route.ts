import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

function dayBounds(d = new Date()) {
  const s = new Date(d); s.setHours(0, 0, 0, 0)
  const e = new Date(d); e.setHours(23, 59, 59, 999)
  return { s, e }
}

export async function GET(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const projectId = req.nextUrl.searchParams.get('projectId') ?? ''
    const sc = projectId ? { projectId } : {}
    const { s: ds, e: de } = dayBounds()
    const employees = await db.employee.findMany({ where: sc })
    const active = employees.filter(e => e.status === 'ACTIVE')
    const attendanceAll = await db.attendance.findMany({ where: sc })
    const tasks = await db.workTask.findMany({ where: sc })
    const wbs = await db.wbsTask.findMany({ where: sc })
    const quantities = await db.quantityItem.findMany({ where: sc })
    const fabrications = await db.fabricationItem.findMany({ where: sc })
    const equipment = await db.equipmentDelivery.findMany({ where: sc })
    const kpis = await db.kpiRecord.findMany({ where: sc })
    const dailyReports = await db.dailyReport.findMany({ where: sc })

    // today attendance
    const today = attendanceAll.filter(a => {
      const d = new Date(a.date)
      return d >= ds && d <= de
    })
    const presentToday = today.filter(a => a.status === 'PRESENT' || a.status === 'LATE').length
    const lateToday = today.filter(a => a.status === 'LATE').length
    const absentToday = today.filter(a => a.status === 'ABSENT').length
    const avgPpe = today.length ? Math.round(today.filter(a => a.ppeScore > 0).reduce((s, a) => s + a.ppeScore, 0) / Math.max(1, today.filter(a => a.ppeScore > 0).length)) : 0
    const avgMood = today.length ? Math.round(today.filter(a => a.moodScore > 0).reduce((s, a) => s + a.moodScore, 0) / Math.max(1, today.filter(a => a.moodScore > 0).length)) : 0

    // 7-day trend
    const trend: { date: string; present: number; ppe: number; mood: number }[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i)
      const { s, e } = dayBounds(d)
      const day = attendanceAll.filter(a => { const ad = new Date(a.date); return ad >= s && ad <= e })
      const present = day.filter(a => a.status === 'PRESENT' || a.status === 'LATE').length
      const ppeArr = day.filter(a => a.ppeScore > 0)
      const moodArr = day.filter(a => a.moodScore > 0)
      trend.push({
        date: s.toISOString().slice(0, 10), present,
        ppe: ppeArr.length ? Math.round(ppeArr.reduce((x, a) => x + a.ppeScore, 0) / ppeArr.length) : 0,
        mood: moodArr.length ? Math.round(moodArr.reduce((x, a) => x + a.moodScore, 0) / moodArr.length) : 0,
      })
    }

    // tasks
    const taskStats = {
      total: tasks.length,
      pending: tasks.filter(t => t.status === 'PENDING').length,
      inProgress: tasks.filter(t => t.status === 'IN_PROGRESS').length,
      completed: tasks.filter(t => t.status === 'COMPLETED').length,
      delayed: tasks.filter(t => t.status === 'DELAYED').length,
      overdue: tasks.filter(t => t.status !== 'COMPLETED' && t.status !== 'CANCELLED' && t.dueDate && new Date(t.dueDate) < new Date()).length,
    }

    // WBS weighted progress (level 2 items)
    const lvl2 = wbs.filter(w => w.level === 2)
    const totalW = lvl2.reduce((s, w) => s + (w.weight || 0), 0) || 1
    const actualProgress = Math.round(lvl2.reduce((s, w) => s + (w.progress || 0) * (w.weight || 0), 0) / totalW * 10) / 10
    const plannedProgress = Math.round(lvl2.reduce((s, w) => s + (w.plannedProgress || 0) * (w.weight || 0), 0) / totalW * 10) / 10

    // discipline progress
    const discProgress = ['CIVIL', 'MECHANICAL', 'ELECTRICAL'].map(d => {
      const items = lvl2.filter(w => w.discipline === d)
      const wsum = items.reduce((s, w) => s + (w.weight || 0), 0) || 1
      return {
        discipline: d,
        actual: Math.round(items.reduce((s, w) => s + (w.progress || 0) * (w.weight || 0), 0) / wsum * 10) / 10,
        planned: Math.round(items.reduce((s, w) => s + (w.plannedProgress || 0) * (w.weight || 0), 0) / wsum * 10) / 10,
        count: items.length,
      }
    })

    // headcount by role & discipline
    const byRole: Record<string, number> = {}
    const byDisc: Record<string, number> = {}
    for (const e of active) {
      byRole[e.role] = (byRole[e.role] || 0) + 1
      byDisc[e.discipline] = (byDisc[e.discipline] || 0) + 1
    }

    // qty per discipline (avg completion %)
    const qtyStats = ['CIVIL', 'MECHANICAL', 'ELECTRICAL'].map(d => {
      const items = quantities.filter(q => q.discipline === d)
      const pct = items.length ? Math.round(items.reduce((s, q) => s + (q.plannedQty ? Math.min(100, (q.installedQty / q.plannedQty) * 100) : 0), 0) / items.length) : 0
      return { discipline: d, items: items.length, avgPct: pct }
    })

    const fabTotal = fabrications.length
    const fabProgress = fabTotal ? Math.round(fabrications.reduce((s, f) => s + (f.totalQty ? Math.min(100, (f.weldedQty / f.totalQty) * 100) : 0), 0) / fabTotal) : 0
    const eqStats = {
      total: equipment.length,
      arrived: equipment.filter(e => ['ARRIVED', 'INSTALLED'].includes(e.status)).length,
      delayed: equipment.filter(e => e.status === 'DELAYED' || (e.plannedDate && !e.actualDate && new Date(e.plannedDate) < new Date())).length,
    }

    // KPI monthly top & bottom
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    const monthly = kpis.filter(k => k.period === 'MONTHLY' && new Date(k.periodStart) >= monthStart)
    const empMap = Object.fromEntries(employees.map(e => [e.id, e]))
    const ranked = monthly.map(k => ({ employee: empMap[k.employeeId], overall: k.overallScore }))
      .filter(r => r.employee).sort((a, b) => b.overall - a.overall)

    // reports today
    const reportsToday = dailyReports.filter(r => { const d = new Date(r.date); return d >= ds && d <= de }).length

    return NextResponse.json({
      data: {
        headcount: { total: active.length, byRole, byDisc },
        attendance: { today: today.length, presentToday, lateToday, absentToday, avgPpe, avgMood, leaveToday: today.filter(a => a.status === 'LEAVE').length },
        trend,
        taskStats,
        progress: { actualProgress, plannedProgress, discProgress, deviation: Math.round((actualProgress - plannedProgress) * 10) / 10 },
        qtyStats, fabTotal, fabProgress, eqStats,
        reportsToday,
        topPerformers: ranked.slice(0, 5).map(r => ({ id: r.employee!.id, name: r.employee!.name, role: r.employee!.role, score: r.overall })),
        lowPerformers: ranked.slice(-5).reverse().map(r => ({ id: r.employee!.id, name: r.employee!.name, role: r.employee!.role, score: r.overall })),
        zeroAccidentDays: 62,
      },
    })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
