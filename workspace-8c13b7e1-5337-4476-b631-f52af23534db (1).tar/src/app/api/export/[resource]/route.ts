import { NextRequest, NextResponse } from 'next/server'
import JSZip from 'jszip'
import { db } from '@/lib/db'
import { getSessionFromReq, unauthorized } from '@/lib/auth'
import { LOADERS, toCsv } from '@/lib/export-data'
import { EXPORT_ITEMS } from '@/lib/export-registry'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

function slug(v: string): string {
  return v.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'proyek'
}
function stamp(): string {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}
function csvResponse(name: string, csv: string): NextResponse {
  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${name}"`,
      'Cache-Control': 'no-store',
    },
  })
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ resource: string }> }) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  try {
    const { resource } = await ctx.params
    const projectId = req.nextUrl.searchParams.get('projectId') ?? ''
    const project = projectId ? await db.project.findUnique({ where: { id: projectId } }) : null
    const base = project ? `${slug(project.code || project.name)}-${stamp()}` : `asei-hr-${stamp()}`

    // ===== ZIP: semua modul sekaligus =====
    if (resource === 'all') {
      const zip = new JSZip()
      const usedFolders = new Map<string, JSZip>()
      const list: string[] = []
      for (const [key, item] of Object.entries(EXPORT_ITEMS)) {
        const loader = LOADERS[key]
        if (!loader) continue
        const ds = await loader(projectId)
        let folder = usedFolders.get(item.folder)
        if (!folder) { folder = zip.folder(item.folder)!; usedFolders.set(item.folder, folder) }
        folder.file(`${key}.csv`, toCsv(ds.labels, ds.rows))
        list.push(`${item.folder}/${key}.csv — ${item.label} (${ds.rows.length} baris)`)
      }
      // Sertakan file gambar asli (CAD/PDF/PNG)
      const drawings = await db.drawingFile.findMany({ where: { projectId }, select: { fileName: true, fileType: true, mimeType: true, fileData: true } })
      if (drawings.length) {
        const dFolder = zip.folder('4-file-gambar')!
        const extOf = (mime: string, ft: string): string => {
          if (mime.includes('pdf')) return 'pdf'
          if (mime.includes('png')) return 'png'
          if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg'
          if (mime.includes('webp')) return 'webp'
          if (mime.includes('svg')) return 'svg'
          if (ft === 'CAD') return 'dxf'
          return 'bin'
        }
        drawings.forEach((d, i) => {
          if (!d.fileData) return
          const b64 = d.fileData.includes(',') ? d.fileData.split(',')[1] : d.fileData
          try {
            const name = d.fileName || `gambar-${i + 1}.${extOf(d.mimeType, d.fileType)}`
            dFolder.file(name, Buffer.from(b64, 'base64'))
          } catch { /* skip file corrupt */ }
        })
        list.push(`4-file-gambar/ — ${drawings.length} file gambar asli`)
      }
      zip.file('README.txt', [
        'ASEI HR Project Management — Export Semua Modul',
        '================================================',
        `Proyek   : ${project?.name ?? '-'} (${project?.code ?? '-'})`,
        `Client   : ${project?.client ?? '-'}`,
        `Diekspor : ${new Date().toLocaleString('id-ID')}`,
        `Oleh     : ${session.username} (${session.role})`,
        '',
        'Isi paket:',
        ...list.map(l => ' - ' + l),
        '',
        'File CSV dapat dibuka di Excel / Google Sheets (pemisah koma, UTF-8).',
      ].join('\n'))
      const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })
      return new NextResponse(new Uint8Array(buf), {
        headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': `attachment; filename="export-semua-modul-${base}.zip"`,
          'Cache-Control': 'no-store',
        },
      })
    }

    // ===== CSV per modul =====
    const loader = LOADERS[resource]
    if (!loader) return NextResponse.json({ error: 'Modul export tidak dikenal' }, { status: 404 })
    const ds = await loader(projectId)
    return csvResponse(`${resource}-${base}.csv`, toCsv(ds.labels, ds.rows))
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
