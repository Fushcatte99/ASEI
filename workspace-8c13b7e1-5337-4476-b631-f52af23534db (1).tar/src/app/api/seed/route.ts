import { NextRequest, NextResponse } from 'next/server'
import { seed } from '@/lib/seed'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  if (__session.role !== 'MASTER_ADMIN') return forbidden()
  try {
    const result = await seed()
    return NextResponse.json({ ok: true, result })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
