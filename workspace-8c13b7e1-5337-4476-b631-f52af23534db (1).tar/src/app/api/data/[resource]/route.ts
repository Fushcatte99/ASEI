import { NextRequest, NextResponse } from 'next/server'
import { isResource, modelOf, sanitize, buildWhere, SCHEMA } from '@/lib/crud'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, ctx: { params: Promise<{ resource: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  const { resource } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ error: 'Unknown resource' }, { status: 404 })
  try {
    const sp = req.nextUrl.searchParams
    const where = buildWhere(resource, sp)
    const m = modelOf(resource)
    const rows = await m.findMany({ where })
    return NextResponse.json({ data: rows })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ resource: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  const { resource } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ error: 'Unknown resource' }, { status: 404 })
  try {
    const body = await req.json()
    const data = sanitize(resource, body)
    // stamp proyek aktif jika belum ada di body
    if (SCHEMA[resource].projectId && !data.projectId) {
      data.projectId = req.nextUrl.searchParams.get('projectId') ?? ''
    }
    const m = modelOf(resource)
    const row = await m.create({ data })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
