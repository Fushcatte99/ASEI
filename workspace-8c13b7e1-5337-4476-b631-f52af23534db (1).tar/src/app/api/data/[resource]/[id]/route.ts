import { NextRequest, NextResponse } from 'next/server'
import { isResource, modelOf, sanitize, buildWhere } from '@/lib/crud'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, ctx: { params: Promise<{ resource: string; id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  const { resource, id } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ error: 'Unknown resource' }, { status: 404 })
  try {
    const m = modelOf(resource)
    const row = await m.findUnique({ where: { id } })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ resource: string; id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  const { resource, id } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ error: 'Unknown resource' }, { status: 404 })
  try {
    const body = await req.json()
    const data = sanitize(resource, body)
    if (Object.keys(data).length === 0) return NextResponse.json({ error: 'No valid fields' }, { status: 400 })
    const m = modelOf(resource)
    const row = await m.update({ where: { id }, data })
    return NextResponse.json({ data: row })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ resource: string; id: string }> }) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  const { resource, id } = await ctx.params
  if (!isResource(resource)) return NextResponse.json({ error: 'Unknown resource' }, { status: 404 })
  try {
    const m = modelOf(resource)
    await m.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
