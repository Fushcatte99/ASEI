import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { analyzePhoto, type PhotoAnalysis } from '@/lib/ai'
import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

// Check-in / check-out dengan foto + analisis AI (APD & emosi)
export async function POST(req: NextRequest) {
  const __session = await getSessionFromReq(req)
  if (!__session) return unauthorized()
  try {
    const { employeeId, photo, location, notes } = await req.json()
    if (!employeeId) return NextResponse.json({ error: 'employeeId wajib' }, { status: 400 })

    const emp = await db.employee.findUnique({ where: { id: employeeId } })
    if (!emp) return NextResponse.json({ error: 'Karyawan tidak ditemukan' }, { status: 404 })

    const now = new Date()
    const ds = new Date(now); ds.setHours(0, 0, 0, 0)
    const de = new Date(now); de.setHours(23, 59, 59, 999)
    const existing = await db.attendance.findFirst({
      where: { employeeId, date: { gte: ds, lte: de } },
      orderBy: { date: 'desc' },
    })

    let analysis: PhotoAnalysis | null = null
    if (photo && typeof photo === 'string' && photo.startsWith('data:image')) {
      analysis = await analyzePhoto(photo)
    }

    // CHECK-OUT: sudah check-in dan belum check-out
    if (existing && existing.checkIn && !existing.checkOut) {
      const hours = Math.round(((now.getTime() - new Date(existing.checkIn).getTime()) / 3600000) * 10) / 10
      const updated = await db.attendance.update({
        where: { id: existing.id },
        data: { checkOut: now, checkOutPhoto: photo ?? '', workHours: hours },
      })
      return NextResponse.json({ data: { mode: 'CHECK_OUT', attendance: updated, analysis } })
    }

    // CHECK-IN baru
    const lateMinutes = now.getHours() > 7 || (now.getHours() === 7 && now.getMinutes() > 30)
      ? (now.getHours() - 7) * 60 + now.getMinutes() - 30 : 0
    const status = lateMinutes > 0 ? 'LATE' : 'PRESENT'
    const ppe = analysis?.ppe
    const ppeScore = analysis ? analysis.ppeScore : 0
    const ppeDetails = ppe ? JSON.stringify(ppe) : '{}'
    const apdComplete = ppe ? Object.values(ppe).every(Boolean) : false

    if (analysis && ppe) {
      await db.employee.update({
        where: { id: employeeId },
        data: { apdStatus: apdComplete ? 'COMPLETE' : 'INCOMPLETE', apdItems: ppeDetails },
      })
    }

    const created = await db.attendance.create({
      data: {
        projectId: emp.projectId,
        employeeId,
        date: now,
        checkIn: now,
        checkInPhoto: photo ?? '',
        location: location || 'Site Utama',
        status,
        lateMinutes,
        ppeScore,
        ppeDetails,
        ppeNotes: analysis?.ppeNotes ?? '',
        emotion: analysis?.emotion ?? '',
        moodScore: analysis?.moodScore ?? 0,
        aiNotes: analysis?.aiNotes ?? '',
        aiAnalyzed: !!analysis,
        notes: notes ?? '',
      },
    })
    return NextResponse.json({ data: { mode: 'CHECK_IN', attendance: created, analysis } })
  } catch (e) {
    return NextResponse.json({ error: `Check-in gagal: ${String(e)}` }, { status: 500 })
  }
}
