import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { SESSION_COOKIE, BOOTSTRAP_ADMIN, createToken, verifyPassword, hashPassword, cookieOptions, type Role } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const username = String(body.username ?? '').trim()
    const password = String(body.password ?? '')
    if (!username || !password) {
      return NextResponse.json({ error: 'Username dan password wajib diisi' }, { status: 400 })
    }

    // Bootstrap: jika belum ada akun sama sekali, buat akun master admin default
    if ((await db.userAccount.count()) === 0 && username === BOOTSTRAP_ADMIN.username && password === BOOTSTRAP_ADMIN.password) {
      await db.userAccount.create({
        data: { username: BOOTSTRAP_ADMIN.username, passwordHash: hashPassword(BOOTSTRAP_ADMIN.password), name: BOOTSTRAP_ADMIN.name, role: 'MASTER_ADMIN' },
      })
    }

    const account = await db.userAccount.findUnique({ where: { username } })
    if (!account || !account.isActive || !verifyPassword(password, account.passwordHash)) {
      return NextResponse.json({ error: 'Username atau password salah' }, { status: 401 })
    }

    await db.userAccount.update({ where: { id: account.id }, data: { lastLoginAt: new Date() } })

    const token = createToken({
      uid: account.id,
      username: account.username,
      name: account.name || account.username,
      role: (account.role === 'MASTER_ADMIN' ? 'MASTER_ADMIN' : 'STAFF') as Role,
      employeeId: account.employeeId ?? '',
    })
    const res = NextResponse.json({
      data: { uid: account.id, username: account.username, name: account.name || account.username, role: account.role },
    })
    res.cookies.set(SESSION_COOKIE, token, cookieOptions())
    return res
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
