import { NextResponse } from 'next/server'
import { SESSION_COOKIE, cookieOptions } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function POST() {
  const res = NextResponse.json({ ok: true })
  res.cookies.set(SESSION_COOKIE, '', { ...cookieOptions(0), maxAge: 0 })
  return res
}
