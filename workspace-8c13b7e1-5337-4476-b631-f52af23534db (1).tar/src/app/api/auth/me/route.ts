import { NextRequest, NextResponse } from 'next/server'
import { getSessionFromReq, unauthorized } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const session = getSessionFromReq(req)
  if (!session) return unauthorized()
  return NextResponse.json({
    data: { uid: session.uid, username: session.username, name: session.name, role: session.role, employeeId: session.employeeId },
  })
}
