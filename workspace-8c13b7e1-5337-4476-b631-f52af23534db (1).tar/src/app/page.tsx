import AppShell from '@/components/asei/app-shell'

export default function Home() {
  return <AppShell />
}
