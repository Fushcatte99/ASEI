'use client'
// Error boundary tingkat rute — menangkap exception client agar user tidak melihat
// layar "Application error: a client-side exception..." yang buntu tanpa jalan keluar.
import { useEffect } from 'react'
import { AlertTriangle, RefreshCw, RotateCcw } from 'lucide-react'

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('[ASEI] Client error:', error)
  }, [error])

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md text-center">
        <div className="h-14 w-14 rounded-2xl bg-amber-50 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="h-7 w-7 text-amber-500" />
        </div>
        <h1 className="font-bold text-slate-900 text-lg mb-1">Terjadi Kesalahan Tak Terduga</h1>
        <p className="text-sm text-slate-500 mb-1">
          Aplikasi mengalami kesalahan saat memproses halaman ini. Data proyek Anda <b>aman</b> di server.
        </p>
        <p className="text-xs text-slate-400 mb-5 break-words">{error?.message || 'Kesalahan tidak diketahui'}</p>
        <div className="flex gap-2 justify-center">
          <button
            onClick={reset}
            className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-amber-500 to-orange-600 shadow-sm hover:opacity-90"
          >
            <RefreshCw className="h-4 w-4" /> Coba Lagi
          </button>
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold text-slate-700 border border-slate-300 bg-white hover:bg-slate-50"
          >
            <RotateCcw className="h-4 w-4" /> Muat Ulang Aplikasi
          </button>
        </div>
      </div>
    </div>
  )
}
