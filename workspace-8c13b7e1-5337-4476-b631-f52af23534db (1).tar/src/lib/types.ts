// ============ Types for ASEI HR Project Management ============
export interface SessionInfo {
  uid: string; username: string; name: string
  role: 'MASTER_ADMIN' | 'STAFF'; employeeId: string
}
export interface UserAccount {
  id: string; username: string; name: string; role: 'MASTER_ADMIN' | 'STAFF'
  employeeId: string; employeeName?: string | null; isActive: boolean
  lastLoginAt: string | null; createdAt: string
}
export interface Project {
  id: string; code: string; name: string; client: string; location: string; description: string
  status: string; startDate: string | null; endDate: string | null; isDefault: boolean
  brandLogo: string | null; brandFavicon: string | null; brandAppName: string | null; brandTeamName: string | null
  createdAt: string; updatedAt: string
}
export interface Employee {
  id: string; nip: string; name: string; role: string; discipline: string; subDiscipline: string
  position: string; managerId: string; phone: string; email: string; joinDate: string; status: string
  avatarColor: string; safetyInduction: boolean; inductionDate: string | null; inductionScore: number
  apdStatus: string; apdItems: string; skills: string; notes: string
}
export interface Attendance {
  id: string; employeeId: string; date: string; checkIn: string | null; checkOut: string | null
  checkInPhoto: string; checkOutPhoto: string; location: string; status: string; lateMinutes: number
  workHours: number; ppeScore: number; ppeDetails: string; ppeNotes: string; emotion: string
  moodScore: number; aiNotes: string; aiAnalyzed: boolean; notes: string
}
export interface WorkTask {
  id: string; title: string; description: string; discipline: string; subDiscipline: string
  category: string; assigneeId: string; assignerId: string; priority: string; status: string
  startDate: string | null; dueDate: string | null; completedAt: string | null; progress: number
  targetQty: number; actualQty: number; unit: string; location: string; notes: string
}
export interface WbsTask {
  id: string; wbsCode: string; name: string; discipline: string; subDiscipline: string
  parentId: string; level: number; order: number; startDate: string; endDate: string; duration: number
  progress: number; plannedProgress: number; weight: number; predecessors: string; resources: string
  assigneeId: string; isMilestone: boolean; criticalPath: boolean; status: string; budget: number
  actualCost: number; notes: string
}
export interface QuantityItem {
  id: string; name: string; discipline: string; subDiscipline: string; unit: string
  plannedQty: number; installedQty: number; location: string; area: string
  startDate: string | null; endDate: string | null; status: string; notes: string
}
export interface FabricationItem {
  id: string; name: string; drawingNo: string; discipline: string; material: string; unit: string
  totalQty: number; cutQty: number; fitUpQty: number; weldedQty: number; ndtQty: number
  paintedQty: number; deliveredQty: number; workshop: string; status: string; notes: string
}
export interface EquipmentDelivery {
  id: string; equipmentName: string; tagNo: string; discipline: string; supplier: string
  qty: number; unit: string; status: string; plannedDate: string | null; actualDate: string | null
  storageLocation: string; notes: string
}
export interface DailyReport {
  id: string; employeeId: string; role: string; discipline: string; date: string; activities: string
  achievements: string; issues: string; planTomorrow: string; weather: string; manpowerCount: number
  workHours: number; status: string; reviewedBy: string; reviewNotes: string
}
export interface WeeklyReport {
  id: string; employeeId: string; role: string; type: string; weekStart: string; weekEnd: string
  achievements: string; issues: string; nextWeekPlan: string; progressSummary: string; status: string
}
export interface ProjectDocument {
  id: string; title: string; docNo: string; type: string; discipline: string; phase: string
  content: string; version: string; status: string; authorId: string; approvedBy: string
  validFrom: string | null; validTo: string | null; notes: string
}
export interface KpiRecord {
  id: string; employeeId: string; period: string; periodStart: string; periodEnd: string
  attendanceScore: number; taskScore: number; disciplineScore: number; qualityScore: number
  safetyScore: number; overallScore: number; notes: string
}
export interface AiSummary {
  id: string; employeeId: string; scope: string; role: string; periodStart: string; periodEnd: string
  title: string; content: string; createdAt: string
}
export interface DrawingFileMeta {
  id: string; projectId: string; title: string; drawingNo: string; discipline: string
  fileType: string; fileName: string; mimeType: string; sizeKb: number; notes: string
  createdAt: string; updatedAt: string
}
export interface DrawingFile extends DrawingFileMeta { fileData?: string }
export interface DrawingZone {
  id: string; projectId: string; name: string; code: string; description: string
  discipline: string; status: string; color: string; createdAt: string; updatedAt: string
}
export interface DrawingMark {
  id: string; projectId: string; drawingId: string; type: string; color: string
  strokeWidth: number; points: string; text: string; zoneId: string; author: string
  createdAt: string; updatedAt: string
}
export interface DashboardData {
  headcount: { total: number; byRole: Record<string, number>; byDisc: Record<string, number> }
  attendance: { today: number; presentToday: number; lateToday: number; absentToday: number; avgPpe: number; avgMood: number; leaveToday: number }
  trend: { date: string; present: number; ppe: number; mood: number }[]
  taskStats: { total: number; pending: number; inProgress: number; completed: number; delayed: number; overdue: number }
  progress: { actualProgress: number; plannedProgress: number; discProgress: { discipline: string; actual: number; planned: number; count: number }[]; deviation: number }
  qtyStats: { discipline: string; items: number; avgPct: number }[]
  fabTotal: number; fabProgress: number
  eqStats: { total: number; arrived: number; delayed: number }
  reportsToday: number
  topPerformers: { id: string; name: string; role: string; score: number }[]
  lowPerformers: { id: string; name: string; role: string; score: number }[]
  zeroAccidentDays: number
}
export interface PhotoAnalysis {
  faceDetected: boolean
  ppe: { helmet: boolean; vest: boolean; gloves: boolean; boots: boolean; goggles: boolean }
  ppeScore: number; ppeNotes: string
  emotion: string; moodScore: number; aiNotes: string
}
export interface SuggestedTask {
  name: string; discipline: string; subDiscipline: string; duration: number
  after?: string[]; resources?: string; weight?: number
}
export type Store = {
  employees: Employee[]; attendance: Attendance[]; tasks: WorkTask[]; wbs: WbsTask[]
  quantities: QuantityItem[]; fabrications: FabricationItem[]; equipment: EquipmentDelivery[]
  dailyReports: DailyReport[]; weeklyReports: WeeklyReport[]; documents: ProjectDocument[]
  kpi: KpiRecord[]; summaries: AiSummary[]; zones: DrawingZone[]
}
