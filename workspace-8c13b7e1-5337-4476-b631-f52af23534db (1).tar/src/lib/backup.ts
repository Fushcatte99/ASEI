import { db } from '@/lib/db'
import { sanitize } from '@/lib/crud'

// ============ Backup / Restore data proyek (simpan & upload file lokal) ============
// Semua data proyek tersimpan di DB (media inline base64), jadi satu payload JSON = backup lengkap:
// info proyek + branding, tenaga kerja, absensi (+foto AI), task, WBS/Gantt, progress,
// laporan harian/mingguan, dokumen, KPI, AI summary, zona, gambar (CAD/PDF/PNG) & marking.

export const BACKUP_FORMAT = 'ASEI-PROJECT-BACKUP'
export const BACKUP_VERSION = 1

const MAX_MEDIA_CHARS = 14_000_000 // batas aman per media base64 (~10MB)

type DelegateLike = {
  create: (args: { data: Record<string, unknown> }) => Promise<Record<string, unknown>>
  update: (args: { where: { id: string }; data: Record<string, unknown> }) => Promise<unknown>
}

interface TableDef {
  key: string // resource key (whitelist sanitizer di lib/crud)
  model: keyof typeof db
  dates: string[] // field DateTime wajib (invalid -> now)
  datesNull: string[] // field DateTime? (invalid -> null)
  employeeFks?: string[] // field yang menunjuk Employee.id
  selfRef?: string // field self-reference (managerId / parentId)
  noUpdatedAt?: boolean // model tanpa field updatedAt (mis. AiSummary)
}

const BACKUP_TABLES: TableDef[] = [
  { key: 'employees', model: 'employee', dates: ['joinDate'], datesNull: ['inductionDate'], selfRef: 'managerId' },
  { key: 'attendance', model: 'attendance', dates: ['date'], datesNull: ['checkIn', 'checkOut'], employeeFks: ['employeeId'] },
  { key: 'tasks', model: 'workTask', dates: [], datesNull: ['startDate', 'dueDate', 'completedAt'], employeeFks: ['assigneeId', 'assignerId'] },
  // CATATAN: WbsTask.parentId TIDAK self-ref ke id — isinya wbsCode fase induk ("1".."8")
  // yang ikut ter-copy apa adanya, jadi tidak diremap (lihat view Planning)
  { key: 'wbs', model: 'wbsTask', dates: ['startDate', 'endDate'], datesNull: [], employeeFks: ['assigneeId'] },
  { key: 'quantities', model: 'quantityItem', dates: [], datesNull: ['startDate', 'endDate'] },
  { key: 'fabrications', model: 'fabricationItem', dates: [], datesNull: [] },
  { key: 'equipment', model: 'equipmentDelivery', dates: [], datesNull: ['plannedDate', 'actualDate'] },
  { key: 'daily-reports', model: 'dailyReport', dates: ['date'], datesNull: [], employeeFks: ['employeeId'] },
  { key: 'weekly-reports', model: 'weeklyReport', dates: ['weekStart', 'weekEnd'], datesNull: [], employeeFks: ['employeeId'] },
  { key: 'documents', model: 'projectDocument', dates: [], datesNull: ['validFrom', 'validTo'], employeeFks: ['authorId'] },
  { key: 'kpi', model: 'kpiRecord', dates: ['periodStart', 'periodEnd'], datesNull: [], employeeFks: ['employeeId'] },
  { key: 'summaries', model: 'aiSummary', dates: ['periodStart', 'periodEnd'], datesNull: [], employeeFks: ['employeeId'], noUpdatedAt: true },
  { key: 'zones', model: 'drawingZone', dates: [], datesNull: [] },
]

function manyOf(model: keyof typeof db) {
  return db[model] as unknown as {
    findMany: (args?: Record<string, unknown>) => Promise<Record<string, unknown>[]>
  }
}

function txDelegate(tx: unknown, model: keyof typeof db): DelegateLike {
  return (tx as Record<string, Record<string, unknown>>)[model as string] as unknown as DelegateLike
}

function toDate(v: unknown): Date | null {
  if (!v) return null
  const d = new Date(String(v))
  return isNaN(d.getTime()) ? null : d
}

function strOrNull(v: unknown, max: number): string | null {
  const s = String(v ?? '').trim()
  if (!s) return null
  return s.length > max ? null : s
}

// ============ Ekspor: muat seluruh data satu proyek jadi satu payload ============
export async function loadBackupPayload(projectId: string) {
  const project = await db.project.findUnique({ where: { id: projectId } })
  if (!project) return null
  const results = await Promise.all([
    ...BACKUP_TABLES.map(t => manyOf(t.model).findMany({ where: { projectId } })),
    db.drawingFile.findMany({ where: { projectId } }) as unknown as Promise<Record<string, unknown>[]>,
    db.drawingMark.findMany({ where: { projectId } }) as unknown as Promise<Record<string, unknown>[]>,
  ])
  const data: Record<string, Record<string, unknown>[]> = {}
  BACKUP_TABLES.forEach((t, i) => { data[t.key] = results[i] ?? [] })
  data.drawings = results[BACKUP_TABLES.length] ?? []
  data.marks = results[BACKUP_TABLES.length + 1] ?? []
  const counts: Record<string, number> = {}
  for (const [k, rows] of Object.entries(data)) counts[k] = rows.length
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    project,
    counts,
    data,
  }
}

// ============ Impor: pulihkan payload jadi proyek BARU (remap semua ID) ============
// - Selalu membuat proyek baru (isDefault=false) sehingga backup bisa diimpor berkali-kali
// - Semua ID baris dibuat ulang oleh Prisma; referensi FK dipetakan ulang otomatis
// - NIP karyawan unik global: bila bentrok dengan proyek lain otomatis disuffix
// - UserAccount tidak disentuh (bukan data proyek & berisi hash password)
export async function restoreProjectBackup(payload: unknown) {
  if (!payload || typeof payload !== 'object') throw new Error('File backup tidak valid')
  const p = payload as { format?: string; version?: number; project?: Record<string, unknown>; data?: Record<string, unknown> }
  if (p.format !== BACKUP_FORMAT || !p.project || typeof p.project !== 'object' || !p.data || typeof p.data !== 'object') {
    throw new Error('File backup tidak dikenali (bukan hasil "Simpan Proyek ke Folder Lokal" ASEI HR)')
  }
  const src = p.project
  const data = p.data as Record<string, unknown>

  // Nama unik: kalau sudah ada proyek dengan nama sama, tambah suffix
  const baseName = String(src.name ?? '').trim() || 'Proyek Impor'
  const existingNames = new Set((await db.project.findMany({ select: { name: true } })).map(x => x.name.toLowerCase()))
  let name = baseName
  let ctr = 1
  while (existingNames.has(name.toLowerCase())) { ctr++; name = `${baseName} (Impor ${ctr})` }

  const statusOk = ['PLANNING', 'ACTIVE', 'ON_HOLD', 'CLOSED'].includes(String(src.status ?? ''))

  const result = await db.$transaction(async tx => {
    const project = await tx.project.create({
      data: {
        code: String(src.code ?? '').slice(0, 60),
        name,
        client: String(src.client ?? '').slice(0, 200),
        location: String(src.location ?? '').slice(0, 200),
        description: String(src.description ?? '').slice(0, 5000),
        status: statusOk ? String(src.status) : 'ACTIVE',
        startDate: toDate(src.startDate),
        endDate: toDate(src.endDate),
        isDefault: false,
        brandLogo: strOrNull(src.brandLogo, 700_000),
        brandFavicon: strOrNull(src.brandFavicon, 700_000),
        brandAppName: strOrNull(src.brandAppName, 200),
        brandTeamName: strOrNull(src.brandTeamName, 200),
        createdAt: toDate(src.createdAt) ?? new Date(),
        updatedAt: toDate(src.updatedAt) ?? new Date(),
      },
    })
    const pid = project.id
    const maps: Record<string, Record<string, string>> = {}

    // NIP harus unik global — kumpulkan yang sudah terpakai
    const nipSet = new Set((await tx.employee.findMany({ select: { nip: true } })).map(x => x.nip))

    for (const t of BACKUP_TABLES) {
      const rows = Array.isArray(data[t.key]) ? (data[t.key] as Record<string, unknown>[]) : []
      maps[t.key] = {}
      const delegate = txDelegate(tx, t.model)
      let idx = 0
      for (const row of rows) {
        idx++
        if (!row || typeof row !== 'object' || !row.id) continue
        const clean = sanitize(t.key, row) // whitelist field per modul
        for (const k of t.dates) clean[k] = toDate(clean[k]) ?? new Date()
        for (const k of t.datesNull) clean[k] = toDateOrNullSafe(clean[k])
        clean.createdAt = toDate(row.createdAt) ?? new Date()
        clean.updatedAt = t.noUpdatedAt ? undefined : (toDate(row.updatedAt) ?? (clean.createdAt as Date))
        if (t.noUpdatedAt) delete clean.updatedAt
        for (const fk of t.employeeFks ?? []) clean[fk] = maps.employees[String(clean[fk] ?? '')] ?? ''
        clean.projectId = pid
        if (t.selfRef) clean[t.selfRef] = '' // diisi pass-2 setelah semua id baru ada
        if (t.key === 'employees') {
          let nip = String(clean.nip ?? '').trim()
          if (!nip) nip = `IMP-${Date.now()}-${idx}`
          let k = 1
          while (nipSet.has(nip)) { k++; nip = `${String(clean.nip ?? 'IMP').slice(0, 40)}-${k}` }
          nipSet.add(nip)
          clean.nip = nip
        }
        const created = await delegate.create({ data: clean })
        maps[t.key][String(row.id)] = String(created.id)
      }
    }

    // Pass 2: self-reference (managerId karyawan, parentId WBS)
    for (const t of BACKUP_TABLES.filter(x => x.selfRef)) {
      const rows = Array.isArray(data[t.key]) ? (data[t.key] as Record<string, unknown>[]) : []
      const map = maps[t.key]
      const delegate = txDelegate(tx, t.model)
      for (const row of rows) {
        const nid = map[String(row?.id ?? '')]
        const old = String(row?.[t.selfRef as string] ?? '')
        if (!nid || !old || !map[old]) continue
        await delegate.update({ where: { id: nid }, data: { [t.selfRef as string]: map[old] } })
      }
    }

    // Gambar proyek (CAD/PDF/PNG base64) — whitelist manual (tidak ada di SCHEMA crud)
    const drawings = Array.isArray(data.drawings) ? (data.drawings as Record<string, unknown>[]) : []
    maps.drawings = {}
    for (const row of drawings) {
      if (!row || typeof row !== 'object' || !row.id) continue
      const created = await tx.drawingFile.create({
        data: {
          projectId: pid,
          title: String(row.title ?? 'Gambar Proyek').slice(0, 200),
          drawingNo: String(row.drawingNo ?? '').slice(0, 100),
          discipline: String(row.discipline ?? 'GENERAL'),
          fileType: ['IMAGE', 'PDF', 'CAD'].includes(String(row.fileType)) ? String(row.fileType) : 'IMAGE',
          fileName: String(row.fileName ?? '').slice(0, 200),
          mimeType: String(row.mimeType ?? '').slice(0, 100),
          fileData: typeof row.fileData === 'string' ? row.fileData.slice(0, MAX_MEDIA_CHARS) : '',
          sizeKb: Number(row.sizeKb) || 0,
          notes: String(row.notes ?? '').slice(0, 2000),
          createdAt: toDate(row.createdAt) ?? new Date(),
          updatedAt: toDate(row.updatedAt) ?? new Date(),
        },
      })
      maps.drawings[String(row.id)] = String(created.id)
    }

    // Marking/anotasi gambar (FK -> drawing & zone baru)
    const marks = Array.isArray(data.marks) ? (data.marks as Record<string, unknown>[]) : []
    maps.marks = {}
    for (const row of marks) {
      if (!row || typeof row !== 'object' || !row.id) continue
      const clean = sanitize('marks', row)
      clean.projectId = pid
      clean.drawingId = maps.drawings[String(clean.drawingId ?? '')] ?? ''
      clean.zoneId = maps.zones[String(clean.zoneId ?? '')] ?? ''
      clean.createdAt = toDate(row.createdAt) ?? new Date()
      clean.updatedAt = toDate(row.updatedAt) ?? (clean.createdAt as Date)
      const created = await tx.drawingMark.create({ data: clean })
      maps.marks[String(row.id)] = String(created.id)
    }

    const stats: Record<string, number> = { employees: 0, attendance: 0, tasks: 0, wbs: 0, drawings: 0, marks: 0 }
    for (const k of Object.keys(maps)) stats[k] = Object.keys(maps[k]).length
    return { project, stats }
  }, { timeout: 120_000, maxWait: 15_000 })

  return {
    id: String(result.project.id),
    name: String(result.project.name),
    stats: result.stats,
  }
}

function toDateOrNullSafe(v: unknown): Date | null {
  if (v === null || v === undefined || v === '') return null
  const d = new Date(String(v))
  return isNaN(d.getTime()) ? null : d
}
