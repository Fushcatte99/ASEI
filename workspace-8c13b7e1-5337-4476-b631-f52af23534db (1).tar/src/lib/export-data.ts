// Loader data + builder CSV untuk export modul (server only)
import { db } from '@/lib/db'

type Row = (string | number)[]
interface Dataset { labels: string[]; rows: Row[] }
type Loader = (projectId: string) => Promise<Dataset>

// ---------- helpers ----------
const s = (v: unknown): string => v === null || v === undefined ? '' : String(v)
const dt = (v: unknown): string => {
  if (!v) return ''
  const d = new Date(v as string)
  if (isNaN(d.getTime())) return ''
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}
const dOnly = (v: unknown): string => dt(v).slice(0, 10)
const yn = (v: unknown): string => v ? 'Ya' : 'Tidak'

function csvEscape(v: string | number): string {
  const str = String(v)
  return /[",\n\r]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str
}
export function toCsv(labels: string[], rows: Row[]): string {
  const head = labels.map(csvEscape).join(',')
  const body = rows.map(r => r.map(csvEscape).join(',')).join('\n')
  return '\uFEFF' + head + '\n' + body + '\n'
}

async function empMap(projectId: string): Promise<Map<string, { name: string; nip: string; role: string }>> {
  const emps = await db.employee.findMany({ where: { projectId }, select: { id: true, name: true, nip: true, role: true } })
  return new Map(emps.map(e => [e.id, { name: e.name, nip: e.nip, role: e.role }]))
}
const emp = (m: Map<string, { name: string; nip: string; role: string }>, id: string, field: 'name' | 'nip' | 'role' = 'name'): string =>
  (id && m.get(id)?.[field]) || ''

// ---------- loaders ----------
const LOADERS: Record<string, Loader> = {
  ringkasan: async (projectId) => {
    const p = await db.project.findUnique({ where: { id: projectId } })
    const [empCount, attCount, taskCount, wbsCount, qtyCount, fabCount, eqCount, docCount, dhCount, dwCount, zoneCount, kpiCount] = await Promise.all([
      db.employee.count({ where: { projectId } }),
      db.attendance.count({ where: { projectId } }),
      db.workTask.count({ where: { projectId } }),
      db.wbsTask.count({ where: { projectId } }),
      db.quantityItem.count({ where: { projectId } }),
      db.fabricationItem.count({ where: { projectId } }),
      db.equipmentDelivery.count({ where: { projectId } }),
      db.projectDocument.count({ where: { projectId } }),
      db.dailyReport.count({ where: { projectId } }),
      db.drawingFile.count({ where: { projectId } }),
      db.drawingZone.count({ where: { projectId } }),
      db.kpiRecord.count({ where: { projectId } }),
    ])
    const taskByStatus = await db.workTask.groupBy({ by: ['status'], where: { projectId }, _count: true })
    const wbsAvg = await db.wbsTask.aggregate({ where: { projectId }, _avg: { progress: true } })
    const labels = ['Keterangan', 'Nilai']
    const rows: Row[] = [
      ['Kode Proyek', s(p?.code)], ['Nama Proyek', s(p?.name)], ['Client', s(p?.client)],
      ['Lokasi', s(p?.location)], ['Status Proyek', s(p?.status)],
      ['Tanggal Mulai', dOnly(p?.startDate)], ['Tanggal Selesai', dOnly(p?.endDate)],
      ['Total Karyawan', empCount], ['Total Record Absensi', attCount],
      ['Total Work Task', taskCount],
      ...taskByStatus.map(t => [`Work Task — ${t.status}`, t._count]),
      ['Rata-rata Progres WBS (%)', Math.round((wbsAvg._avg.progress ?? 0) * 10) / 10],
      ['Total Task WBS/Gantt', wbsCount], ['Item Quantity', qtyCount], ['Item Fabrikasi', fabCount],
      ['Equipment', eqCount], ['Dokumen Proyek', docCount], ['Laporan Harian', dhCount],
      ['Gambar Proyek', dwCount], ['Zona Pekerjaan', zoneCount], ['Record KPI', kpiCount],
      ['Diekspor pada', dt(new Date())],
    ]
    return { labels, rows }
  },

  absensi: async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.attendance.findMany({ where: { projectId }, orderBy: [{ date: 'desc' }] }),
      empMap(projectId),
    ])
    const apd = (json: string): string => {
      try {
        const o = JSON.parse(json || '{}') as Record<string, boolean>
        const names: Record<string, string> = { helmet: 'Helm', vest: 'Rompi', gloves: 'Sarung Tangan', boots: 'Sepatu', goggles: 'Kacamata', mask: 'Masker' }
        return Object.entries(o).filter(([, v]) => v).map(([k]) => names[k] ?? k).join(', ')
      } catch { return '' }
    }
    return {
      labels: ['Tanggal', 'NIP', 'Nama', 'Status', 'Jam Masuk', 'Jam Keluar', 'Menit Terlambat', 'Jam Kerja', 'Skor APD', 'APD Terdeteksi', 'Emosi', 'Skor Mood', 'Catatan AI', 'Lokasi', 'Catatan'],
      rows: rows0.map(r => [
        dOnly(r.date), emp(em, r.employeeId, 'nip'), emp(em, r.employeeId), s(r.status),
        dt(r.checkIn), dt(r.checkOut), r.lateMinutes, r.workHours, r.ppeScore, apd(r.ppeDetails),
        s(r.emotion), r.moodScore, s(r.aiNotes), s(r.location), s(r.notes),
      ]),
    }
  },

  'tenaga-kerja': async (projectId) => {
    const rows0 = await db.employee.findMany({ where: { projectId }, orderBy: { nip: 'asc' } })
    let skills: string[] = []
    return {
      labels: ['NIP', 'Nama', 'Role', 'Disiplin', 'Sub Disiplin', 'Posisi', 'Telepon', 'Email', 'Tanggal Masuk', 'Status', 'Induksi K3', 'Skor Induksi', 'Status APD', 'Keahlian', 'Catatan'],
      rows: rows0.map(r => {
        try { skills = JSON.parse(r.skills || '[]') as string[] } catch { skills = [] }
        return [
          r.nip, r.name, r.role, r.discipline, r.subDiscipline, r.position, r.phone, r.email,
          dOnly(r.joinDate), r.status, yn(r.safetyInduction), r.inductionScore, r.apdStatus, skills.join(', '), r.notes,
        ]
      }),
    }
  },

  'work-task': async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.workTask.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } }),
      empMap(projectId),
    ])
    return {
      labels: ['Judul', 'Deskripsi', 'Disiplin', 'Sub Disiplin', 'Kategori', 'Penerima', 'Pemberi Tugas', 'Prioritas', 'Status', 'Progress (%)', 'Mulai', 'Deadline', 'Selesai Pada', 'Target Qty', 'Realisasi Qty', 'Satuan', 'Lokasi', 'Catatan'],
      rows: rows0.map(r => [
        r.title, r.description, r.discipline, r.subDiscipline, r.category,
        emp(em, r.assigneeId), emp(em, r.assignerId), r.priority, r.status, r.progress,
        dOnly(r.startDate), dOnly(r.dueDate), dt(r.completedAt), r.targetQty, r.actualQty, r.unit, r.location, r.notes,
      ]),
    }
  },

  quantity: async (projectId) => {
    const rows0 = await db.quantityItem.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } })
    return {
      labels: ['Nama Item', 'Disiplin', 'Sub Disiplin', 'Satuan', 'Qty Rencana', 'Qty Terpasang', 'Progres (%)', 'Lokasi', 'Area', 'Mulai', 'Selesai', 'Status', 'Catatan'],
      rows: rows0.map(r => [
        r.name, r.discipline, r.subDiscipline, r.unit, r.plannedQty, r.installedQty,
        r.plannedQty > 0 ? Math.round((r.installedQty / r.plannedQty) * 1000) / 10 : 0,
        r.location, r.area, dOnly(r.startDate), dOnly(r.endDate), r.status, r.notes,
      ]),
    }
  },

  fabrikasi: async (projectId) => {
    const rows0 = await db.fabricationItem.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } })
    return {
      labels: ['Nama', 'No Gambar', 'Disiplin', 'Material', 'Satuan', 'Total Qty', 'Cutting', 'Fit-Up', 'Welding', 'NDT', 'Painting', 'Terkirim', 'Workshop', 'Status', 'Catatan'],
      rows: rows0.map(r => [
        r.name, r.drawingNo, r.discipline, r.material, r.unit, r.totalQty, r.cutQty, r.fitUpQty,
        r.weldedQty, r.ndtQty, r.paintedQty, r.deliveredQty, r.workshop, r.status, r.notes,
      ]),
    }
  },

  equipment: async (projectId) => {
    const rows0 = await db.equipmentDelivery.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } })
    return {
      labels: ['Nama Equipment', 'Tag No', 'Disiplin', 'Supplier', 'Qty', 'Satuan', 'Status', 'Tgl Rencana', 'Tgl Aktual', 'Lokasi Penyimpanan', 'Catatan'],
      rows: rows0.map(r => [
        r.equipmentName, r.tagNo, r.discipline, r.supplier, r.qty, r.unit, r.status,
        dOnly(r.plannedDate), dOnly(r.actualDate), r.storageLocation, r.notes,
      ]),
    }
  },

  'planning-wbs': async (projectId) => {
    const rows0 = await db.wbsTask.findMany({ where: { projectId }, orderBy: [{ order: 'asc' }, { startDate: 'asc' }] })
    return {
      labels: ['Kode WBS', 'Nama', 'Level', 'Disiplin', 'Sub Disiplin', 'Mulai', 'Selesai', 'Durasi (hari)', 'Progres Aktual (%)', 'Progres Rencana (%)', 'Bobot (%)', 'Milestone', 'Critical Path', 'Status', 'Resource', 'Budget', 'Realisasi Biaya', 'Catatan'],
      rows: rows0.map(r => [
        r.wbsCode, r.name, r.level, r.discipline, r.subDiscipline, dOnly(r.startDate), dOnly(r.endDate),
        r.duration, r.progress, r.plannedProgress, r.weight, yn(r.isMilestone), yn(r.criticalPath),
        r.status, r.resources, r.budget, r.actualCost, r.notes,
      ]),
    }
  },

  gambar: async (projectId) => {
    const rows0 = await db.drawingFile.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' }, select: { title: true, drawingNo: true, discipline: true, fileType: true, fileName: true, sizeKb: true, notes: true, createdAt: true } })
    return {
      labels: ['Judul', 'No Gambar', 'Disiplin', 'Tipe File', 'Nama File', 'Ukuran (KB)', 'Catatan', 'Diupload'],
      rows: rows0.map(r => [r.title, r.drawingNo, r.discipline, r.fileType, r.fileName, r.sizeKb, r.notes, dt(r.createdAt)]),
    }
  },

  zona: async (projectId) => {
    const rows0 = await db.drawingZone.findMany({ where: { projectId }, orderBy: { createdAt: 'asc' } })
    return {
      labels: ['Nama Zona', 'Kode', 'Disiplin', 'Status', 'Warna', 'Deskripsi'],
      rows: rows0.map(r => [r.name, r.code, r.discipline, r.status, r.color, r.description]),
    }
  },

  'laporan-harian': async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.dailyReport.findMany({ where: { projectId }, orderBy: [{ date: 'desc' }] }),
      empMap(projectId),
    ])
    return {
      labels: ['Tanggal', 'NIP', 'Nama', 'Role', 'Disiplin', 'Aktivitas', 'Pencapaian', 'Kendala', 'Rencana Besok', 'Cuaca', 'Manpower', 'Jam Kerja', 'Status', 'Review Oleh', 'Catatan Review'],
      rows: rows0.map(r => [
        dOnly(r.date), emp(em, r.employeeId, 'nip'), emp(em, r.employeeId), r.role, r.discipline,
        r.activities, r.achievements, r.issues, r.planTomorrow, r.weather, r.manpowerCount,
        r.workHours, r.status, r.reviewedBy, r.reviewNotes,
      ]),
    }
  },

  'laporan-mingguan': async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.weeklyReport.findMany({ where: { projectId }, orderBy: [{ weekStart: 'desc' }] }),
      empMap(projectId),
    ])
    return {
      labels: ['Tipe', 'Minggu Mulai', 'Minggu Selesai', 'NIP', 'Nama', 'Role', 'Pencapaian', 'Kendala', 'Rencana Minggu Depan', 'Ringkasan Progres', 'Status'],
      rows: rows0.map(r => [
        r.type, dOnly(r.weekStart), dOnly(r.weekEnd), emp(em, r.employeeId, 'nip'), emp(em, r.employeeId),
        r.role, r.achievements, r.issues, r.nextWeekPlan, r.progressSummary, r.status,
      ]),
    }
  },

  dokumen: async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.projectDocument.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } }),
      empMap(projectId),
    ])
    return {
      labels: ['Judul', 'No Dokumen', 'Tipe', 'Disiplin', 'Fase', 'Versi', 'Status', 'Penulis', 'Disetujui Oleh', 'Berlaku Dari', 'Berlaku Sampai', 'Catatan'],
      rows: rows0.map(r => [
        r.title, r.docNo, r.type, r.discipline, r.phase, r.version, r.status,
        emp(em, r.authorId), r.approvedBy, dOnly(r.validFrom), dOnly(r.validTo), r.notes,
      ]),
    }
  },

  kpi: async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.kpiRecord.findMany({ where: { projectId }, orderBy: [{ periodStart: 'desc' }] }),
      empMap(projectId),
    ])
    return {
      labels: ['NIP', 'Nama', 'Periode', 'Mulai', 'Akhir', 'Skor Kehadiran', 'Skor Disiplin', 'Skor Keselamatan', 'Skor Task', 'Skor Kualitas', 'Skor Akhir', 'Catatan'],
      rows: rows0.map(r => [
        emp(em, r.employeeId, 'nip'), emp(em, r.employeeId), r.period, dOnly(r.periodStart), dOnly(r.periodEnd),
        r.attendanceScore, r.disciplineScore, r.safetyScore, r.taskScore, r.qualityScore, r.overallScore, r.notes,
      ]),
    }
  },

  'ai-summary': async (projectId) => {
    const [rows0, em] = await Promise.all([
      db.aiSummary.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } }),
      empMap(projectId),
    ])
    return {
      labels: ['Judul', 'Cakupan', 'Filter Role', 'Periode Mulai', 'Periode Akhir', 'Karyawan', 'Konten', 'Dibuat'],
      rows: rows0.map(r => [
        r.title, r.scope, r.role, dOnly(r.periodStart), dOnly(r.periodEnd),
        emp(em, r.employeeId), r.content, dt(r.createdAt),
      ]),
    }
  },
}

export { LOADERS }
