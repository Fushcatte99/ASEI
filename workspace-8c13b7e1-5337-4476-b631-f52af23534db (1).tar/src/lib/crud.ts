import { db } from '@/lib/db'

// Generic CRUD registry + field sanitizer (whitelist per resource)
type FieldType = 'string' | 'number' | 'boolean' | 'date' | 'dateOrNull' | 'json'

export const SCHEMA: Record<string, Record<string, FieldType>> = {
  employees: {
    projectId: 'string', nip: 'string', name: 'string', role: 'string', discipline: 'string', subDiscipline: 'string',
    position: 'string', managerId: 'string', phone: 'string', email: 'string', joinDate: 'date',
    status: 'string', avatarColor: 'string', safetyInduction: 'boolean', inductionDate: 'dateOrNull',
    inductionScore: 'number', apdStatus: 'string', apdItems: 'json', skills: 'json', notes: 'string',
  },
  attendance: {
    projectId: 'string', employeeId: 'string', date: 'date', checkIn: 'dateOrNull', checkOut: 'dateOrNull',
    checkInPhoto: 'string', checkOutPhoto: 'string', location: 'string', status: 'string',
    lateMinutes: 'number', workHours: 'number', ppeScore: 'number', ppeDetails: 'json',
    ppeNotes: 'string', emotion: 'string', moodScore: 'number', aiNotes: 'string',
    aiAnalyzed: 'boolean', notes: 'string',
  },
  tasks: {
    projectId: 'string', title: 'string', description: 'string', discipline: 'string', subDiscipline: 'string',
    category: 'string', assigneeId: 'string', assignerId: 'string', priority: 'string',
    status: 'string', startDate: 'dateOrNull', dueDate: 'dateOrNull', completedAt: 'dateOrNull',
    progress: 'number', targetQty: 'number', actualQty: 'number', unit: 'string',
    location: 'string', notes: 'string',
  },
  wbs: {
    projectId: 'string', wbsCode: 'string', name: 'string', discipline: 'string', subDiscipline: 'string',
    parentId: 'string', level: 'number', order: 'number', startDate: 'date', endDate: 'date',
    duration: 'number', progress: 'number', plannedProgress: 'number', weight: 'number',
    predecessors: 'json', resources: 'string', assigneeId: 'string', isMilestone: 'boolean',
    criticalPath: 'boolean', status: 'string', budget: 'number', actualCost: 'number', notes: 'string',
  },
  quantities: {
    projectId: 'string', name: 'string', discipline: 'string', subDiscipline: 'string', unit: 'string',
    plannedQty: 'number', installedQty: 'number', location: 'string', area: 'string',
    startDate: 'dateOrNull', endDate: 'dateOrNull', status: 'string', notes: 'string',
  },
  fabrications: {
    projectId: 'string', name: 'string', drawingNo: 'string', discipline: 'string', material: 'string', unit: 'string',
    totalQty: 'number', cutQty: 'number', fitUpQty: 'number', weldedQty: 'number', ndtQty: 'number',
    paintedQty: 'number', deliveredQty: 'number', workshop: 'string', status: 'string', notes: 'string',
  },
  equipment: {
    projectId: 'string', equipmentName: 'string', tagNo: 'string', discipline: 'string', supplier: 'string',
    qty: 'number', unit: 'string', status: 'string', plannedDate: 'dateOrNull',
    actualDate: 'dateOrNull', storageLocation: 'string', notes: 'string',
  },
  'daily-reports': {
    projectId: 'string', employeeId: 'string', role: 'string', discipline: 'string', date: 'date', activities: 'string',
    achievements: 'string', issues: 'string', planTomorrow: 'string', weather: 'string',
    manpowerCount: 'number', workHours: 'number', status: 'string', reviewedBy: 'string', reviewNotes: 'string',
  },
  'weekly-reports': {
    projectId: 'string', employeeId: 'string', role: 'string', type: 'string', weekStart: 'date', weekEnd: 'date',
    achievements: 'string', issues: 'string', nextWeekPlan: 'string', progressSummary: 'string',
    status: 'string',
  },
  documents: {
    projectId: 'string', title: 'string', docNo: 'string', type: 'string', discipline: 'string', phase: 'string',
    content: 'string', version: 'string', status: 'string', authorId: 'string', approvedBy: 'string',
    validFrom: 'dateOrNull', validTo: 'dateOrNull', notes: 'string',
  },
  kpi: {
    projectId: 'string', employeeId: 'string', period: 'string', periodStart: 'date', periodEnd: 'date',
    attendanceScore: 'number', taskScore: 'number', disciplineScore: 'number', qualityScore: 'number',
    safetyScore: 'number', overallScore: 'number', notes: 'string',
  },
  summaries: {
    projectId: 'string', employeeId: 'string', scope: 'string', role: 'string', periodStart: 'date', periodEnd: 'date',
    title: 'string', content: 'string',
  },
  zones: {
    projectId: 'string', name: 'string', code: 'string', description: 'string', discipline: 'string',
    status: 'string', color: 'string',
  },
  marks: {
    projectId: 'string', drawingId: 'string', type: 'string', color: 'string', strokeWidth: 'number',
    points: 'string', text: 'string', zoneId: 'string', author: 'string',
  },
}

const MODELS: Record<string, keyof typeof db> = {
  employees: 'employee',
  attendance: 'attendance',
  tasks: 'workTask',
  wbs: 'wbsTask',
  quantities: 'quantityItem',
  fabrications: 'fabricationItem',
  equipment: 'equipmentDelivery',
  'daily-reports': 'dailyReport',
  'weekly-reports': 'weeklyReport',
  documents: 'projectDocument',
  kpi: 'kpiRecord',
  summaries: 'aiSummary',
  zones: 'drawingZone',
  marks: 'drawingMark',
}

export function isResource(r: string): boolean {
  return !!SCHEMA[r] && !!MODELS[r]
}

export function modelOf(r: string) {
  return db[MODELS[r]] as unknown as {
    findMany: (args?: Record<string, unknown>) => Promise<unknown[]>
    findUnique: (args: { where: { id: string } }) => Promise<unknown>
    create: (args: { data: Record<string, unknown> }) => Promise<unknown>
    update: (args: { where: { id: string }; data: Record<string, unknown> }) => Promise<unknown>
    delete: (args: { where: { id: string } }) => Promise<unknown>
    deleteMany: () => Promise<unknown>
    createMany: (args: { data: Record<string, unknown>[] }) => Promise<unknown>
  }
}

export function sanitize(resource: string, body: Record<string, unknown>): Record<string, unknown> {
  const schema = SCHEMA[resource]
  if (!schema) throw new Error(`Unknown resource: ${resource}`)
  const out: Record<string, unknown> = {}
  for (const [k, t] of Object.entries(schema)) {
    if (!(k in body)) continue
    const v = body[k]
    if (v === undefined) continue
    if (v === null || v === '') {
      if (t === 'dateOrNull') out[k] = null
      else if (t === 'date') { /* skip empty date */ }
      else if (t === 'number') out[k] = 0
      else if (t === 'boolean') out[k] = false
      else out[k] = ''
      continue
    }
    switch (t) {
      case 'string': out[k] = String(v); break
      case 'number': out[k] = Number(v) || 0; break
      case 'boolean': out[k] = v === true || v === 'true'; break
      case 'date': out[k] = new Date(String(v)); break
      case 'dateOrNull': out[k] = v ? new Date(String(v)) : null; break
      case 'json': out[k] = typeof v === 'string' ? v : JSON.stringify(v); break
    }
  }
  return out
}

// Build Prisma where from query params (equality on schema fields + date ranges)
export function buildWhere(resource: string, sp: URLSearchParams): Record<string, unknown> {
  const schema = SCHEMA[resource]
  const where: Record<string, unknown> = {}
  if (!schema) return where
  for (const [key, val] of sp.entries()) {
    if (!val) continue
    if (key.endsWith('_from') || key.endsWith('_to')) continue
    const t = schema[key]
    if (!t) continue
    if (t === 'string') where[key] = val
    else if (t === 'number') where[key] = Number(val)
    else if (t === 'boolean') where[key] = val === 'true'
    else if (t === 'date') {
      const d = new Date(val)
      if (key.endsWith('Start') || key === 'date' || key === 'weekStart') {
        where[key] = { gte: new Date(new Date(d).setHours(0, 0, 0, 0)) }
      } else where[key] = d
    }
  }
  const dateField = resource === 'attendance' || resource === 'daily-reports' ? 'date'
    : resource === 'weekly-reports' ? 'weekStart' : null
  if (dateField) {
    const from = sp.get(`${dateField}_from`), to = sp.get(`${dateField}_to`)
    const w = where[dateField] as Record<string, unknown> | undefined
    if (from || to) {
      const rng: Record<string, unknown> = { ...(w ?? {}) }
      if (from) rng.gte = new Date(new Date(from).setHours(0, 0, 0, 0))
      if (to) rng.lte = new Date(new Date(to).setHours(23, 59, 59, 999))
      where[dateField] = rng
    }
  }
  return where
}
