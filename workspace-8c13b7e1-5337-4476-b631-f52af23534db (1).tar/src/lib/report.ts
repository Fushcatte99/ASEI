// Registry seksi General Report + utilitas periode — pure data, aman untuk client

export interface ReportSectionDef {
  key: string
  label: string
  desc: string
  group: string
}

export const REPORT_GROUPS = ['Modul Utama', 'Eksekusi Proyek', 'Pelaporan & Kinerja'] as const

export const REPORT_SECTIONS: ReportSectionDef[] = [
  { key: 'ringkasan', label: 'Ringkasan Dashboard', desc: 'Kartu KPI, tren kehadiran, statistik task & progress fisik', group: 'Modul Utama' },
  { key: 'absensi', label: 'Absensi & Kehadiran', desc: 'Rekap status kehadiran, grafik & tabel + skor APD/mood AI', group: 'Modul Utama' },
  { key: 'tenaga-kerja', label: 'Tenaga Kerja', desc: 'Komposisi tim per peran & disiplin + personel kunci', group: 'Modul Utama' },
  { key: 'timeline', label: 'Timeline Proyek', desc: 'Kronologi kegiatan: laporan harian, task selesai, check-in', group: 'Eksekusi Proyek' },
  { key: 'gantt', label: 'Gantt Chart WBS', desc: 'Jadwal seluruh fase dengan progress, bobot & today marker', group: 'Eksekusi Proyek' },
  { key: 'work-task', label: 'Work Task', desc: 'Status pekerjaan, prioritas & progress per penanggung jawab', group: 'Eksekusi Proyek' },
  { key: 'progress-fisik', label: 'Progress Fisik', desc: 'Quantity terpasang, fabrikasi & equipment delivery', group: 'Eksekusi Proyek' },
  { key: 'laporan-harian', label: 'Laporan Harian', desc: 'Aktivitas, kendala & rencana besok per pelapor', group: 'Pelaporan & Kinerja' },
  { key: 'laporan-mingguan', label: 'Laporan Mingguan', desc: 'Ringkasan progres, capaian & rencana minggu depan', group: 'Pelaporan & Kinerja' },
  { key: 'kpi', label: 'KPI Karyawan', desc: 'Peringkat kinerja, top/low performers & tabel KPI lengkap', group: 'Pelaporan & Kinerja' },
  { key: 'dokumen', label: 'Dokumen Proyek', desc: 'SOW/JSA/ITP, versi & status persetujuan', group: 'Pelaporan & Kinerja' },
  { key: 'gambar-zona', label: 'Gambar & Zona', desc: 'Daftar gambar proyek (CAD/PDF/PNG) & status zona pekerjaan', group: 'Pelaporan & Kinerja' },
  { key: 'ai-summary', label: 'AI Summary & Insight', desc: 'Ringkasan analisis & rekomendasi AI untuk proyek', group: 'Pelaporan & Kinerja' },
]

export const DEFAULT_SECTIONS = REPORT_SECTIONS.map(s => s.key)

// ============ Periode ============
export type ReportPeriod = 'full' | 'daily' | 'weekly' | 'monthly'

export interface PeriodRange { start: Date; end: Date; label: string; kind: ReportPeriod }

export function parseDateInput(s: string | null | undefined, fallback = new Date()): Date {
  if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return fallback
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, m - 1, d)
}

export function periodRange(p: ReportPeriod, dateStr: string | null | undefined): PeriodRange | null {
  const anchor = parseDateInput(dateStr)
  if (p === 'full') return null
  if (p === 'daily') {
    const start = new Date(anchor); start.setHours(0, 0, 0, 0)
    const end = new Date(anchor); end.setHours(23, 59, 59, 999)
    return { start, end, kind: p, label: `Harian — ${fmtIDN(start)}` }
  }
  if (p === 'weekly') {
    const start = new Date(anchor); start.setHours(0, 0, 0, 0)
    const dow = (start.getDay() + 6) % 7 // Senin=0
    start.setDate(start.getDate() - dow)
    const end = new Date(start); end.setDate(end.getDate() + 6); end.setHours(23, 59, 59, 999)
    return { start, end, kind: p, label: `Mingguan — ${fmtIDN(start)} s.d. ${fmtIDN(end)}` }
  }
  // monthly
  const start = new Date(anchor.getFullYear(), anchor.getMonth(), 1)
  const end = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0, 23, 59, 59, 999)
  const bulan = start.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })
  return { start, end, kind: p, label: `Bulanan — ${bulan}` }
}

export function fmtIDN(d: Date): string {
  return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })
}

export function inRange(d: string | Date | null | undefined, r: PeriodRange | null): boolean {
  if (!r) return true
  if (!d) return false
  const t = new Date(d).getTime()
  return t >= r.start.getTime() && t <= r.end.getTime()
}

export const PERIOD_LABEL: Record<ReportPeriod, string> = {
  full: 'Laporan Lengkap (Semua Periode)',
  daily: 'Laporan Harian',
  weekly: 'Laporan Mingguan',
  monthly: 'Laporan Bulanan',
}
