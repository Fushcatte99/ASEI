import { db } from '@/lib/db'

// Data contoh ringan (2-3 record per modul) untuk proyek baru — bisa diedit/dihapus user.
export async function createSampleData(projectId: string) {
  const pid = projectId
  const TODAY = new Date()
  const addDays = (n: number) => { const d = new Date(TODAY); d.setDate(d.getDate() + n); return d }
  const APD_FULL = JSON.stringify({ helmet: true, vest: true, gloves: true, boots: true, goggles: true })

  // ============ TENAGA KERJA (3) ============
  const pm = await db.employee.create({ data: {
    projectId: pid, nip: `PM-${Date.now().toString().slice(-6)}`, name: 'Ir. Andi Wijaya', role: 'PM', discipline: 'GENERAL',
    subDiscipline: 'Manajemen', position: 'Project Manager', phone: '0812-3000-0001', email: 'pm@contoh.co.id',
    avatarColor: 'amber', safetyInduction: true, inductionDate: addDays(-30), inductionScore: 90,
    apdStatus: 'COMPLETE', apdItems: APD_FULL, skills: JSON.stringify(['Manajemen Proyek', 'Kurva-S']),
  } })
  const formMe = await db.employee.create({ data: {
    projectId: pid, nip: `FR-${Date.now().toString().slice(-6)}`, name: 'Slamet Riyadi', role: 'FOREMAN', discipline: 'MECHANICAL',
    subDiscipline: 'Piping', position: 'Piping Foreman', phone: '0812-3000-0002', email: 'foreman.me@contoh.co.id',
    managerId: pm.id, avatarColor: 'orange', safetyInduction: true, inductionDate: addDays(-28), inductionScore: 85,
    apdStatus: 'COMPLETE', apdItems: APD_FULL, skills: JSON.stringify(['Pipe Fitting', 'Erection']),
  } })
  const w1 = await db.employee.create({ data: {
    projectId: pid, nip: `WK-${Date.now().toString().slice(-6)}`, name: 'Dedi Kurniawan', role: 'WORKER', discipline: 'CIVIL',
    subDiscipline: 'Carpenter', position: 'Carpenter', phone: '0812-3000-0003', email: 'dedi@contoh.co.id',
    managerId: pm.id, avatarColor: 'emerald', safetyInduction: true, inductionDate: addDays(-25), inductionScore: 80,
    apdStatus: 'COMPLETE', apdItems: APD_FULL, skills: JSON.stringify(['Formwork']),
  } })

  // ============ WBS / PLANNING (3) ============
  await db.wbsTask.createMany({ data: [
    { projectId: pid, wbsCode: '1', name: 'PRELIMINARY & MOBILISASI', discipline: 'GENERAL', level: 1, order: 1,
      startDate: addDays(-14), endDate: addDays(-7), duration: 7, progress: 100, plannedProgress: 100, weight: 10,
      resources: 'PM / Admin', status: 'COMPLETED' },
    { projectId: pid, wbsCode: '1.1', name: 'Kick-off Meeting & Mobilisasi', discipline: 'GENERAL', parentId: '1', level: 2, order: 1,
      startDate: addDays(-14), endDate: addDays(-10), duration: 4, progress: 100, plannedProgress: 100, weight: 5,
      predecessors: JSON.stringify([]), resources: 'PM, Admin', status: 'COMPLETED' },
    { projectId: pid, wbsCode: '1.2', name: 'Safety Induction & Site Setup', discipline: 'GENERAL', parentId: '1', level: 2, order: 2,
      startDate: addDays(-9), endDate: addDays(10), duration: 20, progress: 35, plannedProgress: 50, weight: 5,
      predecessors: JSON.stringify(['1.1']), resources: 'HSE, Civil Crew', status: 'IN_PROGRESS' },
  ] })

  // ============ WORK TASK (3) ============
  await db.workTask.createMany({ data: [
    { projectId: pid, title: 'Survey & marking layout area kerja', description: 'Contoh task: survey topografi ringan dan marking layout sesuai gambar site plan.',
      discipline: 'CIVIL', subDiscipline: 'Earthwork', category: 'INSTALLATION', assigneeId: w1.id, assignerId: pm.id,
      priority: 'HIGH', status: 'IN_PROGRESS', startDate: addDays(-2), dueDate: addDays(3), progress: 60,
      targetQty: 500, actualQty: 300, unit: 'm2', location: 'Area A' },
    { projectId: pid, title: 'Fabrikasi pipe support awal (contoh)', description: 'Contoh task fabrikasi support sesuai shop drawing.',
      discipline: 'MECHANICAL', subDiscipline: 'Fabrikasi Support', category: 'FABRICATION', assigneeId: formMe.id, assignerId: pm.id,
      priority: 'MEDIUM', status: 'PENDING', startDate: addDays(1), dueDate: addDays(7), progress: 0,
      targetQty: 20, actualQty: 0, unit: 'pcs', location: 'Workshop' },
    { projectId: pid, title: 'Susun JSA & permit to work mingguan', description: 'Contoh task administrasi K3: JSA aktivitas minggu ini + pengajuan PTW.',
      discipline: 'GENERAL', subDiscipline: 'K3', category: 'SAFETY', assigneeId: pm.id, assignerId: pm.id,
      priority: 'HIGH', status: 'IN_PROGRESS', startDate: addDays(-1), dueDate: addDays(1), progress: 50,
      targetQty: 2, actualQty: 1, unit: 'dok', location: 'Office' },
  ] })

  // ============ QUANTITY INSTALLED (3) ============
  await db.quantityItem.createMany({ data: [
    { projectId: pid, name: 'Galian tanah (contoh)', discipline: 'CIVIL', subDiscipline: 'Earthwork', unit: 'm3',
      plannedQty: 500, installedQty: 320, location: 'Area A', area: 'Area A', status: 'ON_PROGRESS',
      startDate: addDays(-5), endDate: addDays(15) },
    { projectId: pid, name: 'Erection steel structure (contoh)', discipline: 'MECHANICAL', subDiscipline: 'Steel Erection', unit: 'ton',
      plannedQty: 40, installedQty: 6, location: 'Area A', area: 'Area A', status: 'ON_PROGRESS',
      startDate: addDays(-3), endDate: addDays(25) },
    { projectId: pid, name: 'Instalasi cable tray (contoh)', discipline: 'ELECTRICAL', subDiscipline: 'Cable Tray', unit: 'm',
      plannedQty: 300, installedQty: 0, location: 'Rack A', area: 'Rack A', status: 'NOT_STARTED',
      startDate: addDays(5), endDate: addDays(30) },
  ] })

  // ============ FABRICATION (2) ============
  await db.fabricationItem.createMany({ data: [
    { projectId: pid, name: 'Spool SP-001 (4" CS) contoh', drawingNo: 'ISO-001', discipline: 'MECHANICAL', material: 'A106 Gr.B',
      unit: 'pcs', totalQty: 6, cutQty: 3, fitUpQty: 2, weldedQty: 1, ndtQty: 0, paintedQty: 0, deliveredQty: 0,
      workshop: 'WS-1', status: 'ON_FABRICATION' },
    { projectId: pid, name: 'Support PS-101 contoh', drawingNo: 'SUP-101', discipline: 'MECHANICAL', material: 'A36 Plate',
      unit: 'pcs', totalQty: 12, cutQty: 12, fitUpQty: 8, weldedQty: 6, ndtQty: 0, paintedQty: 4, deliveredQty: 2,
      workshop: 'WS-1', status: 'PAINTING' },
  ] })

  // ============ EQUIPMENT DELIVERY (3) ============
  await db.equipmentDelivery.createMany({ data: [
    { projectId: pid, equipmentName: 'Centrifugal Pump P-101 (contoh)', tagNo: 'P-101', discipline: 'MECHANICAL',
      supplier: 'PT. Pompa Teknik', qty: 1, unit: 'unit', status: 'PO_ISSUED', plannedDate: addDays(14) },
    { projectId: pid, equipmentName: 'Panel MCC-1 (contoh)', tagNo: 'MCC-1', discipline: 'ELECTRICAL',
      supplier: 'PT. Panel Listrik', qty: 1, unit: 'unit', status: 'IN_PRODUCTION', plannedDate: addDays(25) },
    { projectId: pid, equipmentName: 'Globe & Gate Valve Set (contoh)', tagNo: 'VLV-SET1', discipline: 'MECHANICAL',
      supplier: 'PT. Valve Utama', qty: 1, unit: 'set', status: 'ARRIVED', plannedDate: addDays(-4), actualDate: addDays(-3), storageLocation: 'Laydown A' },
  ] })

  // ============ DOKUMEN (3) ============
  await db.projectDocument.createMany({ data: [
    { projectId: pid, title: 'Preliminary Report (contoh)', docNo: 'NEW-PRELIM-001', type: 'PRELIM', discipline: 'GENERAL',
      phase: 'PRELIMINARY', content: 'Contoh dokumen preliminary: hasil survei awal lokasi, kebutuhan mobilisasi, dan rencana tenaga kerja. Edit dokumen ini sesuai kondisi proyek Anda.',
      version: 'A', status: 'DRAFT', authorId: pm.id },
    { projectId: pid, title: 'Statement of Work (contoh)', docNo: 'NEW-SOW-001', type: 'SOW', discipline: 'GENERAL',
      phase: 'ENGINEERING', content: 'Contoh SOW: lingkup pekerjaan Civil, Mechanical, Electrical beserta target completion dan standar kualitas. Edit sesuai kontrak.',
      version: 'A', status: 'IN_REVIEW', authorId: pm.id },
    { projectId: pid, title: 'JSA - Welding (contoh)', docNo: 'NEW-JSA-001', type: 'JSA', discipline: 'MECHANICAL',
      phase: 'EXECUTION', content: 'Contoh JSA pekerjaan las: langkah kerja, bahaya (percikan api, asap), dan kontrol (fire watch, APD las lengkap, ventilasi).',
      version: 'A', status: 'DRAFT', authorId: pm.id },
  ] })

  // ============ ABSENSI HARI INI (3) ============
  await db.attendance.createMany({ data: [
    { projectId: pid, employeeId: pm.id, date: TODAY, checkIn: new Date(new Date().setHours(7, 5, 0, 0)), location: 'Site Utama',
      status: 'PRESENT', workHours: 8, ppeScore: 95, ppeDetails: APD_FULL, emotion: 'happy', moodScore: 85,
      aiNotes: 'Contoh data: APD lengkap, wajah terdeteksi happy.', aiAnalyzed: true },
    { projectId: pid, employeeId: formMe.id, date: TODAY, checkIn: new Date(new Date().setHours(7, 20, 0, 0)), location: 'Workshop',
      status: 'PRESENT', workHours: 8, ppeScore: 90, ppeDetails: APD_FULL, emotion: 'neutral', moodScore: 70,
      aiNotes: 'Contoh data: APD lengkap, wajah terdeteksi netral.', aiAnalyzed: true },
    { projectId: pid, employeeId: w1.id, date: TODAY, checkIn: new Date(new Date().setHours(7, 42, 0, 0)), location: 'Site Utama',
      status: 'LATE', lateMinutes: 12, workHours: 7.5, ppeScore: 75, ppeDetails: JSON.stringify({ helmet: true, vest: true, gloves: false, boots: true, goggles: false }),
      emotion: 'tired', moodScore: 55, aiNotes: 'Contoh data: goggles & gloves tidak terdeteksi.', aiAnalyzed: true },
  ] })

  // ============ LAPORAN HARIAN (2) ============
  await db.dailyReport.createMany({ data: [
    { projectId: pid, employeeId: w1.id, role: 'WORKER', discipline: 'CIVIL', date: TODAY,
      activities: 'Contoh laporan: marking layout area A, bongkar bekas pagarnya sisi timur.',
      achievements: 'Target 60% tercapai.', issues: '-', planTomorrow: 'Lanjut marking sisi utara.',
      weather: 'Cerah', manpowerCount: 1, workHours: 8, status: 'SUBMITTED' },
    { projectId: pid, employeeId: pm.id, role: 'PM', discipline: 'GENERAL', date: addDays(-1),
      activities: 'Contoh laporan PM: koordinasi dengan client, review rencana mingguan.',
      achievements: 'SOW disetujui client.', issues: 'Pengadaan material masih menunggu PO.',
      planTomorrow: 'Follow up PO ke procurement.', weather: 'Cerah', manpowerCount: 3, workHours: 8, status: 'APPROVED' },
  ] })

  // ============ LAPORAN & RENCANA MINGGUAN (2) ============
  const weekStart = new Date(TODAY); weekStart.setDate(weekStart.getDate() - ((TODAY.getDay() + 6) % 7))
  const weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 6)
  await db.weeklyReport.createMany({ data: [
    { projectId: pid, employeeId: pm.id, role: 'PM', type: 'REPORT', weekStart, weekEnd,
      achievements: 'Contoh: mobilisasi selesai, survey layout 60%.', issues: 'Belum ada kendala berarti.',
      nextWeekPlan: 'Contoh: mulai earthwork & fabrikasi support.', progressSummary: 'Progress awal 5%.',
      status: 'SUBMITTED' },
    { projectId: pid, employeeId: formMe.id, role: 'FOREMAN', type: 'PLAN', weekStart, weekEnd,
      achievements: '', issues: '', nextWeekPlan: 'Contoh rencana: siapkan material & tools fabrikasi spool pertama.',
      progressSummary: 'Rencana minggu depan.', status: 'SUBMITTED' },
  ] })

  // ============ KPI BULANAN (3) ============
  const monthStart = new Date(TODAY.getFullYear(), TODAY.getMonth(), 1)
  const monthEnd = new Date(TODAY.getFullYear(), TODAY.getMonth() + 1, 0)
  await db.kpiRecord.createMany({ data: [
    { projectId: pid, employeeId: pm.id, period: 'MONTHLY', periodStart: monthStart, periodEnd: monthEnd,
      attendanceScore: 92, taskScore: 88, disciplineScore: 90, qualityScore: 85, safetyScore: 95, overallScore: 90,
      notes: 'Contoh KPI: performa sangat baik.' },
    { projectId: pid, employeeId: formMe.id, period: 'MONTHLY', periodStart: monthStart, periodEnd: monthEnd,
      attendanceScore: 85, taskScore: 80, disciplineScore: 82, qualityScore: 78, safetyScore: 88, overallScore: 83,
      notes: 'Contoh KPI: performa baik.' },
    { projectId: pid, employeeId: w1.id, period: 'MONTHLY', periodStart: monthStart, periodEnd: monthEnd,
      attendanceScore: 78, taskScore: 72, disciplineScore: 75, qualityScore: 70, safetyScore: 80, overallScore: 75,
      notes: 'Contoh KPI: perlu peningkatan konsistensi.' },
  ] })

  // ============ ZONA PEKERJAAN (3) ============
  await db.drawingZone.createMany({ data: [
    { projectId: pid, name: 'Area A - Ponds & Structure', code: 'ZN-A', discipline: 'CIVIL',
      description: 'Contoh zona: area pondasi & struktur utama. Edit atau hapus sesuai kebutuhan.',
      status: 'ON_PROGRESS', color: '#d97706' },
    { projectId: pid, name: 'Area B - Piping & Equipment', code: 'ZN-B', discipline: 'MECHANICAL',
      description: 'Contoh zona: area instalasi piping dan equipment rotasi.', status: 'PLANNED', color: '#ea580c' },
    { projectId: pid, name: 'Rack Listrik & MCC', code: 'ZN-C', discipline: 'ELECTRICAL',
      description: 'Contoh zona: cable rack, panel MCC, dan transformer.', status: 'PLANNED', color: '#059669' },
  ] })
}
