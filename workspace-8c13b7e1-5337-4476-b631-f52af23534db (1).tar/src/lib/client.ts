// API client helpers + constants + formatters

// ---------- Proyek aktif (disinkronkan oleh store) ----------
let ACTIVE_PROJECT = ''
export function setActiveProjectId(id: string) { ACTIVE_PROJECT = id }
export function activeProjectId() { return ACTIVE_PROJECT }

export async function api<T = unknown>(url: string, init?: RequestInit & { timeoutMs?: number }): Promise<T> {
  const { timeoutMs, ...rest } = init ?? {}
  // Timeout guard: cegah request menggantung selamanya (mis. dev server sedang recompile)
  const ctrl = timeoutMs && timeoutMs > 0 ? new AbortController() : null
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null
  try {
    const res = await fetch(url, {
      ...(rest as RequestInit),
      signal: ctrl ? ctrl.signal : (rest as RequestInit).signal,
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      cache: 'no-store',
    })
    if (res.status === 401 && typeof window !== 'undefined' && !url.startsWith('/api/auth/')) {
      // Sesi habis / belum login -> beri tahu aplikasi untuk kembali ke halaman login
      window.dispatchEvent(new CustomEvent('asei:unauth'))
    }
    const json = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(json?.error || `HTTP ${res.status}`)
    return json as T
  } catch (e) {
    if (ctrl?.signal.aborted) throw new Error('Waktu tunggu habis — server tidak merespons. Coba lagi.')
    throw e
  } finally {
    if (timer) clearTimeout(timer)
  }
}

// Ulangi request yang gagal (transien: recompile dev server / jaringan tidak stabil)
export async function retry<T>(fn: () => Promise<T>, times = 3, waitMs = 900): Promise<T> {
  let last: unknown
  for (let i = 0; i < times; i++) {
    try {
      return await fn()
    } catch (e) {
      last = e
      if (i < times - 1) await new Promise(r => setTimeout(r, waitMs * (i + 1)))
    }
  }
  throw last
}

// Semua list/create otomatis ter-scope ke proyek aktif
export const listRes = <T>(r: string, q = '') => {
  const sep = q ? '&' : ''
  return api<{ data: T }>(`/api/data/${r}?${q}${sep}projectId=${ACTIVE_PROJECT}`).then(j => j.data)
}
export const createRes = (r: string, body: unknown) =>
  api<{ data: unknown }>(`/api/data/${r}?projectId=${ACTIVE_PROJECT}`, {
    method: 'POST', body: JSON.stringify({ projectId: ACTIVE_PROJECT, ...(body as Record<string, unknown>) }),
  })
export const updateRes = (r: string, id: string, body: unknown) =>
  api<{ data: unknown }>(`/api/data/${r}/${id}`, { method: 'PATCH', body: JSON.stringify(body) })
export const deleteRes = (r: string, id: string) => api(`/api/data/${r}/${id}`, { method: 'DELETE' })

// ============ Constants ============
export const ROLES = ['PM', 'SM', 'HSE', 'ENGINEER', 'SUPERVISOR', 'FOREMAN', 'QC', 'WELDER', 'WORKER', 'ADMIN'] as const
export const ROLE_LABEL: Record<string, string> = {
  PM: 'Project Manager', SM: 'Site Manager', HSE: 'HSE / K3', ENGINEER: 'Engineer',
  SUPERVISOR: 'Supervisor', FOREMAN: 'Foreman', QC: 'QC Inspector', WELDER: 'Welder',
  WORKER: 'Pekerja', ADMIN: 'Admin',
}
export const DISCIPLINES = ['GENERAL', 'CIVIL', 'MECHANICAL', 'ELECTRICAL'] as const
export const DISC_LABEL: Record<string, string> = { GENERAL: 'General', CIVIL: 'Civil', MECHANICAL: 'Mechanical', ELECTRICAL: 'Electrical' }
export const DISC_COLOR: Record<string, string> = {
  GENERAL: 'bg-slate-500', CIVIL: 'bg-amber-600', MECHANICAL: 'bg-orange-600', ELECTRICAL: 'bg-emerald-600',
}
export const DISC_HEX: Record<string, string> = { GENERAL: '#64748b', CIVIL: '#d97706', MECHANICAL: '#ea580c', ELECTRICAL: '#059669' }
export const ME_SUBS = ['Piping', 'Welding', 'Welding GTAW', 'Welding SMAW 6G', 'Fabrikasi Piping', 'Fabrikasi Support', 'Steel Erection', 'Equipment Erection', 'Pipe Fitting', 'Alignment', 'Rigging', 'Hydrotest & Flushing', 'Painting & Insulation', 'NDT / QC']
export const CIVIL_SUBS = ['Earthwork', 'Concrete', 'Rebar', 'Carpenter', 'Formwork', 'Mason', 'Foundation', 'Drainase', 'Roadway']
export const EE_SUBS = ['Cable Tray', 'Cable Pulling', 'Panel & Switchgear', 'Lighting', 'Instrumentation', 'Termination', 'Pre-Commissioning']

export const TASK_STATUS: Record<string, string> = { PENDING: 'Menunggu', IN_PROGRESS: 'Berjalan', COMPLETED: 'Selesai', DELAYED: 'Terlambat', CANCELLED: 'Batal' }
export const WBS_STATUS: Record<string, string> = { NOT_STARTED: 'Belum Mulai', IN_PROGRESS: 'Berjalan', COMPLETED: 'Selesai', DELAYED: 'Terlambat' }
export const ATT_STATUS: Record<string, string> = { PRESENT: 'Hadir', LATE: 'Terlambat', ABSENT: 'Absen', LEAVE: 'Izin', SICK: 'Sakit' }
export const PRIORITY: Record<string, string> = { LOW: 'Rendah', MEDIUM: 'Sedang', HIGH: 'Tinggi', CRITICAL: 'Kritis' }
export const EQ_STATUS: Record<string, string> = { PLANNED: 'Direncanakan', PO_ISSUED: 'PO Terbit', IN_PRODUCTION: 'Produksi', SHIPPED: 'Dikirim', ARRIVED: 'Tiba', INSTALLED: 'Terpasang', DELAYED: 'Terlambat' }
export const FAB_STATUS: Record<string, string> = { PLANNED: 'Direncanakan', CUTTING: 'Cutting', ON_FABRICATION: 'Fabrikasi', WELDING: 'Welding', NDT: 'NDT', PAINTING: 'Painting', DELIVERED: 'Terkirim' }
export const DOC_TYPES: Record<string, string> = { PRELIM: 'Preliminary', SOW: 'SOW', JSA: 'JSA', ITP: 'ITP', QCP: 'QCP', METHOD_STATEMENT: 'Method Statement', PERMIT: 'Permit to Work', MOM: 'MoM', OTHER: 'Lainnya' }
export const DOC_PHASE: Record<string, string> = { PRELIMINARY: 'Preliminary', ENGINEERING: 'Engineering', PROCUREMENT: 'Procurement', EXECUTION: 'Eksekusi', COMMISSIONING: 'Commissioning' }
export const PROJECT_STATUS: Record<string, string> = { PLANNING: 'Perencanaan', ACTIVE: 'Aktif', ON_HOLD: 'Ditunda', CLOSED: 'Selesai' }
export const PROJECT_BADGE: Record<string, string> = {
  PLANNING: 'bg-sky-100 text-sky-700 border-sky-200', ACTIVE: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  ON_HOLD: 'bg-amber-100 text-amber-700 border-amber-200', CLOSED: 'bg-slate-100 text-slate-600 border-slate-200',
}
export const ZONE_STATUS: Record<string, string> = { PLANNED: 'Direncanakan', ON_PROGRESS: 'Berjalan', COMPLETED: 'Selesai', DELAYED: 'Terlambat' }
export const ZONE_COLORS = ['#d97706', '#ea580c', '#059669', '#dc2626', '#0d9488', '#7c3aed', '#2563eb', '#be185d']
export const MARK_COLORS = ['#dc2626', '#ea580c', '#d97706', '#059669', '#0d9488', '#2563eb', '#7c3aed', '#111827', '#ffffff']
export const APD_LIST = [
  { key: 'helmet', label: 'Helm Safety' }, { key: 'vest', label: 'Rompi Reflektif' },
  { key: 'gloves', label: 'Sarung Tangan' }, { key: 'boots', label: 'Sepatu Safety' },
  { key: 'goggles', label: 'Kacamata' },
] as const

export function roleBadge(role: string): string {
  const map: Record<string, string> = {
    PM: 'bg-rose-100 text-rose-800 border-rose-200', SM: 'bg-orange-100 text-orange-800 border-orange-200',
    HSE: 'bg-lime-100 text-lime-800 border-lime-200', ENGINEER: 'bg-teal-100 text-teal-800 border-teal-200',
    SUPERVISOR: 'bg-amber-100 text-amber-800 border-amber-200', FOREMAN: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    QC: 'bg-violet-100 text-violet-800 border-violet-200', WELDER: 'bg-orange-50 text-orange-700 border-orange-200',
    WORKER: 'bg-slate-100 text-slate-700 border-slate-200', ADMIN: 'bg-gray-100 text-gray-600 border-gray-200',
  }
  return map[role] ?? 'bg-slate-100 text-slate-700 border-slate-200'
}

export function statusBadge(s: string): string {
  const map: Record<string, string> = {
    COMPLETED: 'bg-emerald-100 text-emerald-700 border-emerald-200', IN_PROGRESS: 'bg-amber-100 text-amber-700 border-amber-200',
    PENDING: 'bg-slate-100 text-slate-600 border-slate-200', DELAYED: 'bg-red-100 text-red-700 border-red-200',
    CANCELLED: 'bg-gray-100 text-gray-500 border-gray-200', NOT_STARTED: 'bg-slate-100 text-slate-600 border-slate-200',
    PRESENT: 'bg-emerald-100 text-emerald-700 border-emerald-200', LATE: 'bg-amber-100 text-amber-700 border-amber-200',
    ABSENT: 'bg-red-100 text-red-700 border-red-200', LEAVE: 'bg-sky-100 text-sky-700 border-sky-200',
    SICK: 'bg-orange-100 text-orange-700 border-orange-200', APPROVED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    SUBMITTED: 'bg-amber-100 text-amber-700 border-amber-200', DRAFT: 'bg-slate-100 text-slate-600 border-slate-200',
    IN_REVIEW: 'bg-amber-100 text-amber-700 border-amber-200', REJECTED: 'bg-red-100 text-red-700 border-red-200',
    ON_PROGRESS: 'bg-amber-100 text-amber-700 border-amber-200',
  }
  return map[s] ?? 'bg-slate-100 text-slate-600 border-slate-200'
}

// ============ Formatters ============
export const fmtDate = (d: string | Date | null | undefined) => d ? new Date(d).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'
export const fmtDateShort = (d: string | Date | null | undefined) => d ? new Date(d).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }) : '-'
export const fmtTime = (d: string | Date | null | undefined) => d ? new Date(d).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-'
export const fmtDateTime = (d: string | Date | null | undefined) => d ? `${fmtDate(d)} ${fmtTime(d)}` : '-'
export const todayStr = () => new Date().toISOString().slice(0, 10)
export const dateInput = (d: string | Date | null | undefined) => d ? new Date(d).toISOString().slice(0, 10) : ''
export const dateInputDT = (d: string | Date | null | undefined) => { if (!d) return ''; const x = new Date(d); return new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 16) }
export const pct = (a: number, b: number) => (b > 0 ? Math.min(100, Math.round((a / b) * 100)) : 0)

export const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map(n => n[0]).join('').toUpperCase()
export const moodEmoji = (e: string) => e === 'happy' ? '😊' : e === 'neutral' ? '😐' : e === 'tired' ? '😴' : e === 'stressed' ? '😣' : e === 'angry' ? '😠' : '❓'
export const scoreColor = (s: number) => s >= 80 ? 'text-emerald-600' : s >= 60 ? 'text-amber-600' : s > 0 ? 'text-red-600' : 'text-slate-400'
export const scoreBg = (s: number) => s >= 80 ? 'bg-emerald-500' : s >= 60 ? 'bg-amber-500' : s > 0 ? 'bg-red-500' : 'bg-slate-300'
