// ============ Auth: password hashing, session token (HMAC), guards ============
import { NextRequest, NextResponse } from 'next/server'
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import fs from 'fs'
import path from 'path'

export const SESSION_COOKIE = 'asei_session'
const DAY_MS = 24 * 60 * 60 * 1000

export type Role = 'MASTER_ADMIN' | 'STAFF'
export interface Session {
  uid: string
  username: string
  name: string
  role: Role
  employeeId: string
  exp: number
}

// Akun bootstrap pertama (dibuat otomatis saat login jika DB masih kosong)
export const BOOTSTRAP_ADMIN = { username: 'masteradmin09', password: 'Camilan85?', name: 'Master Admin' }

let SECRET = ''
function secret(): string {
  if (SECRET) return SECRET
  const env = process.env.AUTH_SECRET
  if (env && env.length >= 16) { SECRET = env; return SECRET }
  const file = path.join(process.cwd(), 'db', '.auth-secret')
  try {
    SECRET = fs.readFileSync(file, 'utf8').trim()
  } catch {
    SECRET = randomBytes(32).toString('hex')
    try { fs.writeFileSync(file, SECRET, { mode: 0o600 }) } catch { /* ignore */ }
  }
  return SECRET
}

// ---------- Password (scrypt) ----------
export function hashPassword(pw: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(pw, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [salt, hash] = String(stored || '').split(':')
  if (!salt || !hash) return false
  try {
    const test = scryptSync(pw, salt, 64)
    const orig = Buffer.from(hash, 'hex')
    return orig.length === test.length && timingSafeEqual(orig, test)
  } catch { return false }
}

// ---------- Token (payload JSON + HMAC-SHA256) ----------
function sign(data: string): string {
  return createHmac('sha256', secret()).update(data).digest('base64url')
}

export function createToken(s: Omit<Session, 'exp'>, days = 7): string {
  const payload: Session = { ...s, exp: Date.now() + days * DAY_MS }
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url')
  return `${body}.${sign(body)}`
}

export function verifyToken(token: string | undefined | null): Session | null {
  if (!token) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  const a = Buffer.from(sig)
  const b = Buffer.from(sign(body))
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  try {
    const s = JSON.parse(Buffer.from(body, 'base64url').toString()) as Session
    if (!s.exp || s.exp < Date.now()) return null
    return s
  } catch { return null }
}

export function getSessionFromReq(req: NextRequest): Session | null {
  return verifyToken(req.cookies.get(SESSION_COOKIE)?.value)
}

// ---------- Respon standar ----------
export function unauthorized(): NextResponse {
  return NextResponse.json({ error: 'Tidak diizinkan — silakan login terlebih dahulu' }, { status: 401 })
}
export function forbidden(): NextResponse {
  return NextResponse.json({ error: 'Akses ditolak — khusus Master Admin' }, { status: 403 })
}
export function isAdmin(s: Session | null): boolean {
  return s?.role === 'MASTER_ADMIN'
}
export function cookieOptions(maxAgeDays = 7) {
  return { httpOnly: true, sameSite: 'lax' as const, path: '/', maxAge: Math.round(maxAgeDays * 24 * 60 * 60) }
}
