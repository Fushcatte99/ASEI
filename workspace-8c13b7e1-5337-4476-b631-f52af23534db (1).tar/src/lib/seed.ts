import { db } from '@/lib/db'
import { ensureDefaultProject } from '@/lib/projects'

// ---------- helpers ----------
const D = (s: string) => new Date(s)
function addDays(base: Date, days: number) {
  const d = new Date(base)
  d.setDate(d.getDate() + days)
  return d
}
const TODAY = new Date()

const APD_FULL = JSON.stringify({ helmet: true, vest: true, gloves: true, boots: true, goggles: true })
const APD_PART = JSON.stringify({ helmet: true, vest: true, gloves: true, boots: false, goggles: false })

export async function seed() {
  // reset penuh: hapus semua proyek + datanya, lalu buat ulang proyek default
  await db.drawingMark.deleteMany()
  await db.drawingFile.deleteMany()
  await db.drawingZone.deleteMany()
  await db.aiSummary.deleteMany()
  await db.kpiRecord.deleteMany()
  await db.projectDocument.deleteMany()
  await db.weeklyReport.deleteMany()
  await db.dailyReport.deleteMany()
  await db.equipmentDelivery.deleteMany()
  await db.fabricationItem.deleteMany()
  await db.quantityItem.deleteMany()
  await db.wbsTask.deleteMany()
  await db.workTask.deleteMany()
  await db.attendance.deleteMany()
  await db.employee.deleteMany()
  await db.project.deleteMany()

  const defaultProject = await ensureDefaultProject()
  const pid = defaultProject.id

  // ============ EMPLOYEES ============
  type EmpExtra = Partial<{ apdStatus: string; apdItems: string; safetyInduction: boolean; inductionScore: number }>
  const E = (nip: string, name: string, role: string, discipline: string, sub: string, position: string, mgr: string, extra: EmpExtra = {}) => ({
    projectId: pid,
    nip, name, role, discipline, subDiscipline: sub, position, managerId: mgr,
    phone: `0812-${nip.slice(-4)}-${Math.floor(1000 + Math.random() * 8999)}`,
    email: `${nip.toLowerCase()}@asei.co.id`,
    joinDate: D('2026-06-20'),
    avatarColor: ['amber', 'emerald', 'orange', 'teal', 'rose', 'lime', 'cyan', 'violet'][Math.floor(Math.random() * 8)],
    safetyInduction: true,
    inductionDate: D('2026-06-22'),
    inductionScore: 80 + Math.floor(Math.random() * 20),
    apdStatus: 'COMPLETE',
    apdItems: APD_FULL,
    ...extra,
  })

  const pm = await db.employee.create({ data: E('ASEI-001', 'Ir. Hendra Wijaya', 'PM', 'GENERAL', 'Manajemen', 'Project Manager', '') })
  const hseMgr = await db.employee.create({ data: E('ASEI-002', 'Rudi Hartono', 'HSE', 'GENERAL', 'K3 / Safety', 'HSE Manager', pm.id) })
  const smCiv = await db.employee.create({ data: E('ASEI-003', 'Suparman, ST', 'SM', 'CIVIL', 'Structure & Foundation', 'Site Manager Civil', pm.id) })
  const smMe = await db.employee.create({ data: E('ASEI-004', 'Bambang Sutrisno, ST', 'SM', 'MECHANICAL', 'Mechanical Erection', 'Site Manager Mechanical', pm.id) })
  const smEe = await db.employee.create({ data: E('ASEI-005', 'Dwi Lestari, ST', 'SM', 'ELECTRICAL', 'Power & Control', 'Site Manager Electrical', pm.id) })
  const hseOff = await db.employee.create({ data: E('ASEI-006', 'Sari Kusuma', 'HSE', 'GENERAL', 'K3 / Safety', 'HSE Officer', hseMgr.id) })
  const engCiv = await db.employee.create({ data: E('ASEI-007', 'Andi Pratama, ST', 'ENGINEER', 'CIVIL', 'Structure', 'Civil Engineer', smCiv.id) })
  const engPipe = await db.employee.create({ data: E('ASEI-008', 'Joko Susilo, ST', 'ENGINEER', 'MECHANICAL', 'Piping', 'Piping Engineer', smMe.id) })
  const engWeld = await db.employee.create({ data: E('ASEI-009', 'Agus Salim, ST', 'ENGINEER', 'MECHANICAL', 'Welding & QA', 'Welding Engineer', smMe.id) })
  const engEquip = await db.employee.create({ data: E('ASEI-010', 'Rizky Maulana, ST', 'ENGINEER', 'MECHANICAL', 'Equipment & Alignment', 'Mechanical Engineer', smMe.id) })
  const engEe = await db.employee.create({ data: E('ASEI-011', 'Fitri Handayani, ST', 'ENGINEER', 'ELECTRICAL', 'Power Distribution', 'Electrical Engineer', smEe.id) })
  const engIc = await db.employee.create({ data: E('ASEI-012', 'Dimas Anggara, ST', 'ENGINEER', 'ELECTRICAL', 'Instrumentation & Control', 'Instrument Engineer', smEe.id) })
  const supCiv = await db.employee.create({ data: E('ASEI-013', 'Ahmad Fauzi', 'SUPERVISOR', 'CIVIL', 'Structure & Foundation', 'Civil Supervisor', smCiv.id) })
  const supPipe = await db.employee.create({ data: E('ASEI-014', 'Eko Prasetyo', 'SUPERVISOR', 'MECHANICAL', 'Piping', 'Piping Supervisor', smMe.id) })
  const supEquip = await db.employee.create({ data: E('ASEI-015', 'Yoga Permana', 'SUPERVISOR', 'MECHANICAL', 'Equipment Erection', 'Mechanical Supervisor', smMe.id) })
  const supEe = await db.employee.create({ data: E('ASEI-016', 'I Wayan Suda', 'SUPERVISOR', 'ELECTRICAL', 'Electrical Installation', 'Electrical Supervisor', smEe.id) })
  const formCiv = await db.employee.create({ data: E('ASEI-017', 'Budi Santoso', 'FOREMAN', 'CIVIL', 'Structure & Foundation', 'Civil Foreman', supCiv.id) })
  const formPipe = await db.employee.create({ data: E('ASEI-018', 'Slamet Riyadi', 'FOREMAN', 'MECHANICAL', 'Piping', 'Piping Foreman', supPipe.id) })
  const formWeld = await db.employee.create({ data: E('ASEI-019', 'Mulyadi', 'FOREMAN', 'MECHANICAL', 'Welding', 'Welding Foreman', engWeld.id) })
  const formEe = await db.employee.create({ data: E('ASEI-020', 'Taufik Hidayat', 'FOREMAN', 'ELECTRICAL', 'Electrical Installation', 'Electrical Foreman', supEe.id) })
  const qc = await db.employee.create({ data: E('ASEI-021', 'Retno Wulandari', 'QC', 'MECHANICAL', 'Quality Control', 'QC Inspector', engWeld.id) })
  const w1 = await db.employee.create({ data: E('ASEI-022', 'Dedi Kurniawan', 'WORKER', 'CIVIL', 'Carpenter', 'Carpenter', formCiv.id) })
  const w2 = await db.employee.create({ data: E('ASEI-023', 'Agus Setiawan', 'WORKER', 'CIVIL', 'Rebar', 'Rebar Man', formCiv.id, { apdStatus: 'INCOMPLETE', apdItems: APD_PART }) })
  const w3 = await db.employee.create({ data: E('ASEI-024', 'Herman Nugraha', 'WORKER', 'CIVIL', 'Mason', 'Mason', formCiv.id) })
  const w4 = await db.employee.create({ data: E('ASEI-025', 'Iwan Setiawan', 'WORKER', 'MECHANICAL', 'Pipe Fitter', 'Pipe Fitter', formPipe.id) })
  const w5 = await db.employee.create({ data: E('ASEI-026', 'Rizal Fahmi', 'WORKER', 'MECHANICAL', 'Pipe Fitter', 'Pipe Fitter', formPipe.id) })
  const w6 = await db.employee.create({ data: E('ASEI-027', 'Doni Saputra', 'WORKER', 'MECHANICAL', 'Rigger', 'Rigger', supEquip.id, { apdStatus: 'INCOMPLETE', apdItems: APD_PART }) })
  const w7 = await db.employee.create({ data: E('ASEI-028', 'Fajar Ramadhan', 'WORKER', 'ELECTRICAL', 'Cable Puller', 'Electrician', formEe.id) })
  const w8 = await db.employee.create({ data: E('ASEI-029', 'Bagus Prakoso', 'WORKER', 'ELECTRICAL', 'Panel Wiring', 'Electrician', formEe.id) })
  const wd1 = await db.employee.create({ data: E('ASEI-030', 'Sutrisno Aji', 'WELDER', 'MECHANICAL', 'SMAW 6G', 'Welder 6G', formWeld.id) })
  const wd2 = await db.employee.create({ data: E('ASEI-031', 'Kurnia Sandi', 'WELDER', 'MECHANICAL', 'GTAW+SMAW 6G', 'Welder Combo 6G', formWeld.id) })
  const wd3 = await db.employee.create({ data: E('ASEI-032', 'Yusuf Hamdani', 'WELDER', 'MECHANICAL', 'SMAW 3G', 'Welder 3G', formWeld.id) })
  const wd4 = await db.employee.create({ data: E('ASEI-033', 'Ali Mursid', 'WELDER', 'MECHANICAL', 'FCAW 6G', 'Welder FCAW', formWeld.id) })
  const admin = await db.employee.create({ data: E('ASEI-034', 'Maya Sari', 'ADMIN', 'GENERAL', 'Administrasi', 'Admin HR Project', pm.id) })

  const all = await db.employee.findMany()
  const byNip = Object.fromEntries(all.map(e => [e.nip, e.id]))

  // ============ WBS TASKS (Gantt) ============
  type W = { code: string; name: string; disc: string; sub: string; lvl: number; ord: number; start: string; dur: number; prog: number; plan: number; preds?: string[]; res?: string; mile?: boolean; crit?: boolean; assign?: string; weight?: number; status?: string }
  const wbs: W[] = [
    { code: '1', name: 'PRELIMINARY & MOBILISASI', disc: 'GENERAL', sub: '', lvl: 1, ord: 1, start: '2026-07-01', dur: 10, prog: 100, plan: 100, weight: 2, res: 'PM / HSE / Admin', status: 'COMPLETED' },
    { code: '1.1', name: 'Kick-off Meeting & Mobilisasi', disc: 'GENERAL', sub: '', lvl: 2, ord: 1, start: '2026-07-01', dur: 5, prog: 100, plan: 100, preds: [], res: 'PM, Admin', weight: 1, status: 'COMPLETED' },
    { code: '1.2', name: 'Safety Induction & Site Orientation', disc: 'GENERAL', sub: 'K3', lvl: 2, ord: 2, start: '2026-07-06', dur: 3, prog: 100, plan: 100, preds: ['1.1'], res: 'HSE Team', weight: 0.5, status: 'COMPLETED' },
    { code: '1.3', name: 'Setup Fasilitas Site (Office, Gudang, Laydown)', disc: 'GENERAL', sub: 'Fasilitas', lvl: 2, ord: 3, start: '2026-07-06', dur: 4, prog: 100, plan: 100, preds: ['1.1'], res: 'Admin, Civil Crew', weight: 0.5, status: 'COMPLETED' },
    { code: '2', name: 'ENGINEERING & PERMITTING', disc: 'GENERAL', sub: '', lvl: 1, ord: 2, start: '2026-07-08', dur: 20, prog: 95, plan: 100, weight: 5 },
    { code: '2.1', name: 'SOW & Approval Method Statement', disc: 'GENERAL', sub: 'Dokumen', lvl: 2, ord: 1, start: '2026-07-08', dur: 7, prog: 100, plan: 100, preds: ['1.1'], res: 'Engineering', weight: 2, status: 'COMPLETED' },
    { code: '2.2', name: 'Shop Drawing Piping & Steel Structure', disc: 'MECHANICAL', sub: 'Piping', lvl: 2, ord: 2, start: '2026-07-13', dur: 12, prog: 100, plan: 100, preds: ['2.1'], res: 'Piping Engineer', weight: 2, status: 'COMPLETED' },
    { code: '2.3', name: 'Shop Drawing Electrical & IFC Drawing', disc: 'ELECTRICAL', sub: 'Engineering', lvl: 2, ord: 3, start: '2026-07-15', dur: 10, prog: 90, plan: 100, preds: ['2.1'], res: 'EE Engineer', weight: 1, status: 'IN_PROGRESS' },
    { code: '3', name: 'PROCUREMENT & DELIVERY', disc: 'GENERAL', sub: '', lvl: 1, ord: 3, start: '2026-07-20', dur: 45, prog: 62, plan: 75, weight: 8 },
    { code: '3.1', name: 'Pengadaan Material Piping (Pipe, Fitting, Valve)', disc: 'MECHANICAL', sub: 'Procurement', lvl: 2, ord: 1, start: '2026-07-20', dur: 25, prog: 100, plan: 100, preds: ['2.2'], res: 'Procurement', weight: 3, status: 'COMPLETED' },
    { code: '3.2', name: 'Pengadaan Equipment Rotating (Pump, Compressor)', disc: 'MECHANICAL', sub: 'Equipment', lvl: 2, ord: 2, start: '2026-08-01', dur: 35, prog: 60, plan: 80, preds: ['2.2'], res: 'Procurement', weight: 3, status: 'IN_PROGRESS' },
    { code: '3.3', name: 'Pengadaan Material Electrical (Kabel, Tray, Panel)', disc: 'ELECTRICAL', sub: 'Procurement', lvl: 2, ord: 3, start: '2026-08-05', dur: 30, prog: 45, plan: 60, preds: ['2.3'], res: 'Procurement', weight: 2, status: 'IN_PROGRESS' },
    { code: '4', name: 'CIVIL WORKS', disc: 'CIVIL', sub: '', lvl: 1, ord: 4, start: '2026-07-22', dur: 60, prog: 58, plan: 65, weight: 20 },
    { code: '4.1', name: 'Earthwork & Pile Cap Foundation', disc: 'CIVIL', sub: 'Foundation', lvl: 2, ord: 1, start: '2026-07-22', dur: 18, prog: 100, plan: 100, preds: ['1.3'], res: 'Civil Crew A', weight: 6, status: 'COMPLETED' },
    { code: '4.2', name: 'Pondasi Equipment (Pedestal & Anchor Bolt)', disc: 'CIVIL', sub: 'Foundation', lvl: 2, ord: 2, start: '2026-08-10', dur: 20, prog: 70, plan: 75, preds: ['4.1'], res: 'Civil Crew B', weight: 6, status: 'IN_PROGRESS' },
    { code: '4.3', name: 'Pondasi Cable Tray & Duct Bank', disc: 'CIVIL', sub: 'Foundation', lvl: 2, ord: 3, start: '2026-08-20', dur: 15, prog: 35, plan: 40, preds: ['4.1'], res: 'Civil Crew A', weight: 4, status: 'IN_PROGRESS' },
    { code: '4.4', name: 'Drainage & Roadway Site', disc: 'CIVIL', sub: 'Drainase', lvl: 2, ord: 4, start: '2026-09-01', dur: 20, prog: 0, plan: 0, preds: ['4.2'], res: 'Civil Crew B', weight: 4, status: 'NOT_STARTED' },
    { code: '5', name: 'FABRIKASI MECHANICAL', disc: 'MECHANICAL', sub: '', lvl: 1, ord: 5, start: '2026-08-03', dur: 50, prog: 48, plan: 55, weight: 15 },
    { code: '5.1', name: 'Fabrikasi Pipe Spool Area A (Carbon Steel)', disc: 'MECHANICAL', sub: 'Fabrikasi Piping', lvl: 2, ord: 1, start: '2026-08-03', dur: 25, prog: 85, plan: 90, preds: ['3.1'], res: 'Fab Workshop', weight: 6, status: 'IN_PROGRESS' },
    { code: '5.2', name: 'Fabrikasi Pipe Spool Area B (Stainless)', disc: 'MECHANICAL', sub: 'Fabrikasi Piping', lvl: 2, ord: 2, start: '2026-08-18', dur: 25, prog: 40, plan: 45, preds: ['3.1'], res: 'Fab Workshop', weight: 5, status: 'IN_PROGRESS' },
    { code: '5.3', name: 'Fabrikasi Support & Steel Bracket', disc: 'MECHANICAL', sub: 'Fabrikasi Support', lvl: 2, ord: 3, start: '2026-08-10', dur: 20, prog: 60, plan: 65, preds: ['3.1'], res: 'Fab Workshop', weight: 4, status: 'IN_PROGRESS' },
    { code: '6', name: 'MECHANICAL INSTALLATION', disc: 'MECHANICAL', sub: '', lvl: 1, ord: 6, start: '2026-09-01', dur: 65, prog: 8, plan: 10, weight: 25 },
    { code: '6.1', name: 'Erection Steel Structure & Platform', disc: 'MECHANICAL', sub: 'Steel Erection', lvl: 2, ord: 1, start: '2026-09-01', dur: 18, prog: 15, plan: 15, preds: ['4.2', '5.3'], res: 'ME Crew', weight: 5, status: 'IN_PROGRESS' },
    { code: '6.2', name: 'Setting & Alignment Rotating Equipment', disc: 'MECHANICAL', sub: 'Equipment Erection', lvl: 2, ord: 2, start: '2026-09-12', dur: 15, prog: 5, plan: 8, preds: ['6.1', '3.2'], res: 'ME Equip Crew', weight: 5, status: 'IN_PROGRESS' },
    { code: '6.3', name: 'Instalasi Piping Area A (Spool Erection & Welding)', disc: 'MECHANICAL', sub: 'Piping Erection', lvl: 2, ord: 3, start: '2026-09-15', dur: 25, prog: 5, plan: 8, preds: ['6.1', '5.1'], res: 'Piping Crew', weight: 8, status: 'IN_PROGRESS' },
    { code: '6.4', name: 'Instalasi Piping Area B + Hydrotest', disc: 'MECHANICAL', sub: 'Piping Erection', lvl: 2, ord: 4, start: '2026-10-05', dur: 22, prog: 0, plan: 0, preds: ['6.3', '5.2'], res: 'Piping Crew', weight: 7, status: 'NOT_STARTED' },
    { code: '7', name: 'ELECTRICAL INSTALLATION', disc: 'ELECTRICAL', sub: '', lvl: 1, ord: 7, start: '2026-09-10', dur: 60, prog: 4, plan: 8, weight: 15 },
    { code: '7.1', name: 'Instalasi Cable Tray & Containment', disc: 'ELECTRICAL', sub: 'Cable Tray', lvl: 2, ord: 1, start: '2026-09-10', dur: 18, prog: 8, plan: 10, preds: ['4.3'], res: 'EE Crew', weight: 4, status: 'IN_PROGRESS' },
    { code: '7.2', name: 'Penarikan Kabel Power & Control', disc: 'ELECTRICAL', sub: 'Cable Pulling', lvl: 2, ord: 2, start: '2026-10-01', dur: 25, prog: 0, plan: 0, preds: ['7.1', '3.3'], res: 'EE Crew', weight: 6, status: 'NOT_STARTED' },
    { code: '7.3', name: 'Instalasi Panel MCC & Transformer', disc: 'ELECTRICAL', sub: 'Panel & Switchgear', lvl: 2, ord: 3, start: '2026-10-10', dur: 20, prog: 0, plan: 0, preds: ['7.1', '3.3'], res: 'EE Crew', weight: 5, status: 'NOT_STARTED' },
    { code: '8', name: 'PRE-COMMISSIONING & COMMISSIONING', disc: 'GENERAL', sub: '', lvl: 1, ord: 8, start: '2026-11-01', dur: 35, prog: 0, plan: 0, weight: 10 },
    { code: '8.1', name: 'Pre-Comm: Loop Test, Megger, Flush Piping', disc: 'ELECTRICAL', sub: 'Pre-Commissioning', lvl: 2, ord: 1, start: '2026-11-01', dur: 15, prog: 0, plan: 0, preds: ['6.4', '7.2'], res: 'Comm Team', weight: 4, status: 'NOT_STARTED' },
    { code: '8.2', name: 'Commissioning & Performance Test', disc: 'GENERAL', sub: 'Commissioning', lvl: 2, ord: 2, start: '2026-11-16', dur: 15, prog: 0, plan: 0, preds: ['8.1', '7.3'], res: 'Comm Team', weight: 4, status: 'NOT_STARTED' },
    { code: '8.3', name: 'Hand Over & Demobilisasi', disc: 'GENERAL', sub: '', lvl: 2, ord: 3, start: '2026-11-30', dur: 5, prog: 0, plan: 0, preds: ['8.2'], res: 'PM', mile: true, weight: 2, status: 'NOT_STARTED' },
  ]
  const wbsData = wbs.map(t => ({
    projectId: pid,
    wbsCode: t.code, name: t.name, discipline: t.disc, subDiscipline: t.sub,
    parentId: t.code.includes('.') ? t.code.split('.').slice(0, -1).join('.') : '',
    level: t.lvl, order: t.ord,
    startDate: D(t.start), endDate: addDays(D(t.start), t.dur - 1), duration: t.dur,
    progress: t.prog, plannedProgress: t.plan,
    weight: t.weight ?? 0, predecessors: JSON.stringify(t.preds ?? []),
    resources: t.res ?? '', assigneeId: t.assign ?? '',
    isMilestone: !!t.mile, criticalPath: !!t.crit,
    status: t.status ?? (t.prog === 0 ? 'NOT_STARTED' : t.prog >= 100 ? 'COMPLETED' : 'IN_PROGRESS'),
  }))
  await db.wbsTask.createMany({ data: wbsData })

  // ============ WORK TASKS ============
  const wt = [
    { title: 'Instalasi rebar pondasi pedestal P-101', assignee: 'ASEI-022', assigner: 'ASEI-017', disc: 'CIVIL', sub: 'Rebar', prio: 'HIGH', st: 'IN_PROGRESS', prog: 65, due: 5, qty: 3.5, act: 2.3, unit: 'ton', loc: 'Area A' },
    { title: 'Pengetakan (formwork) beam B-3 Area Pump', assignee: 'ASEI-022', assigner: 'ASEI-017', disc: 'CIVIL', sub: 'Carpenter', prio: 'MEDIUM', st: 'IN_PROGRESS', prog: 40, due: 4, qty: 45, act: 18, unit: 'm2', loc: 'Area Pump' },
    { title: 'Corbing beton K-250 pondasi P-102', assignee: 'ASEI-024', assigner: 'ASEI-017', disc: 'CIVIL', sub: 'Mason', prio: 'HIGH', st: 'PENDING', prog: 0, due: 7, qty: 12, act: 0, unit: 'm3', loc: 'Area A' },
    { title: 'Fit-up & welding spool SP-A-014 s/d SP-A-020', assignee: 'ASEI-030', assigner: 'ASEI-019', disc: 'MECHANICAL', sub: 'Welding', prio: 'CRITICAL', st: 'IN_PROGRESS', prog: 55, due: 3, qty: 14, act: 8, unit: 'joint', loc: 'Workshop Fab' },
    { title: 'Welding root pass stainless spool Area B', assignee: 'ASEI-031', assigner: 'ASEI-019', disc: 'MECHANICAL', sub: 'Welding GTAW', prio: 'HIGH', st: 'IN_PROGRESS', prog: 30, due: 6, qty: 10, act: 3, unit: 'joint', loc: 'Workshop Fab' },
    { title: 'Grinding & finishing weld 3G structure', assignee: 'ASEI-032', assigner: 'ASEI-019', disc: 'MECHANICAL', sub: 'Welding', prio: 'LOW', st: 'IN_PROGRESS', prog: 80, due: 2, qty: 20, act: 16, unit: 'joint', loc: 'Laydown' },
    { title: 'Pemotongan pipa 6" sch 80 untuk spool B', assignee: 'ASEI-033', assigner: 'ASEI-019', disc: 'MECHANICAL', sub: 'Fabrikasi', prio: 'MEDIUM', st: 'IN_PROGRESS', prog: 70, due: 2, qty: 32, act: 22, unit: 'cut', loc: 'Workshop Fab' },
    { title: 'Mock-up alignment pump P-101 & P-102', assignee: 'ASEI-025', assigner: 'ASEI-015', disc: 'MECHANICAL', sub: 'Alignment', prio: 'HIGH', st: 'PENDING', prog: 10, due: 9, qty: 2, act: 0, unit: 'unit', loc: 'Area Pump' },
    { title: 'Rigging & lifting steel structure level-2', assignee: 'ASEI-027', assigner: 'ASEI-015', disc: 'MECHANICAL', sub: 'Rigging', prio: 'CRITICAL', st: 'IN_PROGRESS', prog: 25, due: 4, qty: 8, act: 2, unit: 'lift', loc: 'Area A' },
    { title: 'Instalasi cable tray C1-C3 run 1', assignee: 'ASEI-028', assigner: 'ASEI-020', disc: 'ELECTRICAL', sub: 'Cable Tray', prio: 'HIGH', st: 'IN_PROGRESS', prog: 45, due: 6, qty: 120, act: 54, unit: 'm', loc: 'Rack A' },
    { title: 'Terminasi kabel panel MCC-1 (kontrol)', assignee: 'ASEI-029', assigner: 'ASEI-020', disc: 'ELECTRICAL', sub: 'Panel Wiring', prio: 'MEDIUM', st: 'PENDING', prog: 0, due: 12, qty: 64, act: 0, unit: 'point', loc: 'MCC Room' },
    { title: 'NDT (PT) weld joint spool Area A batch-2', assignee: 'ASEI-021', assigner: 'ASEI-009', disc: 'MECHANICAL', sub: 'QC / NDT', prio: 'HIGH', st: 'IN_PROGRESS', prog: 60, due: 3, qty: 25, act: 15, unit: 'joint', loc: 'Workshop Fab' },
    { title: 'Update JSA lifting operation weekly', assignee: 'ASEI-006', assigner: 'ASEI-002', disc: 'GENERAL', sub: 'K3', prio: 'MEDIUM', st: 'IN_PROGRESS', prog: 50, due: 2, qty: 1, act: 0.5, unit: 'dok', loc: 'Office' },
    { title: 'Pengecekan APD & housekeeping harian area fab', assignee: 'ASEI-006', assigner: 'ASEI-002', disc: 'GENERAL', sub: 'K3', prio: 'HIGH', st: 'COMPLETED', prog: 100, due: 0, qty: 1, act: 1, unit: 'round', loc: 'Workshop' },
    { title: 'Compile progress report mingguan & kurva-S', assignee: 'ASEI-034', assigner: 'ASEI-001', disc: 'GENERAL', sub: 'Administrasi', prio: 'MEDIUM', st: 'IN_PROGRESS', prog: 75, due: 1, qty: 1, act: 0.75, unit: 'report', loc: 'Office' },
  ]
  for (const t of wt) {
    const startD = addDays(TODAY, -Math.floor(Math.random() * 6) - 2)
    await db.workTask.create({
      data: {
        projectId: pid,
        title: t.title, description: `Task ${t.sub} untuk area ${t.loc}. Dikerjakan sesuai method statement dan JSA terkait.`,
        discipline: t.disc, subDiscipline: t.sub, category: t.disc === 'MECHANICAL' && t.sub.includes('Weld') ? 'FABRICATION' : t.disc === 'GENERAL' ? 'SAFETY' : 'INSTALLATION',
        assigneeId: byNip[t.assignee], assignerId: byNip[t.assigner], priority: t.prio, status: t.st,
        startDate: startD, dueDate: addDays(TODAY, t.due), completedAt: t.st === 'COMPLETED' ? TODAY : null,
        progress: t.prog, targetQty: t.qty, actualQty: t.act, unit: t.unit, location: t.loc,
      },
    })
  }

  // ============ QUANTITY INSTALLED ============
  const qty = [
    { name: 'Galian tanah pondasi', disc: 'CIVIL', sub: 'Earthwork', unit: 'm3', plan: 850, inst: 850, loc: 'Area A', st: 'COMPLETED' },
    { name: 'Beton K-250 pondasi/pile cap', disc: 'CIVIL', sub: 'Concrete', unit: 'm3', plan: 220, inst: 168, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Rebar diameter D16-D25', disc: 'CIVIL', sub: 'Rebar', unit: 'ton', plan: 48, inst: 36, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Formwork pondasi & pedestal', disc: 'CIVIL', sub: 'Carpenter', unit: 'm2', plan: 620, inst: 505, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Grouting non-shrink equipment', disc: 'CIVIL', sub: 'Grouting', unit: 'm3', plan: 8.5, inst: 2.0, loc: 'Area Pump', st: 'ON_PROGRESS' },
    { name: 'Erection steel structure W6-W10', disc: 'MECHANICAL', sub: 'Steel Erection', unit: 'ton', plan: 96, inst: 14, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Pipe spool erection CS 2"-8"', disc: 'MECHANICAL', sub: 'Piping Erection', unit: 'dia-inch', plan: 2450, inst: 210, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Piping erection SS 1.5"-4"', disc: 'MECHANICAL', sub: 'Piping Erection', unit: 'dia-inch', plan: 1100, inst: 85, loc: 'Area B', st: 'ON_PROGRESS' },
    { name: 'Welding joint CS (6G)', disc: 'MECHANICAL', sub: 'Welding', unit: 'joint', plan: 380, inst: 52, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Instalasi pipe support & shoe', disc: 'MECHANICAL', sub: 'Support', unit: 'pcs', plan: 340, inst: 118, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Hydrotest piping loop-1', disc: 'MECHANICAL', sub: 'Testing', unit: 'loop', plan: 12, inst: 0, loc: 'Area A', st: 'NOT_STARTED' },
    { name: 'Insulasi & painting pipa', disc: 'MECHANICAL', sub: 'Painting & Insulation', unit: 'm2', plan: 780, inst: 95, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Instalasi cable tray 400mm', disc: 'ELECTRICAL', sub: 'Cable Tray', unit: 'm', plan: 850, inst: 214, loc: 'Rack A', st: 'ON_PROGRESS' },
    { name: 'Penarikan kabel NYY 4x70mm2', disc: 'ELECTRICAL', sub: 'Cable Pulling', unit: 'm', plan: 1450, inst: 0, loc: 'Rack A', st: 'NOT_STARTED' },
    { name: 'Instalasi lighting fixture area', disc: 'ELECTRICAL', sub: 'Lighting', unit: 'point', plan: 180, inst: 22, loc: 'Area A', st: 'ON_PROGRESS' },
    { name: 'Instalasi instrument transmitter & tubing', disc: 'ELECTRICAL', sub: 'Instrumentation', unit: 'loop', plan: 46, inst: 6, loc: 'Area A', st: 'ON_PROGRESS' },
  ]
  for (const q of qty) {
    await db.quantityItem.create({
      data: {
        projectId: pid,
        name: q.name, discipline: q.disc, subDiscipline: q.sub, unit: q.unit,
        plannedQty: q.plan, installedQty: q.inst, location: q.loc, area: q.loc,
        status: q.st, startDate: D('2026-08-01'), endDate: addDays(TODAY, 30),
      },
    })
  }

  // ============ FABRICATION ============
  const fab = [
    { name: 'Spool SP-A-014 (6" CS Elbow+Flange)', dwg: 'ISO-A-014', mat: 'A106 Gr.B', tot: 6, cut: 6, fit: 6, weld: 5, ndt: 4, paint: 3, del: 2, wrk: 'WS-1', st: 'ON_FABRICATION' },
    { name: 'Spool SP-A-015 (4" CS Tee)', dwg: 'ISO-A-015', mat: 'A106 Gr.B', tot: 8, cut: 8, fit: 7, weld: 6, ndt: 5, paint: 4, del: 3, wrk: 'WS-1', st: 'ON_FABRICATION' },
    { name: 'Spool SP-B-001 (2" SS Socket weld)', dwg: 'ISO-B-001', mat: 'A312 TP316', tot: 10, cut: 5, fit: 3, weld: 2, ndt: 1, paint: 0, del: 0, wrk: 'WS-2', st: 'WELDING' },
    { name: 'Spool SP-B-002 (3" SS Butt weld)', dwg: 'ISO-B-002', mat: 'A312 TP316', tot: 7, cut: 4, fit: 2, weld: 1, ndt: 0, paint: 0, del: 0, wrk: 'WS-2', st: 'CUTTING' },
    { name: 'Support PS-101 (Pipe Shoe Type-A)', dwg: 'SUP-101', mat: 'A36 Plate', tot: 24, cut: 24, fit: 20, weld: 18, ndt: 0, paint: 15, del: 12, wrk: 'WS-3', st: 'PAINTING' },
    { name: 'Support PS-102 (Guide Type-B)', dwg: 'SUP-102', mat: 'A36 Plate', tot: 18, cut: 14, fit: 10, weld: 8, ndt: 0, paint: 5, del: 2, wrk: 'WS-3', st: 'ON_FABRICATION' },
    { name: 'Bracket Platform PL-2 (Grating frame)', dwg: 'PLT-002', mat: 'A36 H-Beam', tot: 12, cut: 12, fit: 12, weld: 12, ndt: 0, paint: 12, del: 10, wrk: 'WS-3', st: 'DELIVERED' },
    { name: 'Ducting exhaust 600x400', dwg: 'DCT-001', mat: 'SS400 Sheet 3mm', tot: 14, cut: 9, fit: 6, weld: 5, ndt: 0, paint: 3, del: 0, wrk: 'WS-1', st: 'ON_FABRICATION' },
  ]
  for (const f of fab) {
    await db.fabricationItem.create({
      data: {
        projectId: pid,
        name: f.name, drawingNo: f.dwg, discipline: 'MECHANICAL', material: f.mat,
        unit: 'pcs', totalQty: f.tot, cutQty: f.cut, fitUpQty: f.fit, weldedQty: f.weld,
        ndtQty: f.ndt, paintedQty: f.paint, deliveredQty: f.del, workshop: f.wrk, status: f.st,
      },
    })
  }

  // ============ EQUIPMENT DELIVERY ============
  const eq = [
    { name: 'Centrifugal Pump P-101', tag: 'P-101', disc: 'MECHANICAL', sup: 'PT. Pompa Teknik', plan: '2026-09-05', act: '', st: 'IN_PRODUCTION', stor: '' },
    { name: 'Centrifugal Pump P-102', tag: 'P-102', disc: 'MECHANICAL', sup: 'PT. Pompa Teknik', plan: '2026-09-05', act: '', st: 'IN_PRODUCTION', stor: '' },
    { name: 'Air Compressor AC-201', tag: 'AC-201', disc: 'MECHANICAL', sup: 'PT. Kompres Indo', plan: '2026-09-20', act: '', st: 'PO_ISSUED', stor: '' },
    { name: 'Pressure Tank TK-301', tag: 'TK-301', disc: 'MECHANICAL', sup: 'PT. Bejana Teknik', plan: '2026-08-28', act: '2026-08-27', st: 'ARRIVED', stor: 'Laydown A' },
    { name: 'Heat Exchanger HE-401', tag: 'HE-401', disc: 'MECHANICAL', sup: 'PT. Penukar Kalor', plan: '2026-09-15', act: '', st: 'SHIPPED', stor: '' },
    { name: 'Panel MCC-1 (12 feeder)', tag: 'MCC-1', disc: 'ELECTRICAL', sup: 'PT. Panel Listrik', plan: '2026-10-05', act: '', st: 'PO_ISSUED', stor: '' },
    { name: 'Transformer 1000 kVA', tag: 'TR-1', disc: 'ELECTRICAL', sup: 'PT. Trafo Nusantara', plan: '2026-10-10', act: '', st: 'PLANNED', stor: '' },
    { name: 'Diesel Generator 500 kVA', tag: 'DG-1', disc: 'ELECTRICAL', sup: 'PT. Genset Prima', plan: '2026-08-25', act: '2026-08-26', st: 'ARRIVED', stor: 'Laydown B' },
    { name: 'Instrument Transmitters (24 pt)', tag: 'IT-BATCH1', disc: 'ELECTRICAL', sup: 'PT. Instrumen Andalan', plan: '2026-08-20', act: '2026-08-19', st: 'INSTALLED', stor: 'Store Room' },
    { name: 'Globe & Gate Valve Set', tag: 'VLV-SET1', disc: 'MECHANICAL', sup: 'PT. Valve Utama', plan: '2026-08-15', act: '2026-08-14', st: 'INSTALLED', stor: 'Store Room' },
  ]
  for (const e of eq) {
    await db.equipmentDelivery.create({
      data: {
        projectId: pid,
        equipmentName: e.name, tagNo: e.tag, discipline: e.disc, supplier: e.sup,
        qty: 1, unit: 'unit', status: e.st, plannedDate: D(e.plan),
        actualDate: e.act ? D(e.act) : null, storageLocation: e.stor,
      },
    })
  }

  // ============ DOCUMENTS (Prelim, SOW, JSA, dll) ============
  const docs = [
    { title: 'Preliminary Report & Site Survey', no: 'ASEI-PRJ-PRELIM-001', type: 'PRELIM', disc: 'GENERAL', phase: 'PRELIMINARY', st: 'APPROVED', content: 'Hasil survei lokasi: akses jalan site, lahan 2.4 Ha, kondisi tanah urug 1.5m, kebutuhan mobilisasi alat berat 6 unit. Rekomendasi layout gudang & laydown area. Kajian awal kebutuhan tenaga kerja 45 orang (Civil 15, ME 20, EE 10) dengan rencana penambahan bertahap saat puncak instalasi.' },
    { title: 'Statement of Work (SOW) EPC Skid Package', no: 'ASEI-PRJ-SOW-001', type: 'SOW', disc: 'GENERAL', phase: 'ENGINEERING', st: 'APPROVED', content: 'Lingkup: Engineering, Procurement, Construction skid package & utility piping meliputi: (1) Civil: earthwork, pondasi, drainage; (2) Mechanical: fabrikasi & instalasi piping carbon/stainless steel, erection structure, setting rotating equipment; (3) Electrical: cable tray, penarikan kabel, panel MCC, transformer, instrumentasi. Target completion 30 November 2026, berlaku zero accident, kualitas sesuai ASME B31.3 dan standar IEC.' },
    { title: 'JSA - Hot Work / Welding Area Fabrikasi', no: 'ASEI-PRJ-JSA-001', type: 'JSA', disc: 'MECHANICAL', phase: 'EXECUTION', st: 'APPROVED', content: 'Langkah kerja: 1) Persiapan area & fire watch, 2) Pemasangan grounding welder, 3) Pengecekan APD las (welding hood, gloves, apron), 4) Welding sesuai WPS, 5) Housekeeping slag. Bahaya: percikan api, luka bakar, asap las, sengatan listrik. Kontrol: fire extinguisher siap, fire watch standby, ventilasi memadai, pemakaian APD lengkap wajib, gas detector untuk area terbatas.' },
    { title: 'JSA - Lifting Operation Steel Structure', no: 'ASEI-PRJ-JSA-002', type: 'JSA', disc: 'MECHANICAL', phase: 'EXECUTION', st: 'APPROVED', content: 'Langkah kerja: 1) Inspeksi crane & rigging tools, 2) Sling sesuai load chart, 3) Tag line & zona eksklusi, 4) Trial lift 30cm, 5) Pemindahan & penempatan, 6) Unhooking. Bahaya: beban jatuh, sling terlepas, angin kencang. Kontrol: rigger bersertifikat, komunikasi radio, batas angin 20 km/jam, barrier zona, tag line dipasang.' },
    { title: 'JSA - Penarikan Kabel Tenaga (Cable Pulling)', no: 'ASEI-PRJ-JSA-003', type: 'JSA', disc: 'ELECTRICAL', phase: 'EXECUTION', st: 'IN_REVIEW', content: 'Langkah kerja: 1) Inspeksi tray & roller, 2) Pemasangan cable stocking & winch, 3) Penarikan terkoordinasi, 4) Pemotongan & terminasi sementara. Bahaya: tangan terjepit, kelelahan, tertabrak roller. Kontrol: komando lewat 1 leader, sarung tangan kulit, posisi kerja aman, rotasi pekerja tiap 30m pull.' },
    { title: 'ITP - Piping Fabrication & Erection', no: 'ASEI-PRJ-ITP-001', type: 'ITP', disc: 'MECHANICAL', phase: 'EXECUTION', st: 'APPROVED', content: 'Tahap inspeksi: 1) Verifikasi material (MTC), 2) Visual dimensi setelah cutting, 3) Fit-up inspection, 4) Visual weld, 5) NDT 10% random (PT/RT), 6) Hydrotest 1.5x design pressure, 7) Flushing, 8) Painting DFT check. Hold point oleh client pada fit-up, final weld, hydrotest.' },
    { title: 'Method Statement - Setting Rotating Equipment', no: 'ASEI-PRJ-MS-001', type: 'METHOD_STATEMENT', disc: 'MECHANICAL', phase: 'EXECUTION', st: 'APPROVED', content: 'Prosedur: 1) Pengecekan pondasi & anchor bolt, 2) Rigging & positioning skid, 3) Leveling dengan shim & machinist level, 4) Alignment laser (toleransi 0.05mm), 5) Grouting, 6) Final alignment setelah grout curing. Tools: dial indicator, laser alignment kit, torque wrench. QC hold point pada alignment final sebelum grouting.' },
    { title: 'Permit to Work - Hot Work & Confined Space', no: 'ASEI-PRJ-PTW-001', type: 'PERMIT', disc: 'GENERAL', phase: 'EXECUTION', st: 'APPROVED', content: 'PTW aktif minggu ini: Hot work area fabrikasi (berlaku 07:00-17:00, fire watch 2 orang), Confined space tank TK-301 (gas test tiap masuk, attendant standby, rescue plan tersedia). Semua pekerja wajib toolbox meeting sebelum aktivitas.' },
    { title: 'QCP - Electrical Cable Pulling & Termination', no: 'ASEI-PRJ-QCP-001', type: 'QCP', disc: 'ELECTRICAL', phase: 'EXECUTION', st: 'IN_REVIEW', content: 'Checkpoint: inspeksi tray sebelum pull, megger test sebelum terminasi (min 100 MOhm @1kV), torque check terminal sesuai spesifikasi, continuous sheath test, labeling & ferruling, loop test instrument.' },
    { title: 'MOM - Weekly Progress Meeting #8', no: 'ASEI-PRJ-MOM-008', type: 'MOM', disc: 'GENERAL', phase: 'EXECUTION', st: 'APPROVED', content: 'Agenda: progress fisik 42.3% vs plan 45.1% (minus 2.8%), kendala: keterlambatan delivery pump P-101/P-102 (mitigasi: ekspedisi darat, resequence pekerjaan), kebutuhan tambahan welder 2 orang untuk spool stainless, permintaan client untuk percepatan cable tray sebelum piping erection ramping.' },
  ]
  for (const d of docs) {
    await db.projectDocument.create({
      data: {
        projectId: pid,
        title: d.title, docNo: d.no, type: d.type, discipline: d.disc, phase: d.phase,
        content: d.content, version: 'A', status: d.st, authorId: byNip['ASEI-034'],
        approvedBy: d.st === 'APPROVED' ? pm.name : '', validFrom: D('2026-07-01'), validTo: D('2026-12-31'),
      },
    })
  }

  // ============ ATTENDANCE (7 hari terakhir) ============
  const emotions = ['happy', 'neutral', 'neutral', 'tired', 'happy', 'stressed', 'happy', 'neutral']
  for (let d = 6; d >= 0; d--) {
    const date = addDays(TODAY, -d)
    const dow = date.getDay()
    if (dow === 0) continue // skip hari minggu
    for (const emp of all) {
      const r = Math.random()
      let status = 'PRESENT', late = 0
      if (r > 0.96) { status = 'ABSENT' }
      else if (r > 0.90) { status = 'LEAVE' }
      else if (r > 0.80) { status = 'LATE'; late = 5 + Math.floor(Math.random() * 40) }
      const present = status === 'PRESENT' || status === 'LATE'
      const ppeOk = Math.random() > 0.18
      const ppeScore = !present ? 0 : ppeOk ? 90 + Math.floor(Math.random() * 11) : 55 + Math.floor(Math.random() * 20)
      const emotion = present ? emotions[Math.floor(Math.random() * emotions.length)] : ''
      const mood = present ? (emotion === 'happy' ? 75 + Math.floor(Math.random() * 21) : emotion === 'neutral' ? 55 + Math.floor(Math.random() * 15) : emotion === 'tired' ? 35 + Math.floor(Math.random() * 15) : 25 + Math.floor(Math.random() * 15)) : 0
      const checkDate = new Date(date)
      await db.attendance.create({
        data: {
          projectId: pid,
          employeeId: emp.id, date: checkDate, status, lateMinutes: late,
          checkIn: present ? new Date(new Date(checkDate).setHours(7, status === 'LATE' ? 5 + late : Math.floor(Math.random() * 25), 0, 0)) : null,
          checkOut: present && d > 0 ? new Date(new Date(checkDate).setHours(17, Math.floor(Math.random() * 30), 0, 0)) : null,
          location: Math.random() > 0.8 ? 'Workshop Fabrikasi' : 'Site Utama',
          workHours: present ? 8 + Math.floor(Math.random() * 2) * 0.5 : 0,
          ppeScore, ppeDetails: ppeScore > 80 ? APD_FULL : APD_PART,
          ppeNotes: ppeScore > 80 ? 'APD lengkap dan sesuai standar' : (present ? 'Sarung tangan & goggles tidak terdeteksi' : ''),
          emotion, moodScore: mood,
          aiNotes: present ? (ppeScore > 80 ? `Wajah terdeteksi ${emotion}, APD lengkap.` : `Wajah terdeteksi ${emotion}, APD kurang: goggles & gloves.`) : '',
          aiAnalyzed: present,
        },
      })
    }
  }

  // ============ DAILY REPORTS ============
  const drTemplates = [
    { nip: 'ASEI-017', act: 'Koordinasi pengetakan beam B-3, monitoring rebar pedestal P-101, distribusi manpower 6 orang ke 2 front kerja.', iss: 'Kekurangan plywood 15 lembar, sudah request ke gudang.', plan: 'Lanjut pengetakan & mulai corbing P-102.', mn: 6 },
    { nip: 'ASEI-018', act: 'Fit-up spool SP-A-014 s/d 016, welding joint 8 titik oleh welder 6G, housekeeping area fab.', iss: 'Consumable TIG wire hampir habis.', plan: 'Lanjut welding SP-A-017 s/d 020 & request wire.', mn: 9 },
    { nip: 'ASEI-020', act: 'Instalasi cable tray run-1 45 meter, pengecekan level & alignment support.', iss: 'Belum ada kendala.', plan: 'Lanjut run-2 dan mulai marking routing MCC.', mn: 5 },
    { nip: 'ASEI-008', act: 'Review shop drawing isometric piping batch-2, koordinasi dengan supervisor untuk sequence erection.', iss: 'Ada 3 isometric butuh klarifikasi ke engineering utama.', plan: 'Follow up klarifikasi & update cut plan.', mn: 0 },
    { nip: 'ASEI-002', act: 'Safety patrol 2x (fab & civil), toolbox meeting pagi, audit APD 34 pekerja, verifikasi PTW 6 permit.', iss: '2 pekerja APD kurang (goggles), langsung di-stop & diberi teguran.', plan: 'Safety talk khusus pemakaian goggles & audit ulang.', mn: 34 },
    { nip: 'ASEI-021', act: 'Visual inspection weld 18 joint, NDT PT 15 joint (hasil: 14 accept, 1 reject - repair), dokumentasi laporan NDT.', iss: '1 joint reject di SP-A-014, sudah dibuat NCR.', plan: 'Re-inspection setelah repair welder.', mn: 0 },
    { nip: 'ASEI-001', act: 'Weekly meeting client, review kurva-S, koordinasi procurement pump P-101/102, approve dokumen method statement.', iss: 'Pump P-101/102 delay 10 hari dari vendor.', plan: 'Mitigasi resequence: prioritaskan erection structure & piping area A.', mn: 45 },
    { nip: 'ASEI-013', act: 'Supervisi pondasi pedestal P-102, pengecekan as-built elevation, koordinasi alat vibrator dengan foreman.', iss: 'Elevation pedestal-2 meleset 3mm, dikoreksi dengan grouting.', plan: 'Lanjut setting anchor bolt P-103.', mn: 12 },
  ]
  for (const [i, t] of drTemplates.entries()) {
    const emp = all.find(e => e.nip === t.nip)
    if (!emp) continue
    await db.dailyReport.create({
      data: {
        projectId: pid,
        employeeId: emp.id, role: emp.role, discipline: emp.discipline,
        date: addDays(TODAY, i % 2 === 0 ? 0 : -1),
        activities: t.act, achievements: i % 2 === 0 ? 'Target harian tercapai 100%.' : 'Target harian tercapai ~85%, sisanya lanjut besok.',
        issues: t.iss, planTomorrow: t.plan, weather: 'Cerah', manpowerCount: t.mn, workHours: 8,
        status: 'APPROVED', reviewedBy: pm.name,
      },
    })
  }

  // ============ WEEKLY REPORT & PLAN ============
  const weekStart = addDays(TODAY, -((TODAY.getDay() + 6) % 7))
  const weekEnd = addDays(weekStart, 6)
  const wr = [
    { nip: 'ASEI-001', type: 'REPORT', ach: 'Progress fisik minggu ini 42.3% (plan 45.1%). Civil pondasi 70%, fabrikasi spool 48%, electrical tray 8%. Zero accident 62 hari.', iss: 'Delay delivery pump 10 hari; kekurangan welder sertifikat 6G untuk stainless.', nxt: 'Percepat erection structure, request 2 welder tambahan, koordinasi expedisi pump.', sum: 'Kurva-S minus 2.8%, mitigasi berjalan.' },
    { nip: 'ASEI-004', type: 'REPORT', ach: 'Fabrikasi spool Area A 85%, Area B 40%, support 60%. Produksi rata-rata 14 joint/hari.', iss: 'Consumable & gas las perlu restock.', nxt: 'Target spool Area A 100% minggu depan, mulai delivery ke site.', sum: 'Mechanical overall 48%.' },
    { nip: 'ASEI-005', type: 'PLAN', ach: '', iss: '', nxt: 'Minggu depan: selesaikan cable tray run-1 (120m), mulai marking run-2, siapkan terminasi MCC-1 bila panel tiba, safety talk khusus cable pulling.', sum: 'Rencana progress EE naik ke 12%.' },
    { nip: 'ASEI-016', type: 'PLAN', ach: '', iss: '', nxt: 'Distribusi 5 electrician: 3 cable tray run-2, 2 persiapan MCC room. Target 80m tray minggu depan.', sum: 'Manpower EE stabil.' },
    { nip: 'ASEI-002', type: 'REPORT', ach: '62 hari tanpa LTI. 6 toolbox meeting, 2 safety patrol/hari, 1 near-miss (jatuh material ringan - sudah ditindaklanjuti).', iss: 'Kepatuhan goggles masih 82%, target 100%.', nxt: 'Re-induction singkat & pengetatan housekeeping score.', sum: 'Safety score mingguan: 91/100.' },
  ]
  for (const w of wr) {
    const emp = all.find(e => e.nip === w.nip)
    if (!emp) continue
    await db.weeklyReport.create({
      data: {
        projectId: pid,
        employeeId: emp.id, role: emp.role, type: w.type,
        weekStart, weekEnd, achievements: w.ach, issues: w.iss, nextWeekPlan: w.nxt,
        progressSummary: w.sum, status: 'SUBMITTED',
      },
    })
  }

  // ============ KPI MONTHLY & WEEKLY ============
  for (const emp of all) {
    const att = 70 + Math.floor(Math.random() * 30)
    const task = 65 + Math.floor(Math.random() * 35)
    const disc = 70 + Math.floor(Math.random() * 30)
    const qual = 65 + Math.floor(Math.random() * 35)
    const safe = 75 + Math.floor(Math.random() * 25)
    const overall = Math.round((att + task + disc + qual + safe) / 5)
    await db.kpiRecord.create({
      data: {
        projectId: pid,
        employeeId: emp.id, period: 'MONTHLY', periodStart: new Date(TODAY.getFullYear(), TODAY.getMonth(), 1),
        periodEnd: new Date(TODAY.getFullYear(), TODAY.getMonth() + 1, 0),
        attendanceScore: att, taskScore: task, disciplineScore: disc, qualityScore: qual, safetyScore: safe,
        overallScore: overall,
        notes: overall >= 85 ? 'Performa sangat baik, pertahankan.' : overall >= 70 ? 'Performa baik, tingkatkan konsistensi.' : 'Perlu coaching & monitoring ketat.',
      },
    })
    await db.kpiRecord.create({
      data: {
        projectId: pid,
        employeeId: emp.id, period: 'WEEKLY', periodStart: weekStart, periodEnd: weekEnd,
        attendanceScore: Math.min(100, att + 3), taskScore: Math.min(100, task + 2), disciplineScore: Math.min(100, disc + 4),
        qualityScore: Math.min(100, qual + 1), safetyScore: Math.min(100, safe + 2),
        overallScore: Math.min(100, overall + 3), notes: 'Score minggu berjalan.',
      },
    })
  }

  // ============ AI SUMMARY sample ============
  await db.aiSummary.create({
    data: {
      projectId: pid,
      scope: 'PROJECT', periodStart: weekStart, periodEnd: weekEnd,
      title: 'Ringkasan Proyek Mingguan (AI)',
      content: 'Proyek EPC Skid Package berjalan di 42.3% vs rencana 45.1%. Civil 58% (pondasi pedestal 70%), Mechanical 48% (fabrikasi Area A 85%), Electrical 8% (cable tray run-1). Zero accident 62 hari. Fokus minggu depan: erection structure level-2, welding spool Area A ramp-up, dan mitigasi delay pump P-101/102 dengan resequence pekerjaan.',
    },
  })

  // ============ ZONA CONTOH DI PROYEK DEFAULT ============
  await db.drawingZone.createMany({ data: [
    { projectId: pid, name: 'Area A - Ponds & Structure', code: 'ZN-A', discipline: 'CIVIL', description: 'Area pondasi, pedestal, dan erection struktur utama.', status: 'ON_PROGRESS', color: '#d97706' },
    { projectId: pid, name: 'Area B - Piping & Equipment', code: 'ZN-B', discipline: 'MECHANICAL', description: 'Area instalasi piping spool & rotating equipment.', status: 'ON_PROGRESS', color: '#ea580c' },
    { projectId: pid, name: 'Rack Listrik & MCC Room', code: 'ZN-C', discipline: 'ELECTRICAL', description: 'Cable rack, panel MCC, dan transformer.', status: 'PLANNED', color: '#059669' },
  ] })

  return { employees: all.length }
}
