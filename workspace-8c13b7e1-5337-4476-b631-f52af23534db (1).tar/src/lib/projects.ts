import { db } from '@/lib/db'
import { createSampleData } from '@/lib/samples'

// ---------- Proyek default ----------
export async function ensureDefaultProject() {
  const existing = await db.project.findFirst({ where: { isDefault: true } })
  if (existing) return existing
  return db.project.create({
    data: {
      code: 'ASEI-EPC-001',
      name: 'EPC Skid Package & Utility Piping',
      client: 'PT. Energi Nusantara',
      location: 'Site Utama - Cilegon',
      description: 'Proyek default bawaan sistem: EPC Skid Package & Utility Piping (Civil • Mechanical • Electrical). Semua data demo lama berada di proyek ini.',
      status: 'ACTIVE',
      startDate: new Date('2026-07-01'),
      endDate: new Date('2026-11-30'),
      isDefault: true,
    },
  })
}

// ---------- Hapus proyek + seluruh datanya ----------
export async function deleteProjectCascade(projectId: string) {
  await db.drawingMark.deleteMany({ where: { projectId } })
  await db.drawingFile.deleteMany({ where: { projectId } })
  await db.drawingZone.deleteMany({ where: { projectId } })
  await db.aiSummary.deleteMany({ where: { projectId } })
  await db.kpiRecord.deleteMany({ where: { projectId } })
  await db.projectDocument.deleteMany({ where: { projectId } })
  await db.weeklyReport.deleteMany({ where: { projectId } })
  await db.dailyReport.deleteMany({ where: { projectId } })
  await db.equipmentDelivery.deleteMany({ where: { projectId } })
  await db.fabricationItem.deleteMany({ where: { projectId } })
  await db.quantityItem.deleteMany({ where: { projectId } })
  await db.wbsTask.deleteMany({ where: { projectId } })
  await db.workTask.deleteMany({ where: { projectId } })
  await db.attendance.deleteMany({ where: { projectId } })
  await db.employee.deleteMany({ where: { projectId } })
  await db.project.delete({ where: { id: projectId } })
}

// ---------- Buat proyek baru (opsional isi data contoh) ----------
export async function createProjectWithSamples(input: {
  name: string; code?: string; client?: string; location?: string; description?: string
  status?: string; startDate?: Date | null; endDate?: Date | null; withSamples?: boolean
}) {
  const project = await db.project.create({
    data: {
      name: input.name,
      code: input.code || '',
      client: input.client || '',
      location: input.location || '',
      description: input.description || '',
      status: input.status || 'ACTIVE',
      startDate: input.startDate ?? null,
      endDate: input.endDate ?? null,
      isDefault: false,
    },
  })
  if (input.withSamples) await createSampleData(project.id)
  return project
}
