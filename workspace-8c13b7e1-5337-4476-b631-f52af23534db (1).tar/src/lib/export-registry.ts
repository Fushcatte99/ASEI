// Registry modul export — pure data, aman dipakai client & server
export interface ExportItem {
  key: string
  label: string
  folder: string // nama folder di dalam ZIP / seksi modul
}

export const EXPORT_SECTIONS: { label: string; keys: string[] }[] = [
  { label: 'Modul Utama', keys: ['ringkasan', 'absensi', 'tenaga-kerja'] },
  { label: 'Eksekusi Proyek', keys: ['work-task', 'quantity', 'fabrikasi', 'equipment', 'planning-wbs', 'gambar', 'zona'] },
  { label: 'Pelaporan & Kinerja', keys: ['laporan-harian', 'laporan-mingguan', 'dokumen', 'kpi', 'ai-summary'] },
]

export const EXPORT_ITEMS: Record<string, ExportItem> = {
  'ringkasan': { key: 'ringkasan', label: 'Ringkasan Dashboard', folder: '1-modul-utama' },
  'absensi': { key: 'absensi', label: 'Absensi & Foto AI', folder: '1-modul-utama' },
  'tenaga-kerja': { key: 'tenaga-kerja', label: 'Tenaga Kerja', folder: '1-modul-utama' },
  'work-task': { key: 'work-task', label: 'Work Task', folder: '2-eksekusi-proyek' },
  'quantity': { key: 'quantity', label: 'Progress — Quantity Terpasang', folder: '2-eksekusi-proyek' },
  'fabrikasi': { key: 'fabrikasi', label: 'Progress — Fabrikasi', folder: '2-eksekusi-proyek' },
  'equipment': { key: 'equipment', label: 'Progress — Equipment Delivery', folder: '2-eksekusi-proyek' },
  'planning-wbs': { key: 'planning-wbs', label: 'Planning & Gantt (WBS)', folder: '2-eksekusi-proyek' },
  'gambar': { key: 'gambar', label: 'Gambar Proyek (daftar)', folder: '2-eksekusi-proyek' },
  'zona': { key: 'zona', label: 'Zona Pekerjaan / Area', folder: '2-eksekusi-proyek' },
  'laporan-harian': { key: 'laporan-harian', label: 'Laporan Harian', folder: '3-pelaporan-kinerja' },
  'laporan-mingguan': { key: 'laporan-mingguan', label: 'Laporan / Rencana Mingguan', folder: '3-pelaporan-kinerja' },
  'dokumen': { key: 'dokumen', label: 'Dokumen Proyek (SOW/JSA)', folder: '3-pelaporan-kinerja' },
  'kpi': { key: 'kpi', label: 'KPI Karyawan', folder: '3-pelaporan-kinerja' },
  'ai-summary': { key: 'ai-summary', label: 'AI Summary', folder: '3-pelaporan-kinerja' },
}

export function exportUrl(key: string, projectId: string): string {
  return `/api/export/${key}?projectId=${encodeURIComponent(projectId)}`
}
