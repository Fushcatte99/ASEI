import ZAI from 'z-ai-web-dev-sdk'

export async function getZai() {
  return ZAI.create()
}

export function extractJson<T>(text: string): T | null {
  if (!text) return null
  let t = text.trim()
  // strip markdown fences
  t = t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')
  // find first { ... } or [ ... ]
  const start = Math.min(...['{', '['].map(c => { const i = t.indexOf(c); return i === -1 ? Infinity : i }))
  if (start === Infinity) return null
  const opener = t[start]
  const closer = opener === '{' ? '}' : ']'
  const end = t.lastIndexOf(closer)
  if (end <= start) return null
  try {
    return JSON.parse(t.slice(start, end + 1)) as T
  } catch {
    return null
  }
}

export type PhotoAnalysis = {
  ppe: { helmet: boolean; vest: boolean; gloves: boolean; boots: boolean; goggles: boolean }
  ppeScore: number
  ppeNotes: string
  emotion: 'happy' | 'neutral' | 'tired' | 'stressed' | 'angry' | 'unknown'
  moodScore: number
  aiNotes: string
  faceDetected: boolean
}

export async function analyzePhoto(dataUrl: string): Promise<PhotoAnalysis> {
  const zai = await getZai()
  const visionBody = {
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: `Kamu adalah inspektur K3 (HSE) proyek konstruksi. Analisis foto pekerja di lokasi proyek ini. Nilai:
1. Kelengkapan APD yang terlihat: helmet (helm), vest (rompi reflektif), gloves (sarung tangan), boots (sepatu safety), goggles (kacamata pelindung) → true/false.
2. ppeScore 0-100 sesuai kelengkapan APD.
3. Ekspresi/kondisi wajah → salah satu: happy, neutral, tired, stressed, angry, unknown (unknown jika wajah tidak terlihat jelas).
4. moodScore 0-100 (indeks kebahagiaan/mental positif: happy tinggi, neutral sedang, tired/stressed rendah).
5. aiNotes: 1-2 kalimat bahasa Indonesia ringkas (fokus APD & kondisi pekerja).
6. faceDetected: apakah wajah terdeteksi.
Jawab HANYA JSON valid tanpa teks lain, format:
{"faceDetected":bool,"ppe":{"helmet":bool,"vest":bool,"gloves":bool,"boots":bool,"goggles":bool},"ppeScore":int,"ppeNotes":"...","emotion":"...","moodScore":int,"aiNotes":"..."}`,
          },
          { type: 'image_url', image_url: { url: dataUrl } },
        ],
      },
    ],
    thinking: { type: 'disabled' },
  }
  const res = await (zai.chat.completions.createVision as unknown as (body: typeof visionBody) => Promise<{ choices?: { message?: { content?: string } }[] }>)(visionBody)
  const content = res.choices?.[0]?.message?.content ?? ''
  const parsed = extractJson<PhotoAnalysis>(content)
  if (parsed) return parsed
  return {
    faceDetected: false,
    ppe: { helmet: false, vest: false, gloves: false, boots: false, goggles: false },
    ppeScore: 0,
    ppeNotes: 'AI tidak dapat menganalisis foto dengan jelas.',
    emotion: 'unknown',
    moodScore: 0,
    aiNotes: content.slice(0, 300) || 'Analisis AI gagal.',
  }
}
