'use client'
import { create } from 'zustand'
import { listRes, api, retry, setActiveProjectId } from '@/lib/client'
import type {
  Project, Employee, Attendance, WorkTask, WbsTask, QuantityItem, FabricationItem,
  EquipmentDelivery, DailyReport, WeeklyReport, ProjectDocument, KpiRecord, AiSummary,
  DrawingZone, Store, SessionInfo,
} from '@/lib/types'

interface AseiStore extends Store {
  loading: boolean
  loaded: boolean
  error: string | null
  projects: Project[]
  activeProjectId: string
  projectSwitching: boolean
  user: SessionInfo | null
  authReady: boolean
  checkAuth: () => Promise<void>
  login: (username: string, password: string) => Promise<{ ok: boolean; error?: string }>
  logout: () => Promise<void>
  forceSignOut: () => void
  fetchAll: () => Promise<void>
  refresh: (resource: string) => Promise<void>
  loadProjects: () => Promise<void>
  switchProject: (id: string) => Promise<void>
  reloadActive: () => Promise<void>
}

const RESOURCES = ['employees', 'attendance', 'tasks', 'wbs', 'quantities', 'fabrications', 'equipment', 'daily-reports', 'weekly-reports', 'documents', 'kpi', 'summaries', 'zones'] as const

const LS_KEY = 'asei-active-project'

export const useAsei = create<AseiStore>((set, get) => ({
  employees: [], attendance: [], tasks: [], wbs: [], quantities: [], fabrications: [],
  equipment: [], dailyReports: [], weeklyReports: [], documents: [], kpi: [], summaries: [],
  zones: [], projects: [], activeProjectId: '', projectSwitching: false,
  user: null, authReady: false,
  loading: false, loaded: false, error: null,

  checkAuth: async () => {
    try {
      const j = await retry(() => api<{ data: SessionInfo }>('/api/auth/me', { timeoutMs: 15000 }))
      set({ user: j.data, authReady: true })
    } catch {
      set({ user: null, authReady: true })
    }
  },

  login: async (username, password) => {
    try {
      const j = await api<{ data: SessionInfo }>('/api/auth/login', {
        method: 'POST', body: JSON.stringify({ username, password }),
      })
      set({ user: j.data, loaded: false })
      await get().loadProjects()
      await get().fetchAll()
      return { ok: true }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Login gagal' }
    }
  },

  logout: async () => {
    try { await api('/api/auth/logout', { method: 'POST' }) } catch { /* ignore */ }
    get().forceSignOut()
  },

  forceSignOut: () => {
    set({
      user: null, loaded: false, loading: false,
      employees: [], attendance: [], tasks: [], wbs: [], quantities: [], fabrications: [],
      equipment: [], dailyReports: [], weeklyReports: [], documents: [], kpi: [], summaries: [],
      zones: [], projects: [],
    })
  },

  loadProjects: async () => {
    if (!get().user) return
    try {
      // Retry utk kegagalan transien — kegagalan total = error terlihat + tombol Coba Lagi
      const data = await retry(() => api<{ data: Project[] }>('/api/projects', { timeoutMs: 20000 }).then(j => j.data))
      let active = get().activeProjectId || (typeof window !== 'undefined' ? localStorage.getItem(LS_KEY) ?? '' : '')
      if (!active || !data.some(p => p.id === active)) {
        const def = data.find(p => p.isDefault) ?? data[0]
        active = def?.id ?? ''
      }
      setActiveProjectId(active)
      if (typeof window !== 'undefined' && active) localStorage.setItem(LS_KEY, active)
      set({ projects: data, activeProjectId: active, error: null })
    } catch (e) {
      // Hanya tandai error bila daftar proyek benar2 kosong (tidak ada data tampil);
      // bila data lama masih ada, biarkan UI jalan & fetchAll yang menandai error
      if (!get().projects.length) set({ error: e instanceof Error ? e.message : String(e) })
    }
  },

  switchProject: async (id: string) => {
    set({ projectSwitching: true, loaded: false })
    setActiveProjectId(id)
    if (typeof window !== 'undefined') localStorage.setItem(LS_KEY, id)
    set({ activeProjectId: id })
    await get().fetchAll()
    set({ projectSwitching: false })
  },

  reloadActive: async () => {
    await get().loadProjects()
    await get().fetchAll()
  },

  fetchAll: async () => {
    if (!get().user) return
    set({ loading: true, error: null })
    try {
      // Setiap resource di-retry mandiri (3x) — satu request gagal tidak lagi menggantung seluruh app
      const results = await Promise.all(RESOURCES.map(r => retry(() => listRes<unknown>(r), 3, 800)))
      const [employees, attendance, tasks, wbs, quantities, fabrications, equipment, dailyReports, weeklyReports, documents, kpi, summaries, zones] = results
      set({
        employees: employees as Employee[], attendance: attendance as Attendance[], tasks: tasks as WorkTask[],
        wbs: wbs as WbsTask[], quantities: quantities as QuantityItem[], fabrications: fabrications as FabricationItem[],
        equipment: equipment as EquipmentDelivery[], dailyReports: dailyReports as DailyReport[],
        weeklyReports: weeklyReports as WeeklyReport[], documents: documents as ProjectDocument[],
        kpi: kpi as KpiRecord[], summaries: summaries as AiSummary[], zones: zones as DrawingZone[],
        loading: false, loaded: true, error: null,
      })
    } catch (e) {
      // PENTING: sebelumnya loaded tidak pernah true saat gagal -> spinner "Memuat data proyek..." selamanya.
      // Kini error disimpan agar UI menampilkan kartu gagal-muat + tombol Coba Lagi.
      set({ error: e instanceof Error ? e.message : String(e), loading: false })
    }
  },
  refresh: async (resource: string) => {
    try {
      const data = await listRes<unknown>(resource)
      const map: Record<string, keyof Store> = {
        employees: 'employees', attendance: 'attendance', tasks: 'tasks', wbs: 'wbs',
        quantities: 'quantities', fabrications: 'fabrications', equipment: 'equipment',
        'daily-reports': 'dailyReports', 'weekly-reports': 'weeklyReports',
        documents: 'documents', kpi: 'kpi', summaries: 'summaries', zones: 'zones',
      }
      const key = map[resource]
      if (key) set({ [key]: data } as unknown as Partial<Store>)
    } catch { /* silent */ }
  },
}))

export function empMap(employees: Employee[]): Record<string, Employee> {
  return Object.fromEntries(employees.map(e => [e.id, e]))
}
export function chainOf(employees: Employee[], emp: Employee): Employee[] {
  const map = empMap(employees)
  const chain: Employee[] = []
  let cur: Employee | undefined = emp
  let guard = 0
  while (cur && guard++ < 10) {
    chain.unshift(cur)
    cur = cur.managerId ? map[cur.managerId] : undefined
  }
  return chain
}
