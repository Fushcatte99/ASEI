'use client'
import { useEffect, useRef, useState } from 'react'
import {
  LayoutDashboard, Clock4, Users, ClipboardList, PackageCheck, CalendarRange,
  FileText, FolderOpen, Target, Bot, Menu, HardHat, RefreshCw, ShieldCheck, X,
  ChevronDown, FolderOpenDot, Plus, Pencil, Trash2, Check, Loader2, Images,
  Upload, Palette, Download, LogOut, UserCog, Save, HardDriveDownload, AlertTriangle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { useAsei } from './store'
import { cn } from '@/lib/utils'
import { api, activeProjectId, PROJECT_STATUS, PROJECT_BADGE, dateInput } from '@/lib/client'
import { useToast } from '@/hooks/use-toast'
import type { Project } from '@/lib/types'
import { ReportDialog } from './report/report-dialog'
import DashboardView from './views/dashboard'
import AttendanceView from './views/attendance'
import WorkforceView from './views/workforce'
import TasksView from './views/tasks'
import ProgressView from './views/progress'
import PlanningView from './views/planning'
import DrawingsView from './views/drawings'
import ReportsView from './views/reports'
import DocumentsView from './views/documents'
import KpiView from './views/kpi'
import AssistantView from './views/assistant'
import LoginView from './views/login'
import AccountsView from './views/accounts'
import { EXPORT_SECTIONS, EXPORT_ITEMS, exportUrl } from '@/lib/export-registry'

const NAV = [
  { section: 'Utama', items: [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'attendance', label: 'Absensi & Foto AI', icon: Clock4 },
    { id: 'workforce', label: 'Tenaga Kerja', icon: Users },
  ] },
  { section: 'Eksekusi Proyek', items: [
    { id: 'tasks', label: 'Work Task', icon: ClipboardList },
    { id: 'progress', label: 'Progress Tracker', icon: PackageCheck },
    { id: 'planning', label: 'Planning & Gantt', icon: CalendarRange },
    { id: 'drawings', label: 'Gambar Proyek & Zona', icon: Images },
  ] },
  { section: 'Pelaporan & Kinerja', items: [
    { id: 'reports', label: 'Laporan & AI Summary', icon: FileText },
    { id: 'documents', label: 'Dokumen (SOW/JSA)', icon: FolderOpen },
    { id: 'kpi', label: 'KPI Karyawan', icon: Target },
  ] },
  { section: 'Kecerdasan Buatan', items: [
    { id: 'assistant', label: 'AI Assistant', icon: Bot },
  ] },
]

const TITLES: Record<string, string> = {
  dashboard: 'Dashboard Proyek', attendance: 'Absensi dengan Analisis Foto AI', workforce: 'Manajemen Tenaga Kerja',
  tasks: 'Work Task & Penugasan', progress: 'Progress Tracker', planning: 'Planning & Gantt Chart',
  drawings: 'Gambar Proyek — Zona, Marking & Anotasi', reports: 'Laporan Harian / Mingguan & AI Summary',
  documents: 'Dokumen Proyek', kpi: 'KPI Karyawan', assistant: 'AI Assistant',
  accounts: 'Manajemen Akun Pengguna',
}

interface ProjForm { name: string; code: string; client: string; location: string; status: string; startDate: string; endDate: string; description: string; withSamples: boolean; brandAppName: string; brandTeamName: string }
const emptyForm: ProjForm = { name: '', code: '', client: '', location: '', status: 'ACTIVE', startDate: '', endDate: '', description: '', withSamples: true, brandAppName: '', brandTeamName: '' }

// ============ Backup / restore proyek ke file lokal (save as / upload) ============
function slugify(v: string): string {
  return v.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'proyek'
}
function stampToday(): string {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}
// File System Access API (Chrome/Edge): "Save As" ke folder lokal pilihan user
interface WritableLike { write: (data: Blob) => Promise<void>; close: () => Promise<void> }
interface FileHandleLike { createWritable: () => Promise<WritableLike> }
type FSWindow = Window & {
  showSaveFilePicker?: (opts?: {
    suggestedName?: string
    types?: { description?: string; accept: Record<string, string[]> }[]
  }) => Promise<FileHandleLike>
}

/** Baca file logo -> data URL terkompres (maks 128px, PNG) agar ringan di DB */
function processLogoFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const src = String(reader.result)
      if (file.type === 'image/svg+xml') {
        if (src.length <= 140_000) return resolve(src)
        return reject(new Error('SVG terlalu besar (maks ~100KB)'))
      }
      const img = new window.Image()
      img.onload = () => {
        try {
          const max = 128
          const scale = Math.min(1, max / Math.max(img.width, img.height))
          const w = Math.max(1, Math.round(img.width * scale))
          const h = Math.max(1, Math.round(img.height * scale))
          const canvas = document.createElement('canvas')
          canvas.width = w
          canvas.height = h
          const ctx = canvas.getContext('2d')
          if (!ctx) return reject(new Error('Canvas tidak didukung browser'))
          ctx.drawImage(img, 0, 0, w, h)
          resolve(canvas.toDataURL('image/png'))
        } catch (err) { reject(err instanceof Error ? err : new Error(String(err))) }
      }
      img.onerror = () => reject(new Error('Gambar tidak bisa dibaca'))
      img.src = src
    }
    reader.onerror = () => reject(new Error('Gagal membaca file'))
    reader.readAsDataURL(file)
  })
}

/** Baca file favicon -> data URL PNG persegi 64x64 (gambar fit di tengah, padding transparan) */
function processFaviconFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.size > 3_000_000) return reject(new Error('File terlalu besar (maks 3MB)'))
    const reader = new FileReader()
    reader.onload = () => {
      const src = String(reader.result)
      const img = new window.Image()
      img.onload = () => {
        try {
          const size = 64
          const canvas = document.createElement('canvas')
          canvas.width = size
          canvas.height = size
          const ctx = canvas.getContext('2d')
          if (!ctx) return reject(new Error('Canvas tidak didukung browser'))
          const scale = Math.min(size / img.width, size / img.height)
          const w = Math.max(1, Math.round(img.width * scale))
          const h = Math.max(1, Math.round(img.height * scale))
          ctx.imageSmoothingEnabled = true
          ctx.imageSmoothingQuality = 'high'
          ctx.drawImage(img, Math.round((size - w) / 2), Math.round((size - h) / 2), w, h)
          resolve(canvas.toDataURL('image/png'))
        } catch (err) { reject(err instanceof Error ? err : new Error(String(err))) }
      }
      img.onerror = () => reject(new Error('Gambar tidak bisa dibaca'))
      img.src = src
    }
    reader.onerror = () => reject(new Error('Gagal membaca file'))
    reader.readAsDataURL(file)
  })
}

export default function AppShell() {
  const [mounted, setMounted] = useState(false)
  const [view, setView] = useState<string>('dashboard')
  const [open, setOpen] = useState(false)
  const [today, setToday] = useState('')
  const [dash, setDash] = useState<{ zeroAccidentDays?: number; progress?: { actualProgress?: number } } | null>(null)
  const [projOpen, setProjOpen] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [form, setForm] = useState<ProjForm>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [delOpen, setDelOpen] = useState(false)
  const [repOpen, setRepOpen] = useState(false)
  const [logoState, setLogoState] = useState<string | null>(null) // null=tidak diubah, ''=hapus, dataURL=ganti
  const [faviconState, setFaviconState] = useState<string | null>(null) // null=tidak diubah, ''=hapus, dataURL=ganti
  const [backupBusy, setBackupBusy] = useState(false)
  const [importBusy, setImportBusy] = useState(false)
  const uploadRef = useRef<HTMLInputElement>(null)
  const { fetchAll, loadProjects, switchProject, reloadActive, loading, loaded, error, projects, activeProjectId: apid, projectSwitching, user, authReady, checkAuth, logout, forceSignOut } = useAsei()
  const { toast } = useToast()

  const active = projects.find(p => p.id === apid) ?? null
  // Seksi Admin hanya tampil untuk Master Admin
  const navSections = user?.role === 'MASTER_ADMIN'
    ? [...NAV, { section: 'Admin', items: [{ id: 'accounts', label: 'Manajemen Akun', icon: UserCog }] }]
    : NAV

  // ===== Branding per proyek (fallback ke default ASEI bila kosong) =====
  const appName = (active?.brandAppName ?? '').trim() || 'ASEI HR'
  const teamName = (active?.brandTeamName ?? '').trim() || 'ASEI EPC Team'
  const logoSrc = (active?.brandLogo ?? '').trim() || '/logo-asei.png'
  const faviconSrc = (active?.brandFavicon ?? '').trim() || '/icon.png'
  // Pratinjau logo di dialog edit: '' berarti logo default
  const logoPreview = logoState === null ? (active?.brandLogo ?? '') : logoState
  // Pratinjau favicon di dialog edit: '' berarti favicon default
  const faviconPreview = faviconState === null ? (active?.brandFavicon ?? '') : faviconState

  // Terapkan favicon dinamis: ganti href semua <link> ikon yang disuntikkan Next.js
  useEffect(() => {
    if (!mounted) return
    const links = document.querySelectorAll<HTMLLinkElement>('link[rel="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]')
    links.forEach(l => { l.href = faviconSrc })
  }, [faviconSrc, mounted])

  useEffect(() => { setMounted(true) }, [])
  useEffect(() => { checkAuth() }, [checkAuth])
  // Muat daftar proyek SETELAH sesi user siap — saat refresh halaman user dipulihkan via checkAuth,
  // jalan efek ini yang memicu loadProjects -> apid terisi -> fetchAll otomatis jalan
  useEffect(() => { if (user) loadProjects() }, [user, loadProjects])
  // Sesi berakhir (401 dari API mana pun) -> kembali ke halaman login
  useEffect(() => {
    const onUnauth = () => forceSignOut()
    window.addEventListener('asei:unauth', onUnauth)
    return () => window.removeEventListener('asei:unauth', onUnauth)
  }, [forceSignOut])
  useEffect(() => {
    setToday(new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }))
  }, [])
  useEffect(() => { if (apid && user) fetchAll() }, [apid, user, fetchAll])
  useEffect(() => {
    if (!user) return
    fetch(`/api/dashboard?projectId=${apid}`).then(r => r.json()).then(j => setDash(j?.data ?? null)).catch(() => {})
  }, [apid, user])
  useEffect(() => {
    document.title = `${appName} Project Management`
  }, [appName])
  // Guard view: staff tidak boleh berada di view Manajemen Akun (mis. sisa sesi admin)
  useEffect(() => {
    if (user && view === 'accounts' && user.role !== 'MASTER_ADMIN') setView('dashboard')
  }, [user, view])

  const go = (id: string) => { setView(id); setOpen(false) }

  const openCreate = () => { setEditMode(false); setForm(emptyForm); setLogoState(null); setFaviconState(null); setProjOpen(true) }
  const openEdit = () => {
    if (!active) return
    setEditMode(true)
    setForm({
      name: active.name, code: active.code, client: active.client, location: active.location,
      status: active.status, startDate: dateInput(active.startDate), endDate: dateInput(active.endDate),
      description: active.description, withSamples: false,
      brandAppName: active.brandAppName ?? '', brandTeamName: active.brandTeamName ?? '',
    })
    setLogoState(null)
    setFaviconState(null)
    setProjOpen(true)
  }

  const onFaviconPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const dataUrl = await processFaviconFile(file)
      setFaviconState(dataUrl)
      toast({ title: 'Favicon siap — klik "Simpan Perubahan" untuk menerapkan' })
    } catch (err) {
      toast({ title: 'Gagal memproses favicon', description: err instanceof Error ? err.message : String(err), variant: 'destructive' })
    }
  }

  const onLogoPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const dataUrl = await processLogoFile(file)
      setLogoState(dataUrl)
      toast({ title: 'Logo siap — klik "Simpan Perubahan" untuk menerapkan' })
    } catch (err) {
      toast({ title: 'Gagal memproses logo', description: err instanceof Error ? err.message : String(err), variant: 'destructive' })
    }
  }

  const submitProject = async () => {
    if (!form.name.trim()) return
    setSaving(true)
    try {
      if (editMode && active) {
        const body: Record<string, unknown> = { ...form }
        if (logoState !== null) body.brandLogo = logoState
        if (faviconState !== null) body.brandFavicon = faviconState
        await api(`/api/projects/${active.id}`, { method: 'PATCH', body: JSON.stringify(body) })
        await reloadActive()
        setProjOpen(false)
        toast({ title: 'Info proyek & branding disimpan' })
      } else {
        const { brandAppName: _ba, brandTeamName: _bt, ...createForm } = form
        void _ba; void _bt
        const j = await api<{ data: Project }>('/api/projects', { method: 'POST', body: JSON.stringify(createForm) })
        setProjOpen(false)
        await loadProjects()
        await switchProject(j.data.id)
        setView('dashboard')
      }
    } catch { /* toast via error state */ }
    finally { setSaving(false) }
  }

  const deleteProject = async () => {
    if (!active || active.isDefault) return
    setDelOpen(false)
    const def = projects.find(p => p.isDefault)
    await api(`/api/projects/${active.id}`, { method: 'DELETE' }).catch(() => {})
    if (def) await switchProject(def.id)
    await loadProjects()
  }

  // ===== SIMPAN PROYEK KE FOLDER LOKAL (save as) =====
  // File System Access API bila tersedia (pilih folder & nama file), fallback unduh biasa
  const saveProjectLocal = async () => {
    if (!active || backupBusy) return
    setBackupBusy(true)
    let handle: FileHandleLike | null = null
    const fname = `backup-proyek-${slugify(active.code || active.name)}-${stampToday()}.zip`
    try {
      const w = window as FSWindow
      // navigator.webdriver = browser otomatis/headless -> showSaveFilePicker bisa menggantung tanpa UI,
      // langsung pakai fallback unduh. Browser user nyata (Chrome/Edge) tetap dapat dialog "Save As".
      if (typeof w.showSaveFilePicker === 'function' && !navigator.webdriver) {
        try {
          handle = await w.showSaveFilePicker({
            suggestedName: fname,
            types: [{ description: 'Backup Proyek ASEI (ZIP)', accept: { 'application/zip': ['.zip'] } }],
          })
        } catch (err) {
          if (err instanceof Error && err.name === 'AbortError') return // user batal pilih lokasi
          handle = null // browser lain / error -> fallback unduh
        }
      }
      const res = await fetch(`/api/projects/${active.id}/backup`, { cache: 'no-store' })
      if (!res.ok) {
        const j = await res.json().catch(() => ({}))
        throw new Error((j as { error?: string })?.error || `HTTP ${res.status}`)
      }
      const blob = await res.blob()
      const kb = (blob.size / 1024).toFixed(0)
      if (handle) {
        const wr = await handle.createWritable()
        await wr.write(blob)
        await wr.close()
        toast({ title: 'Backup tersimpan di folder lokal', description: `${fname} • ${kb} KB — berisi seluruh data, gambar & branding proyek` })
      } else {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = fname
        document.body.appendChild(a)
        a.click()
        a.remove()
        setTimeout(() => URL.revokeObjectURL(url), 5000)
        toast({ title: 'Backup proyek diunduh', description: `${fname} • ${kb} KB — pindahkan ke folder lokal Anda (USB/network drive juga bisa)` })
      }
    } catch (err) {
      toast({ title: 'Gagal membuat backup proyek', description: err instanceof Error ? err.message : String(err), variant: 'destructive' })
    } finally { setBackupBusy(false) }
  }

  // ===== UPLOAD / PULIHKAN PROYEK DARI FILE LOKAL =====
  const statLine = (stats?: Record<string, number>) => {
    if (!stats) return undefined
    const parts: string[] = []
    if (stats.employees) parts.push(`${stats.employees} karyawan`)
    if (stats.attendance) parts.push(`${stats.attendance} absensi`)
    if (stats.tasks) parts.push(`${stats.tasks} task`)
    if (stats.wbs) parts.push(`${stats.wbs} WBS`)
    if (stats.drawings) parts.push(`${stats.drawings} gambar`)
    if (stats.marks) parts.push(`${stats.marks} marking`)
    return parts.length ? parts.join(' • ') : 'proyek tanpa data'
  }
  const importProjectLocal = async (file: File) => {
    if (importBusy) return
    setImportBusy(true)
    try {
      let payload: unknown
      const nm = file.name.toLowerCase()
      if (nm.endsWith('.zip')) {
        const JSZip = (await import('jszip')).default
        const zip = await JSZip.loadAsync(await file.arrayBuffer())
        const entry = zip.file('data.json')
        if (!entry) throw new Error('File bukan backup proyek ASEI (data.json tidak ditemukan di dalam ZIP)')
        payload = JSON.parse(await entry.async('string'))
      } else if (nm.endsWith('.json')) {
        payload = JSON.parse(await file.text())
      } else {
        throw new Error('Pilih file backup proyek (.zip) atau data.json')
      }
      const j = await api<{ data: { id: string; name: string; stats: Record<string, number> } }>('/api/projects/import', {
        method: 'POST', body: JSON.stringify(payload),
      })
      await loadProjects()
      await switchProject(j.data.id)
      setView('dashboard')
      toast({ title: `Proyek berhasil dipulihkan: ${j.data.name}`, description: statLine(j.data.stats) })
    } catch (err) {
      toast({ title: 'Gagal mengimpor proyek', description: err instanceof Error ? err.message : String(err), variant: 'destructive' })
    } finally { setImportBusy(false) }
  }

  const sidebar = (
    <div className="flex h-full flex-col bg-slate-900 text-slate-100">
      <div className="flex items-center gap-3 px-4 py-5 border-b border-slate-800">
        <div className="rounded-xl bg-white px-1.5 py-1 shadow-lg shadow-orange-900/40 ring-1 ring-slate-700/60 flex items-center justify-center">
          <img src={logoSrc} alt={`Logo ${appName}`} className="h-8 w-auto object-contain" />
        </div>
        <div className="leading-tight">
          <p className="font-bold tracking-tight text-sm">{appName}</p>
          <p className="text-[11px] text-amber-400 font-medium">Project Management</p>
        </div>
        <button className="ml-auto lg:hidden text-slate-400 hover:text-white" onClick={() => setOpen(false)} aria-label="Tutup menu">
          <X className="h-5 w-5" />
        </button>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
        {navSections.map(group => (
          <div key={group.section}>
            <p className="px-2 mb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">{group.section}</p>
            <div className="space-y-1">
              {group.items.map(item => (
                <button
                  key={item.id}
                  onClick={() => go(item.id)}
                  className={cn(
                    'w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors text-left',
                    view === item.id
                      ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md shadow-orange-900/30'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>
      <div className="border-t border-slate-800 p-4">
        <div className="rounded-lg bg-slate-800/70 p-3">
          <div className="flex items-center gap-2 text-emerald-400">
            <ShieldCheck className="h-4 w-4" />
            <span className="text-xs font-semibold">Zero Accident</span>
          </div>
          <p className="text-xl font-bold mt-1">{dash?.zeroAccidentDays ?? 62} <span className="text-xs font-normal text-slate-400">hari</span></p>
          <div className="flex items-center gap-1.5 mt-2 text-[11px] text-slate-400">
            <span className="rounded bg-slate-700 px-1.5 py-0.5 font-semibold text-amber-400">{dash?.progress?.actualProgress ?? 42.3}%</span>
            progress fisik proyek
          </div>
        </div>
      </div>
    </div>
  )

  const projFormBody = (
    <div className="grid gap-3">
      <div className="grid gap-1.5">
        <Label htmlFor="pj-name">Nama Proyek *</Label>
        <Input id="pj-name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Revamp Utility Area-2" />
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="pj-code">Kode Proyek</Label>
          <Input id="pj-code" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} placeholder="cth: ASEI-PRJ-002" />
        </div>
        <div className="grid gap-1.5">
          <Label>Status</Label>
          <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(PROJECT_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="pj-client">Client / Owner</Label>
          <Input id="pj-client" value={form.client} onChange={e => setForm(f => ({ ...f, client: e.target.value }))} placeholder="cth: PT. Energi Nusantara" />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="pj-loc">Lokasi</Label>
          <Input id="pj-loc" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="cth: Cilegon, Banten" />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="pj-start">Tanggal Mulai</Label>
          <Input id="pj-start" type="date" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="pj-end">Tanggal Selesai</Label>
          <Input id="pj-end" type="date" value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} />
        </div>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="pj-desc">Deskripsi</Label>
        <Textarea id="pj-desc" rows={2} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Lingkup singkat proyek..." />
      </div>
      {editMode && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-3">
          <p className="text-xs font-semibold text-slate-600 flex items-center gap-1.5"><Palette className="h-3.5 w-3.5" /> Branding Aplikasi — khusus proyek ini</p>
          <div className="flex items-center gap-3">
            <div className="h-16 w-16 rounded-lg bg-white ring-1 ring-slate-200 flex items-center justify-center overflow-hidden shrink-0">
              {logoPreview
                ? <img src={logoPreview} alt="Pratinjau logo" className="h-full w-full object-contain p-1" />
                : <HardHat className="h-6 w-6 text-slate-300" />}
            </div>
            <div className="min-w-0 space-y-1.5">
              <div className="flex flex-wrap gap-2">
                <label className="inline-flex items-center gap-1.5 rounded-md border bg-white px-2.5 py-1.5 text-xs font-medium cursor-pointer hover:bg-slate-100">
                  <Upload className="h-3.5 w-3.5" /> Upload Logo
                  <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={onLogoPick} />
                </label>
                {(logoState !== null || !!active?.brandLogo) && (
                  <button type="button" onClick={() => setLogoState(logoState === '' ? (active?.brandLogo ?? null) : '')} className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-white px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50">
                    <X className="h-3.5 w-3.5" /> {logoState === '' ? 'Batalkan Hapus' : 'Hapus Logo'}
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">PNG/JPG/WebP/SVG, otomatis dikecilkan. Dikosongkan = pakai logo default.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-lg bg-white ring-1 ring-slate-200 flex items-center justify-center overflow-hidden shrink-0">
              <img src={faviconPreview || '/icon.png'} alt="Pratinjau favicon" className="h-8 w-8 object-contain" />
            </div>
            <div className="min-w-0 space-y-1.5">
              <div className="flex flex-wrap gap-2">
                <label className="inline-flex items-center gap-1.5 rounded-md border bg-white px-2.5 py-1.5 text-xs font-medium cursor-pointer hover:bg-slate-100">
                  <Upload className="h-3.5 w-3.5" /> Upload Favicon
                  <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={onFaviconPick} />
                </label>
                {(faviconState !== null || !!active?.brandFavicon) && (
                  <button type="button" onClick={() => setFaviconState(faviconState === '' ? (active?.brandFavicon ?? null) : '')} className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-white px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50">
                    <X className="h-3.5 w-3.5" /> {faviconState === '' ? 'Batalkan Hapus' : 'Hapus Favicon'}
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">Ikon kecil di tab browser, otomatis dipadatkan 64×64. Dikosongkan = pakai favicon default.</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="pj-appname">Nama Aplikasi</Label>
              <Input id="pj-appname" value={form.brandAppName} onChange={e => setForm(f => ({ ...f, brandAppName: e.target.value }))} placeholder="ASEI HR" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="pj-teamname">Nama Tim</Label>
              <Input id="pj-teamname" value={form.brandTeamName} onChange={e => setForm(f => ({ ...f, brandTeamName: e.target.value }))} placeholder="ASEI EPC Team" />
            </div>
          </div>
          <p className="text-[11px] text-slate-400">Kosongkan Nama Aplikasi / Nama Tim untuk memakai default (ASEI HR • ASEI EPC Team).</p>
        </div>
      )}
      {!editMode && (
        <div className="flex items-center gap-2 rounded-lg border bg-slate-50 p-3">
          <Switch id="pj-sample" checked={form.withSamples} onCheckedChange={v => setForm(f => ({ ...f, withSamples: v }))} />
          <Label htmlFor="pj-sample" className="text-xs font-normal leading-snug">
            Isi data contoh (2-3 record per modul: tenaga kerja, task, WBS, quantity, fabrikasi, equipment, dokumen, laporan, zona) agar bisa langsung diedit
          </Label>
        </div>
      )}
    </div>
  )

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="flex items-center gap-3 text-slate-500">
          <img src="/logo-asei.png" alt="Logo ASEI" className="h-9 w-9 object-contain animate-pulse" />
          <span className="text-sm font-medium">Memuat ASEI HR Project Management...</span>
        </div>
      </div>
    )
  }

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="flex items-center gap-3 text-slate-500">
          <img src="/logo-asei.png" alt="Logo ASEI" className="h-9 w-9 object-contain animate-pulse" />
          <span className="text-sm font-medium">Memeriksa sesi...</span>
        </div>
      </div>
    )
  }

  // Belum login -> tampilkan halaman login
  if (!user) return <LoginView />

  return (
    <div className="min-h-screen flex bg-slate-100">
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">{sidebar}</aside>
      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-72 shadow-2xl">{sidebar}</aside>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
          <div className="flex items-center gap-3 px-4 sm:px-6 py-3">
            <Button variant="outline" size="icon" className="lg:hidden" onClick={() => setOpen(true)} aria-label="Buka menu">
              <Menu className="h-5 w-5" />
            </Button>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate">{TITLES[view]}</h1>
              <p className="text-[11px] sm:text-xs text-slate-500 hidden sm:block truncate max-w-md">
                {active ? `${active.code ? active.code + ' • ' : ''}${active.name}${active.location ? ' • ' + active.location : ''}` : 'Memuat proyek...'}{today ? ` • ${today}` : ''}
              </p>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {/* Unduh data semua modul (CSV / ZIP) */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5" title="Unduh data modul">
                    <Download className="h-4 w-4 text-emerald-600" />
                    <span className="hidden lg:inline">Unduh</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-72">
                  <DropdownMenuItem onClick={() => setRepOpen(true)} className="gap-2 text-amber-700 font-semibold">
                    <FileText className="h-4 w-4 text-amber-600" />
                    <div className="min-w-0">
                      <p>General Report (PDF)</p>
                      <p className="text-[10px] text-slate-400 font-normal">Grafik + Gantt + timeline, pilih seksi via checklist</p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-[11px] uppercase tracking-wide text-slate-500">Unduh Data Modul (CSV)</DropdownMenuLabel>
                  {EXPORT_SECTIONS.map(sec => (
                    <div key={sec.label}>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-[10px] uppercase tracking-wide text-slate-400">{sec.label}</DropdownMenuLabel>
                      {sec.keys.map(k => (
                        <DropdownMenuItem key={k} onClick={() => { window.location.href = exportUrl(k, apid) }} className="gap-2 text-xs">
                          <Download className="h-3.5 w-3.5 text-slate-400 shrink-0" /> {EXPORT_ITEMS[k]?.label ?? k}
                        </DropdownMenuItem>
                      ))}
                    </div>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => { window.location.href = exportUrl('all', apid) }} className="gap-2 text-amber-700 font-semibold">
                    <Download className="h-4 w-4" /> Unduh Semua Modul (ZIP)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              {/* Project switcher */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5 max-w-[200px] sm:max-w-[280px]">
                    <FolderOpenDot className="h-4 w-4 shrink-0 text-amber-600" />
                    <span className="truncate text-xs font-medium">{active?.name ?? 'Pilih Proyek'}</span>
                    {projectSwitching ? <Loader2 className="h-3.5 w-3.5 animate-spin shrink-0" /> : <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-60" />}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <DropdownMenuLabel className="text-[11px] uppercase tracking-wide text-slate-500">Load / Ganti Proyek</DropdownMenuLabel>
                  {projects.map(p => (
                    <DropdownMenuItem key={p.id} onClick={() => p.id !== apid && switchProject(p.id)} className="gap-2 items-start py-2.5">
                      <span className="mt-0.5 w-4 flex justify-center shrink-0">
                        {p.id === apid && <Check className="h-4 w-4 text-emerald-600" />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-medium truncate">{p.name}</span>
                        <span className="block text-[11px] text-slate-500 truncate">
                          {p.code ? p.code + ' • ' : ''}{p.client || 'Tanpa client'}
                        </span>
                      </span>
                      <span className={cn('shrink-0 rounded border px-1.5 py-0.5 text-[10px] font-semibold', PROJECT_BADGE[p.status])}>
                        {p.isDefault ? 'DEFAULT' : PROJECT_STATUS[p.status] ?? p.status}
                      </span>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={openCreate} className="gap-2 text-amber-700 font-medium">
                    <Plus className="h-4 w-4" /> Buat Proyek Baru
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={openEdit} disabled={!active} className="gap-2">
                    <Pencil className="h-4 w-4" /> Edit Info Proyek (Simpan)
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-[11px] uppercase tracking-wide text-slate-500">Backup Lokal (Save As / Upload)</DropdownMenuLabel>
                  <DropdownMenuItem onClick={saveProjectLocal} disabled={!active || backupBusy} className="gap-2">
                    {backupBusy ? <Loader2 className="h-4 w-4 animate-spin shrink-0" /> : <Save className="h-4 w-4 text-emerald-600 shrink-0" />}
                    <span className="min-w-0">
                      <span className="block text-sm font-medium">Simpan Proyek ke Folder Lokal</span>
                      <span className="block text-[10px] text-slate-400">File .zip berisi seluruh data + gambar + branding (save as)</span>
                    </span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => uploadRef.current?.click()} disabled={importBusy} className="gap-2">
                    {importBusy ? <Loader2 className="h-4 w-4 animate-spin shrink-0" /> : <HardDriveDownload className="h-4 w-4 text-sky-600 shrink-0" />}
                    <span className="min-w-0">
                      <span className="block text-sm font-medium">Upload / Pulihkan dari Folder</span>
                      <span className="block text-[10px] text-slate-400">Pilih file backup .zip → dibuat salinan proyek lengkap</span>
                    </span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setDelOpen(true)} disabled={!active?.isDefault ? false : true} className="gap-2 text-red-600 focus:text-red-600">
                    <Trash2 className="h-4 w-4" /> Hapus Proyek Aktif
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button variant="outline" size="sm" onClick={() => fetchAll()} disabled={loading || projectSwitching} className="gap-1.5 hidden sm:inline-flex">
                <RefreshCw className={cn('h-3.5 w-3.5', loading && 'animate-spin')} />
                <span className="hidden sm:inline">Refresh</span>
              </Button>
              <div className="hidden md:flex items-center gap-2 rounded-full bg-slate-900 text-white pl-1 pr-3 py-1">
                <div className="rounded-full bg-white p-0.5 flex items-center justify-center overflow-hidden">
                  <img src={logoSrc} alt={`Logo ${teamName}`} className="h-4 w-4 object-contain" />
                </div>
                <span className="text-xs font-medium">{teamName}</span>
              </div>
              {/* Chip akun + keluar */}
              <div className="hidden sm:flex items-center gap-1.5 rounded-full border bg-white pl-1 pr-2 py-1">
                <div className="h-6 w-6 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 text-white text-[10px] font-bold flex items-center justify-center">
                  {(user?.name || user?.username || '?').slice(0, 2).toUpperCase()}
                </div>
                <div className="leading-none pr-1">
                  <p className="text-[11px] font-semibold text-slate-800 max-w-[110px] truncate">{user?.username}</p>
                  <p className="text-[9px] text-slate-400">{user?.role === 'MASTER_ADMIN' ? 'Master Admin' : 'Staff'}</p>
                </div>
                <button onClick={() => logout()} className="p-1 rounded-full text-slate-400 hover:text-red-600 hover:bg-red-50" title="Keluar">
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              </div>
              <Button variant="outline" size="icon" className="sm:hidden" onClick={() => logout()} title="Keluar">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
          {projectSwitching && (
            <div className="h-0.5 w-full bg-amber-200 overflow-hidden"><div className="h-full w-1/3 bg-amber-500 animate-pulse" /></div>
          )}
        </header>
        <main className="flex-1 p-4 sm:p-6">
          {!loaded && !projectSwitching ? (
            error ? (
              /* Gagal memuat: tampilkan penyebab + tombol coba lagi (bukan spinner selamanya) */
              <div className="flex flex-col items-center justify-center py-24 gap-3 text-center">
                <AlertTriangle className="h-9 w-9 text-amber-500" />
                <div>
                  <p className="text-sm font-bold text-slate-800">Gagal memuat data proyek</p>
                  <p className="text-xs text-slate-500 max-w-md mt-1">{error}</p>
                  <p className="text-[11px] text-slate-400 max-w-md mt-1">Koneksi ke server mungkin terputus atau server sedang sibuk. Data lama tetap aman.</p>
                </div>
                <Button size="sm" onClick={() => reloadActive()} disabled={loading} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white">
                  <RefreshCw className="h-4 w-4" /> Coba Lagi
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-24 gap-3 text-slate-400">
                <Loader2 className="h-8 w-8 animate-spin" />
                <p className="text-sm">Memuat data proyek...</p>
              </div>
            )
          ) : (
            <>
              {view === 'dashboard' && <DashboardView onNavigate={go} />}
              {view === 'attendance' && <AttendanceView />}
              {view === 'workforce' && <WorkforceView />}
              {view === 'tasks' && <TasksView />}
              {view === 'progress' && <ProgressView />}
              {view === 'planning' && <PlanningView />}
              {view === 'drawings' && <DrawingsView />}
              {view === 'reports' && <ReportsView />}
              {view === 'documents' && <DocumentsView />}
              {view === 'kpi' && <KpiView />}
              {view === 'assistant' && <AssistantView />}
              {view === 'accounts' && <AccountsView />}
            </>
          )}
        </main>
        <footer className="border-t border-slate-200 bg-white py-3 px-6 mt-auto">
          <p className="text-xs text-slate-400 text-center">© 2026 {appName} Project Management • Integrated Construction Workforce & Progress Platform (Civil • Mechanical • Electrical)</p>
        </footer>
      </div>

      {/* Dialog buat / edit proyek */}
      <Dialog open={projOpen} onOpenChange={setProjOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>{editMode ? 'Edit & Simpan Info Proyek' : 'Buat Proyek Baru'}</DialogTitle>
          </DialogHeader>
          {projFormBody}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setProjOpen(false)}>Batal</Button>
            <Button onClick={submitProject} disabled={saving || !form.name.trim()} className="gap-1.5">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {editMode ? 'Simpan Perubahan' : 'Buat Proyek'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus proyek */}
      <AlertDialog open={delOpen} onOpenChange={setDelOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus proyek &quot;{active?.name}&quot;?</AlertDialogTitle>
            <AlertDialogDescription>
              Seluruh data proyek ini (tenaga kerja, task, progress, laporan, gambar, zona & marking) akan dihapus permanen dan tidak bisa dikembalikan. Proyek default tidak dapat dihapus.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={deleteProject} className="bg-red-600 hover:bg-red-700">Ya, Hapus Proyek</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Input file backup proyek (upload / pulihkan dari folder lokal) */}
      <input
        ref={uploadRef}
        type="file"
        accept=".zip,.json"
        className="hidden"
        onChange={e => {
          const f = e.target.files?.[0]
          e.target.value = ''
          if (f) importProjectLocal(f)
        }}
      />

      {/* Dialog General Report (PDF) */}
      <ReportDialog open={repOpen} onOpenChange={setRepOpen} projectId={apid} projectName={active?.name ?? ''} />
    </div>
  )
}
