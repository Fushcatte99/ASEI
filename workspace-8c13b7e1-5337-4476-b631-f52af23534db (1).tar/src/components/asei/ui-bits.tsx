'use client'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { initials } from '@/lib/client'

const COLORS: Record<string, string> = {
  amber: 'bg-amber-500', emerald: 'bg-emerald-500', orange: 'bg-orange-500', teal: 'bg-teal-500',
  rose: 'bg-rose-500', lime: 'bg-lime-600', cyan: 'bg-cyan-500', violet: 'bg-violet-500',
  slate: 'bg-slate-500',
}

export function AseiAvatar({ name, color = 'amber', className = 'h-9 w-9' }: { name: string; color?: string; className?: string }) {
  return (
    <Avatar className={className}>
      <AvatarFallback className={`${COLORS[color] ?? COLORS.amber} text-white text-xs font-semibold`}>
        {initials(name)}
      </AvatarFallback>
    </Avatar>
  )
}

export function SimpleBar({ value, color = 'bg-amber-500', height = 'h-2', className = '' }: { value: number; color?: string; height?: string; className?: string }) {
  return (
    <div className={`w-full ${height} rounded-full bg-slate-200/80 overflow-hidden ${className}`}>
      <div className={`${height} rounded-full ${color} transition-all duration-500`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  )
}

export function StatCard({ title, value, sub, icon, accent = 'bg-amber-500', onClick }: {
  title: string; value: string | number; sub?: string; icon?: React.ReactNode; accent?: string; onClick?: () => void
}) {
  return (
    <div onClick={onClick} className={`rounded-xl border bg-card p-4 shadow-sm transition-all ${onClick ? 'cursor-pointer hover:shadow-md hover:-translate-y-0.5' : ''}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground truncate">{title}</p>
          <p className="text-2xl font-bold tracking-tight mt-1">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-1 truncate">{sub}</p>}
        </div>
        {icon && <div className={`rounded-lg ${accent} p-2 text-white shrink-0`}>{icon}</div>}
      </div>
    </div>
  )
}

export function Chip({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <span className={`inline-flex items-center rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${className}`}>{children}</span>
}

export function EmptyState({ icon, title, sub }: { icon?: React.ReactNode; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {icon && <div className="text-slate-300 mb-3">{icon}</div>}
      <p className="text-sm font-medium text-slate-500">{title}</p>
      {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
    </div>
  )
}
