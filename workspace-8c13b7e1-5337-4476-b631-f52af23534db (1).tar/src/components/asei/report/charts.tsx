'use client'
// Wrapper recharts untuk laporan — tinggi tetap, warna cetak-preservasi
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts'

export const PALETTE = ['#d97706', '#ea580c', '#059669', '#2563eb', '#7c3aed', '#dc2626', '#0d9488', '#64748b']
const AXIS = { fontSize: 9, fill: '#64748b' }

const tooltipStyle = { fontSize: 11, borderRadius: 8, border: '1px solid #e2e8f0' }

export function TrendArea({ data, height = 180 }: { data: { date: string; present: number; ppe: number; mood: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
        <defs>
          <linearGradient id="gPresent" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#059669" stopOpacity={0.35} />
            <stop offset="100%" stopColor="#059669" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis dataKey="date" tick={AXIS} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} interval="preserveStartEnd" />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10 }} />
        <Area type="monotone" dataKey="present" name="Hadir" stroke="#059669" strokeWidth={2} fill="url(#gPresent)" />
        <Line type="monotone" dataKey="ppe" name="Skor APD" stroke="#d97706" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="mood" name="Indeks Mood" stroke="#2563eb" strokeWidth={2} dot={false} strokeDasharray="4 3" />
      </AreaChart>
    </ResponsiveContainer>
  )
}

export function StatusPie({ data, height = 170, colors = PALETTE }: { data: { name: string; value: number }[]; height?: number; colors?: string[] }) {
  const filtered = data.filter(d => d.value > 0)
  if (!filtered.length) return <EmptyChart height={height} />
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie data={filtered} dataKey="value" nameKey="name" innerRadius="52%" outerRadius="80%" paddingAngle={2} strokeWidth={1} stroke="#fff">
          {filtered.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
        </Pie>
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10 }} />
      </PieChart>
    </ResponsiveContainer>
  )
}

export function GroupedBars({ data, series, height = 190, xKey = 'name' }: {
  data: Record<string, string | number>[]
  series: { key: string; name: string; color: string }[]
  height?: number
  xKey?: string
}) {
  if (!data.length) return <EmptyChart height={height} />
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis dataKey={xKey} tick={AXIS} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10 }} />
        {series.map(s => <Bar key={s.key} dataKey={s.key} name={s.name} fill={s.color} radius={[3, 3, 0, 0]} maxBarSize={26} />)}
      </BarChart>
    </ResponsiveContainer>
  )
}

export function HBars({ data, height, color = '#d97706' }: { data: { name: string; value: number }[]; height?: number; color?: string }) {
  if (!data.length) return <EmptyChart height={height ?? 180} />
  const h = height ?? Math.max(150, data.length * 24 + 40)
  return (
    <ResponsiveContainer width="100%" height={h}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 26, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
        <XAxis type="number" tick={AXIS} tickLine={false} axisLine={false} domain={[0, 100]} />
        <YAxis type="category" dataKey="name" tick={{ ...AXIS, fontSize: 9 }} tickLine={false} axisLine={false} width={110} />
        <Tooltip contentStyle={tooltipStyle} />
        <Bar dataKey="value" fill={color} radius={[0, 3, 3, 0]} maxBarSize={14} label={{ position: 'right', fontSize: 9, fill: '#475569' }} />
      </BarChart>
    </ResponsiveContainer>
  )
}

export function MoodLine({ data, height = 150 }: { data: { date: string; mood: number; ppe: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 6, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis dataKey="date" tick={AXIS} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} interval="preserveStartEnd" />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} domain={[0, 100]} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10 }} />
        <Line type="monotone" dataKey="ppe" name="APD" stroke="#d97706" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="mood" name="Mood" stroke="#db2777" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  )
}

function EmptyChart({ height }: { height: number }) {
  return (
    <div className="flex items-center justify-center rounded-lg border border-dashed border-slate-200 text-[10px] text-slate-400" style={{ height }}>
      Tidak ada data untuk grafik ini
    </div>
  )
}
