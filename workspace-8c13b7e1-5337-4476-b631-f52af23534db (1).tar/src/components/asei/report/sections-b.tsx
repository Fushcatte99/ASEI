'use client'
// Seksi laporan B: Timeline, Gantt, Progress Fisik, Laporan Harian/Mingguan, KPI, Dokumen, Gambar&Zona, AI Summary
import { DISC_LABEL, ATT_STATUS, WBS_STATUS, TASK_STATUS, EQ_STATUS, FAB_STATUS, DOC_TYPES, DOC_PHASE, ZONE_STATUS, statusBadge, fmtDate, fmtTime, scoreColor, ROLE_LABEL } from '@/lib/client'
import { inRange, fmtIDN } from '@/lib/report'
import { SectionHeader, ReportCard, MiniStat, Chip, Table, Tr, Td, Bar, Truncated, empName } from './shared'
import type { SecProps } from './shared'
import { GanttChart, Timeline, type TimelineEvent } from './gantt'
import { HBars, StatusPie } from './charts'

const ZONE_HEX: Record<string, string> = { PLANNED: '#94a3b8', ON_PROGRESS: '#d97706', COMPLETED: '#059669', DELAYED: '#dc2626' }
const WBS_HEX: Record<string, string> = { COMPLETED: '#059669', IN_PROGRESS: '#d97706', DELAYED: '#dc2626', NOT_STARTED: '#94a3b8' }

// ============ 5. TIMELINE PROYEK ============
export function TimelineSection({ data, range, no }: SecProps) {
  const events: TimelineEvent[] = []
  data.dailyReports.filter(r => inRange(r.date, range)).forEach(r => {
    events.push({
      date: r.date,
      title: `Laporan Harian — ${empName(data, r.employeeId)}`,
      sub: `${fmtIDN(new Date(r.date))} • ${ROLE_LABEL[r.role] ?? r.role} • ${r.weather || '-'} • ${r.manpowerCount} orang • ${r.workHours} jam`,
      body: [r.activities && `Kegiatan: ${r.activities}`, r.issues && `Kendala: ${r.issues}`, r.planTomorrow && `Rencana besok: ${r.planTomorrow}`].filter(Boolean).join('  •  '),
      tag: 'LAPORAN', color: '#d97706',
    })
  })
  data.tasks.filter(t => t.completedAt && inRange(t.completedAt, range)).forEach(t => {
    events.push({ date: t.completedAt!, title: `Task selesai — ${t.title}`, sub: `${empName(data, t.assigneeId)} • ${fmtIDN(new Date(t.completedAt!))}`, tag: 'SELESAI', color: '#059669' })
  })
  data.weeklyReports.filter(w => inRange(w.weekStart, range)).forEach(w => {
    events.push({ date: w.weekStart, title: `Laporan Mingguan — ${empName(data, w.employeeId)}`, sub: `${fmtIDN(new Date(w.weekStart))} – ${fmtIDN(new Date(w.weekEnd))}`, body: w.progressSummary || w.achievements, tag: 'MINGGUAN', color: '#2563eb' })
  })
  const sorted = [...events].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Timeline & Kronologi Kegiatan" sub={`${events.length} kejadian tercatat${range ? ` — ${range.label}` : ''} (seluruh kejadian ditampilkan)`} accent="#2563eb" />
      <Timeline events={sorted} />
    </div>
  )
}

// ============ 6. GANTT CHART ============
export function GanttSection({ data, no }: SecProps) {
  const fases = data.wbs.filter(t => t.level === 1).length
  const rows = [...data.wbs].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.wbsCode.localeCompare(b.wbsCode))
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Gantt Chart — Jadwal WBS" sub={`${data.wbs.length} aktivitas dalam ${fases} fase • progress aktual vs jadwal`} accent="#dc2626" />
      <GanttChart tasks={data.wbs} />
      <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2">
        {(['NOT_STARTED', 'IN_PROGRESS', 'COMPLETED', 'DELAYED'] as const).map(s => (
          <MiniStat key={s} label={WBS_STATUS[s]} value={data.wbs.filter(t => t.status === s).length} sub="aktivitas" bg={s === 'DELAYED' ? '#fef2f2' : s === 'COMPLETED' ? '#ecfdf5' : '#f8fafc'} color={s === 'DELAYED' ? '#dc2626' : s === 'COMPLETED' ? '#047857' : undefined} />
        ))}
      </div>
      {/* Rincian lengkap SELURUH aktivitas — nama utuh tanpa dipotong */}
      <div className="mt-3">
        <ReportCard title={`Rincian Seluruh Aktivitas WBS (${rows.length} aktivitas)`} accent="#dc2626">
          <Table head={['Kode', 'Aktivitas', 'Disiplin', 'PIC', 'Status', 'Prog.', 'Mulai', 'Selesai']}>
            {rows.map(t => (
              <Tr key={t.id}>
                <Td className="font-mono font-semibold whitespace-nowrap">{t.wbsCode}</Td>
                <Td style={{ paddingLeft: 10 + (t.level - 1) * 10 }}>
                  <span className={t.level === 1 ? 'font-bold text-slate-800' : 'text-slate-600'}>
                    {t.isMilestone && <span className="inline-block w-2 h-2 rotate-45 bg-slate-800 mr-1" style={{ borderRadius: 1 }} />}
                    {t.name}
                  </span>
                  {t.criticalPath && <span className="ml-1.5 text-[8px] font-bold text-red-600 border border-red-400 rounded px-1 align-middle whitespace-nowrap">CP</span>}
                </Td>
                <Td>{DISC_LABEL[t.discipline] ?? t.discipline}</Td>
                <Td>{empName(data, t.assigneeId)}</Td>
                <Td><Chip color={WBS_HEX[t.status] ?? '#64748b'} soft>{WBS_STATUS[t.status] ?? t.status}</Chip></Td>
                <Td className="w-14"><Bar value={t.progress} color={WBS_HEX[t.status] ?? '#d97706'} /></Td>
                <Td className="whitespace-nowrap">{fmtDate(t.startDate)}</Td>
                <Td className="whitespace-nowrap">{fmtDate(t.endDate)}</Td>
              </Tr>
            ))}
          </Table>
        </ReportCard>
      </div>
    </div>
  )
}

// ============ 7. PROGRESS FISIK ============
export function ProgressFisikSection({ data, no }: SecProps) {
  const d = data.dash
  const qty = data.quantities
  const fab = data.fabrications
  const eq = data.equipment
  const avgPct = (f: (x: typeof fab[number]) => number) => fab.length ? Math.round(fab.reduce((s, x) => s + f(x), 0) / fab.length) : 0
  const fabStages = [
    { key: 'cutQty', total: 'totalQty', label: 'Cutting' }, { key: 'fitUpQty', total: 'totalQty', label: 'Fit-Up' },
    { key: 'weldedQty', total: 'totalQty', label: 'Welding' }, { key: 'ndtQty', total: 'totalQty', label: 'NDT' },
    { key: 'paintedQty', total: 'totalQty', label: 'Painting' }, { key: 'deliveredQty', total: 'totalQty', label: 'Terkirim' },
  ].map(s => ({ label: s.label, pct: avgPct(x => (x[s.total as keyof typeof x] as number) > 0 ? (x[s.key as keyof typeof x] as number) / (x[s.total as keyof typeof x] as number) * 100 : 0) }))
  const eqDelayed = eq.filter(e => e.status === 'DELAYED')

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Progress Fisik Pekerjaan" sub="Quantity terpasang, fabrikasi workshop & kedatangan equipment" accent="#ea580c" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
        <MiniStat label="Item Quantity" value={qty.length} sub={`${d?.qtyStats.length ?? 0} disiplin terpantau`} bg="#f8fafc" />
        <MiniStat label="Progress Fabrikasi" value={`${d?.fabProgress ?? 0}%`} sub={`${d?.fabTotal ?? fab.length} item fabrikasi`} bg="#fff7ed" color="#c2410c" />
        <MiniStat label="Equipment Tiba" value={`${d?.eqStats.arrived ?? 0}/${d?.eqStats.total ?? eq.length}`} sub="sudah diterima" bg="#ecfdf5" color="#047857" />
        <MiniStat label="Equipment Terlambat" value={d?.eqStats.delayed ?? eqDelayed.length} bg="#fef2f2" color="#dc2626" />
      </div>
      <ReportCard title="Pipeline Fabrikasi (rata-rata seluruh item)" accent="#ea580c" className="mb-3">
        <div className="grid md:grid-cols-2 gap-x-6 gap-y-2">
          {fabStages.map(s => (
            <div key={s.label} className="flex items-center gap-2">
              <span className="text-[10px] text-slate-600 w-20 shrink-0">{s.label}</span>
              <Bar value={s.pct} color="#ea580c" />
            </div>
          ))}
        </div>
        <div className="flex gap-1.5 flex-wrap mt-2.5">
          {Object.keys(FAB_STATUS).map(k => <Chip key={k} color="#9a3412" soft>{FAB_STATUS[k]}: {fab.filter(f => f.status === k).length}</Chip>)}
        </div>
      </ReportCard>
      <div className="grid md:grid-cols-2 gap-3">
        <ReportCard title="Quantity Terpasang per Item (seluruh item, urut capaian)" accent="#2563eb">
          <div className="space-y-1.5">
            {[...qty].sort((a, b) => (b.installedQty / Math.max(1, b.plannedQty)) - (a.installedQty / Math.max(1, a.plannedQty))).map(q => (
              <div key={q.id} className="flex items-center gap-2" style={{ breakInside: 'avoid' }}>
                <span className="text-[9.5px] text-slate-600 w-32 shrink-0 break-words leading-snug" title={q.name}>{q.name}</span>
                <Bar value={q.installedQty} max={Math.max(1, q.plannedQty)} color="#2563eb" />
              </div>
            ))}
          </div>
        </ReportCard>
        <ReportCard title="Rata-rata Progress per Disiplin (Quantity)" accent="#d97706">
          <HBars data={(d?.qtyStats ?? []).map(q => ({ name: DISC_LABEL[q.discipline] ?? q.discipline, value: q.avgPct }))} />
        </ReportCard>
      </div>
      {eq.length > 0 && (
        <div className="mt-3">
          <Table head={['Equipment', 'Tag No', 'Pemasok', 'Status', 'Tgl Rencana', 'Tgl Aktual']}>
            {[...eq].sort((a, b) => (b.status === 'DELAYED' ? 1 : 0) - (a.status === 'DELAYED' ? 1 : 0)).map(e => (
              <Tr key={e.id}>
                <Td className="font-semibold">{e.equipmentName}</Td>
                <Td>{e.tagNo}</Td>
                <Td>{e.supplier}</Td>
                <Td><Chip color={e.status === 'DELAYED' ? '#dc2626' : e.status === 'ARRIVED' || e.status === 'INSTALLED' ? '#059669' : '#d97706'} soft>{EQ_STATUS[e.status] ?? e.status}</Chip></Td>
                <Td>{fmtDate(e.plannedDate)}</Td>
                <Td>{fmtDate(e.actualDate)}</Td>
              </Tr>
            ))}
          </Table>
        </div>
      )}
    </div>
  )
}

// ============ 8. LAPORAN HARIAN ============
export function LaporanHarianSection({ data, range, no }: SecProps) {
  const rows = data.dailyReports.filter(r => inRange(r.date, range)).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Laporan Harian Lapangan" sub={`${rows.length} laporan${range ? ` — ${range.label}` : ''}`} accent="#0d9488" />
      {rows.length === 0 && <p className="text-[10px] text-slate-400">Tidak ada laporan harian pada periode ini.</p>}
      <div className="grid md:grid-cols-2 gap-3">
        {rows.map(r => (
          <div key={r.id} className="rpt-card rounded-xl border border-slate-200 p-3.5" style={{ breakInside: 'avoid' }}>
            <div className="flex items-center justify-between gap-2 flex-wrap mb-1.5">
              <p className="text-[11px] font-bold text-slate-800">{empName(data, r.employeeId)} <span className="text-slate-400 font-normal">• {ROLE_LABEL[r.role] ?? r.role}</span></p>
              <div className="flex gap-1">
                <Chip color="#0d9488" soft>{fmtIDN(new Date(r.date))}</Chip>
                {r.weather && <Chip color="#0284c7" soft>{r.weather}</Chip>}
                <Chip color="#64748b" soft>{r.manpowerCount} orang • {r.workHours}j</Chip>
              </div>
            </div>
            {[['Kegiatan', r.activities], ['Kendala', r.issues], ['Rencana Besok', r.planTomorrow]].map(([label, v]) => v && (
              <p key={label} className="text-[9.5px] text-slate-600 leading-relaxed mt-1"><b className="text-slate-800">{label}:</b> <Truncated text={v} /></p>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

// ============ 9. LAPORAN MINGGUAN ============
export function LaporanMingguanSection({ data, range, no }: SecProps) {
  const rows = data.weeklyReports.filter(w => inRange(w.weekStart, range) || inRange(w.weekEnd, range)).sort((a, b) => new Date(b.weekStart).getTime() - new Date(a.weekStart).getTime())
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Laporan & Rencana Mingguan" sub={`${rows.length} laporan mingguan${range ? ` — terkait ${range.label}` : ''}`} accent="#2563eb" />
      {rows.length === 0 && <p className="text-[10px] text-slate-400">Tidak ada laporan mingguan pada periode ini.</p>}
      <div className="space-y-3">
        {rows.map(w => (
          <div key={w.id} className="rpt-card rounded-xl border border-slate-200 p-3.5" style={{ breakInside: 'avoid' }}>
            <div className="flex items-center justify-between gap-2 flex-wrap mb-1.5">
              <p className="text-[11px] font-bold text-slate-800">{empName(data, w.employeeId)} <span className="text-slate-400 font-normal">• {ROLE_LABEL[w.role] ?? w.role} • {w.type}</span></p>
              <Chip color="#2563eb" soft>{fmtIDN(new Date(w.weekStart))} – {fmtIDN(new Date(w.weekEnd))}</Chip>
            </div>
            {[['Ringkasan Progres', w.progressSummary], ['Capaian', w.achievements], ['Kendala', w.issues], ['Rencana Minggu Depan', w.nextWeekPlan]].map(([label, v]) => v && (
              <p key={label} className="text-[9.5px] text-slate-600 leading-relaxed mt-1"><b className="text-slate-800">{label}:</b> <Truncated text={v} /></p>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

// ============ 10. KPI KARYAWAN ============
export function KpiSection({ data, range, no }: SecProps) {
  const inRangeKpi = data.kpi.filter(k => inRange(k.periodStart, range))
  const records = inRangeKpi.length ? inRangeKpi : data.kpi.filter(k => k.period === 'MONTHLY')
  const note = inRangeKpi.length ? `KPI periode ${range?.label ?? ''}` : 'Snapshot KPI bulanan terakhir (periode terpilih belum berdata)'
  const monthly = records.filter(k => k.period === 'MONTHLY')
  const rows = monthly.length ? monthly : records
  const top = [...rows].sort((a, b) => b.overallScore - a.overallScore)
  const d = data.dash

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="KPI & Peringkat Karyawan" sub={note} accent="#7c3aed" />
      <div className="grid md:grid-cols-2 gap-3 mb-3">
        <ReportCard title="Top 10 Performer (Overall)" accent="#059669">
          <HBars data={top.slice(0, 10).map(k => ({ name: empName(data, k.employeeId), value: k.overallScore }))} color="#059669" />
        </ReportCard>
        <ReportCard title="Perlu Perhatian (5 Terbawah)" accent="#dc2626">
          {(() => {
            const lows: { id: string; name: string; role: string; score: number }[] = d?.lowPerformers?.length
              ? d.lowPerformers
              : [...top].reverse().slice(0, 5).map(k => ({ id: k.employeeId, name: empName(data, k.employeeId), role: data.employees.find(x => x.id === k.employeeId)?.role ?? '', score: k.overallScore }))
            if (!lows.length) return <p className="text-[10px] text-slate-400">Data belum tersedia.</p>
            return (
              <div className="space-y-1.5">
                {lows.map(p => (
                  <div key={p.id} className="flex items-center justify-between border-b border-slate-100 py-1">
                    <span className="text-[10px] text-slate-700">{p.name} <span className="text-slate-400">• {ROLE_LABEL[p.role] ?? p.role}</span></span>
                    <span className={`text-[11px] font-bold ${scoreColor(p.score)}`}>{p.score}</span>
                  </div>
                ))}
              </div>
            )
          })()}
        </ReportCard>
      </div>
      {rows.length > 0 && (
        <Table head={['Karyawan', 'Peran', 'Kehadiran', 'Task', 'Disiplin', 'Kualitas', 'Safety', 'Overall']}>
          {top.map(k => {
            const e = data.employees.find(x => x.id === k.employeeId)
            return (
              <Tr key={k.id}>
                <Td className="font-semibold">{e?.name ?? '—'}</Td>
                <Td>{e ? (ROLE_LABEL[e.role] ?? e.role) : '—'}</Td>
                <Td className={scoreColor(k.attendanceScore)} style={{ fontWeight: 700 }}>{k.attendanceScore}</Td>
                <Td className={scoreColor(k.taskScore)} style={{ fontWeight: 700 }}>{k.taskScore}</Td>
                <Td className={scoreColor(k.disciplineScore)} style={{ fontWeight: 700 }}>{k.disciplineScore}</Td>
                <Td className={scoreColor(k.qualityScore)} style={{ fontWeight: 700 }}>{k.qualityScore}</Td>
                <Td className={scoreColor(k.safetyScore)} style={{ fontWeight: 700 }}>{k.safetyScore}</Td>
                <Td><Chip color={k.overallScore >= 80 ? '#059669' : k.overallScore >= 60 ? '#d97706' : '#dc2626'}>{k.overallScore}</Chip></Td>
              </Tr>
            )
          })}
        </Table>
      )}
    </div>
  )
}

// ============ 11. DOKUMEN ============
export function DokumenSection({ data, no }: SecProps) {
  const rows = data.documents
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Dokumen Proyek (SOW/JSA/ITP)" sub={`${rows.length} dokumen terkelola`} accent="#0284c7" />
      <div className="flex gap-1.5 flex-wrap mb-2.5">
        {['APPROVED', 'SUBMITTED', 'DRAFT', 'IN_REVIEW', 'REJECTED'].map(s => {
          const n = rows.filter(r => r.status === s).length
          return n ? <Chip key={s} color={s === 'APPROVED' ? '#059669' : s === 'REJECTED' ? '#dc2626' : '#d97706'} soft>{statusBadge(s).length ? s : s}: {n}</Chip> : null
        })}
      </div>
      <Table head={['No. Dokumen', 'Judul', 'Tipe', 'Fase', 'Versi', 'Status', 'Disetujui Oleh']}>
        {rows.map(doc => (
          <Tr key={doc.id}>
            <Td className="font-mono">{doc.docNo}</Td>
            <Td className="font-semibold max-w-[200px]"><Truncated text={doc.title} /></Td>
            <Td>{DOC_TYPES[doc.type] ?? doc.type}</Td>
            <Td>{DOC_PHASE[doc.phase] ?? doc.phase}</Td>
            <Td>{doc.version}</Td>
            <Td><Chip color={doc.status === 'APPROVED' ? '#059669' : doc.status === 'REJECTED' ? '#dc2626' : '#d97706'} soft>{doc.status}</Chip></Td>
            <Td>{doc.approvedBy || '—'}</Td>
          </Tr>
        ))}
      </Table>
    </div>
  )
}

// ============ 12. GAMBAR & ZONA ============
export function GambarZonaSection({ data, no }: SecProps) {
  const drawings = data.drawings
  const zones = data.zones
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Gambar Proyek & Zona Pekerjaan" sub={`${drawings.length} gambar (CAD/PDF/PNG) • ${zones.length} zona pekerjaan terkelola`} accent="#7c3aed" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
        <MiniStat label="Total Gambar" value={drawings.length} bg="#f8fafc" />
        <MiniStat label="Total Zona" value={zones.length} bg="#f8fafc" />
        <MiniStat label="Zona Berjalan" value={zones.filter(z => z.status === 'ON_PROGRESS').length} bg="#fffbeb" color="#b45309" />
        <MiniStat label="Zona Selesai" value={zones.filter(z => z.status === 'COMPLETED').length} bg="#ecfdf5" color="#047857" />
      </div>
      {zones.length > 0 && (
        <ReportCard title="Status Zona Pekerjaan" accent="#7c3aed" className="mb-3">
          <div className="grid md:grid-cols-3 gap-x-5 gap-y-1.5">
            {zones.map(z => (
              <div key={z.id} className="flex items-center justify-between gap-2 border-b border-slate-100 py-1">
                <span className="text-[10px] text-slate-700 break-words leading-snug"><b className="font-mono text-slate-500">{z.code}</b> {z.name}</span>
                <Chip color={ZONE_HEX[z.status] ?? '#64748b'} soft>{ZONE_STATUS[z.status] ?? z.status}</Chip>
              </div>
            ))}
          </div>
        </ReportCard>
      )}
      {drawings.length > 0 && (
        <Table head={['Judul Gambar', 'No. Gambar', 'Disiplin', 'Format', 'Ukuran', 'Diunggah']}>
          {drawings.map(dr => (
            <Tr key={dr.id}>
              <Td className="font-semibold"><Truncated text={dr.title} /></Td>
              <Td className="font-mono">{dr.drawingNo || '—'}</Td>
              <Td>{DISC_LABEL[dr.discipline] ?? dr.discipline}</Td>
              <Td>{dr.fileType}</Td>
              <Td>{dr.sizeKb} KB</Td>
              <Td>{fmtDate(dr.createdAt)}</Td>
            </Tr>
          ))}
        </Table>
      )}
    </div>
  )
}

// ============ 13. AI SUMMARY ============
export function AiSummarySection({ data, no }: SecProps) {
  const rows = [...data.summaries].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="AI Summary & Insight Proyek" sub={`${rows.length} ringkasan AI tersimpan (seluruhnya ditampilkan)`} accent="#a21caf" />
      {rows.length === 0 && <p className="text-[10px] text-slate-400">Belum ada ringkasan AI. Generate melalui menu Laporan & AI Summary.</p>}
      <div className="space-y-3">
        {rows.map(s => (
          <div key={s.id} className="rpt-card rounded-xl border border-slate-200 p-3.5" style={{ breakInside: 'avoid' }}>
            <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
              <p className="text-[11px] font-bold text-slate-800">{s.title || `Ringkasan ${s.scope}`}</p>
              <div className="flex gap-1">
                <Chip color="#a21caf" soft>{s.scope}</Chip>
                <Chip color="#64748b" soft>{fmtDate(s.createdAt)}</Chip>
              </div>
            </div>
            <p className="text-[9.5px] text-slate-600 leading-relaxed whitespace-pre-wrap"><Truncated text={s.content} /></p>
          </div>
        ))}
      </div>
    </div>
  )
}
