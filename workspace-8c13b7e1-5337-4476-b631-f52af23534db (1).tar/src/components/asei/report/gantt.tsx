'use client'
// Gantt chart print-friendly (CSS murni) + Timeline kronologi vertikal
import type { WbsTask } from '@/lib/types'
import { WBS_STATUS } from '@/lib/client'
import { fmtIDN } from '@/lib/report'

const STATUS_COLOR: Record<string, string> = {
  COMPLETED: '#059669', IN_PROGRESS: '#d97706', DELAYED: '#dc2626', NOT_STARTED: '#94a3b8',
}

export function GanttChart({ tasks }: { tasks: WbsTask[] }) {
  const rows = [...tasks].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.wbsCode.localeCompare(b.wbsCode))
  if (!rows.length) return <p className="text-[10px] text-slate-400">Tidak ada data WBS.</p>

  const starts = rows.map(t => new Date(t.startDate).getTime()).filter(n => !Number.isNaN(n))
  const ends = rows.map(t => new Date(t.endDate).getTime()).filter(n => !Number.isNaN(n))
  const min = starts.length ? Math.min(...starts) : Date.now()
  const max = ends.length ? Math.max(...ends) : Date.now() + 86400000
  const span = Math.max(1, max - min)
  const today = Date.now()
  const todayPct = Math.min(100, Math.max(0, ((today - min) / span) * 100))

  // Tick bulan di header
  const ticks: { pct: number; label: string }[] = []
  const cur = new Date(min); cur.setDate(1); cur.setHours(0, 0, 0, 0)
  while (cur.getTime() <= max) {
    const pct = ((cur.getTime() - min) / span) * 100
    if (pct >= -2 && pct <= 100) ticks.push({ pct: Math.max(0, pct), label: cur.toLocaleDateString('id-ID', { month: 'short', year: '2-digit' }) })
    cur.setMonth(cur.getMonth() + 1)
  }

  return (
    <div className="rpt-gantt">
      {/* Legend */}
      <div className="flex flex-wrap gap-3 mb-2 px-1">
        {Object.entries(WBS_STATUS).map(([k, v]) => (
          <span key={k} className="inline-flex items-center gap-1.5 text-[9px] text-slate-600">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ background: STATUS_COLOR[k] ?? '#94a3b8' }} /> {v}
          </span>
        ))}
        <span className="inline-flex items-center gap-1.5 text-[9px] text-slate-600">
          <span className="w-2.5 h-2.5 rotate-45 bg-slate-800" style={{ borderRadius: 2 }} /> Milestone
        </span>
        <span className="inline-flex items-center gap-1.5 text-[9px] text-slate-600">
          <span className="w-2.5 h-2.5 rounded-sm border-2 border-red-500 bg-white" /> Critical Path
        </span>
      </div>

      <div className="rounded-lg border border-slate-200 overflow-hidden">
        {/* Header bulan */}
        <div className="flex bg-slate-100 border-b border-slate-200">
          <div className="shrink-0 w-[300px] px-2.5 py-1.5 text-[9px] font-bold uppercase tracking-wide text-slate-500 border-r border-slate-200">Aktivitas WBS</div>
          <div className="relative flex-1 h-6">
            {ticks.map((t, i) => (
              <div key={i} className="absolute top-0 h-full border-l border-slate-200 pl-1 text-[8px] text-slate-500 leading-6 whitespace-nowrap" style={{ left: `${t.pct}%` }}>{t.label}</div>
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="relative">
          {today >= min && today <= max && (
            <div className="absolute top-0 bottom-0 z-10" style={{ left: `calc(300px + (100% - 300px) * ${todayPct / 100})` }}>
              <div className="relative h-full w-px bg-red-500/70">
                <span className="absolute -top-0.5 -left-4 text-[8px] font-bold text-red-600 bg-red-50 rounded px-0.5 whitespace-nowrap">Hari ini</span>
              </div>
            </div>
          )}
          {rows.map((t, idx) => {
            const st = new Date(t.startDate).getTime()
            const en = new Date(t.endDate).getTime()
            const ok = !Number.isNaN(st) && !Number.isNaN(en)
            const left = ok ? ((st - min) / span) * 100 : 0
            const width = ok ? Math.max(0.6, ((en - st) / span) * 100) : 0
            const color = STATUS_COLOR[t.status] ?? '#94a3b8'
            return (
              <div key={t.id} className={`flex items-stretch border-b border-slate-100 last:border-0 ${idx % 2 ? 'bg-slate-50/60' : 'bg-white'}`} style={{ breakInside: 'avoid' }}>
                <div className="shrink-0 w-[300px] px-2.5 py-1 border-r border-slate-200" style={{ paddingLeft: 10 + (t.level - 1) * 12 }}>
                  {/* Nama aktivitas ditampilkan UTUH — wrap beberapa baris bila panjang */}
                  <p className={`text-[9.5px] leading-snug whitespace-normal break-words ${t.level === 1 ? 'font-bold text-slate-800' : 'text-slate-600'}`} title={`${t.wbsCode} — ${t.name}`}>
                    {t.isMilestone && <span className="inline-block w-2 h-2 rotate-45 bg-slate-800 mr-1.5" style={{ borderRadius: 1 }} />}
                    {t.wbsCode} {t.name}
                  </p>
                </div>
                <div className="relative flex-1 min-h-[22px]">
                  {ok && (
                    t.isMilestone ? (
                      <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rotate-45 shadow-sm" style={{ left: `calc(${left}% )`, background: color, transform: `translate(-50%,-50%) rotate(45deg)` }} />
                    ) : (
                      <div
                        className="absolute top-1/2 -translate-y-1/2 h-[12px] rounded-[3px] shadow-sm"
                        style={{ left: `${left}%`, width: `${width}%`, background: color + '2e', border: `1px solid ${color}`, minWidth: 6 }}
                        title={`${fmtIDN(new Date(t.startDate))} → ${fmtIDN(new Date(t.endDate))} • progress ${t.progress}%`}
                      >
                        <div className="h-full rounded-l-[2px]" style={{ width: `${t.progress}%`, background: color, borderRadius: t.progress >= 100 ? 2 : '2px 0 0 2px' }} />
                        {t.criticalPath && <div className="absolute inset-0 rounded-[2px] border-[1.5px] border-red-500 pointer-events-none" />}
                      </div>
                    )
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>
      <p className="text-[8.5px] text-slate-400 mt-1.5 px-1">Isi bar = progress aktual • garis tepi merah = critical path • garis vertikal merah = tanggal cetak laporan</p>
    </div>
  )
}

// ============ Timeline ============
export interface TimelineEvent {
  date: string | Date
  title: string
  sub?: string
  body?: string
  tag?: string
  color?: string
}

export function Timeline({ events }: { events: TimelineEvent[] }) {
  if (!events.length) return <p className="text-[10px] text-slate-400">Tidak ada kegiatan pada periode ini.</p>
  return (
    <div className="relative pl-5">
      <div className="absolute left-[7px] top-1.5 bottom-1.5 w-px bg-gradient-to-b from-amber-400 via-slate-300 to-slate-200" />
      <div className="space-y-3">
        {events.map((e, i) => (
          <div key={i} className="relative" style={{ breakInside: 'avoid' }}>
            <span className="absolute -left-5 top-1 w-3.5 h-3.5 rounded-full border-2 bg-white shadow-sm" style={{ borderColor: e.color ?? '#d97706' }} />
            <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-sm">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-[10.5px] font-bold text-slate-800">{e.title}</p>
                {e.tag && <span className="rounded-full px-1.5 py-px text-[8px] font-bold text-white" style={{ background: e.color ?? '#d97706' }}>{e.tag}</span>}
                {e.sub && <span className="text-[9px] text-slate-400">{e.sub}</span>}
              </div>
              {e.body && <p className="text-[9.5px] text-slate-600 leading-relaxed mt-1">{e.body}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
