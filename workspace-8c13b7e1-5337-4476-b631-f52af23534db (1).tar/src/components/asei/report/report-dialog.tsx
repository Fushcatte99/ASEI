'use client'
// Dialog pembuat General Report — checklist seksi + pilihan periode harian/mingguan/bulanan/lengkap
import { useMemo, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { FileText, Printer, Loader2, SquareCheckBig, Square } from 'lucide-react'
import { REPORT_GROUPS, REPORT_SECTIONS, DEFAULT_SECTIONS, PERIOD_LABEL, type ReportPeriod } from '@/lib/report'
import { dateInput } from '@/lib/client'

export function ReportDialog({ open, onOpenChange, projectId, projectName }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  projectId: string
  projectName: string
}) {
  const [period, setPeriod] = useState<ReportPeriod>('full')
  const [anchorDate, setAnchorDate] = useState(dateInput(new Date()))
  const [selected, setSelected] = useState<string[]>(DEFAULT_SECTIONS)
  const [title, setTitle] = useState('')
  const [busy, setBusy] = useState(false)

  const grouped = useMemo(() => REPORT_GROUPS.map(g => ({ group: g, items: REPORT_SECTIONS.filter(s => s.group === g) })), [])
  const allOn = selected.length === DEFAULT_SECTIONS.length

  const toggle = (k: string) => setSelected(s => s.includes(k) ? s.filter(x => x !== k) : [...s, k])
  const toggleAll = () => setSelected(allOn ? [] : DEFAULT_SECTIONS)

  const build = () => {
    const params = new URLSearchParams()
    params.set('projectId', projectId)
    params.set('period', period)
    if (period !== 'full' && anchorDate) params.set('date', anchorDate)
    if (selected.length && selected.length < DEFAULT_SECTIONS.length) params.set('secs', selected.join(','))
    const t = title.trim() || ''
    if (t) params.set('title', t)
    params.set('print', '1')
    return `/report/general?${params.toString()}`
  }

  const openReport = () => {
    if (!selected.length) return
    setBusy(true)
    window.open(build(), '_blank')
    setTimeout(() => setBusy(false), 600)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[88vh] overflow-y-auto" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4 text-amber-600" /> Buat General Report (PDF)
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Jenis laporan */}
          <div className="grid sm:grid-cols-[220px_1fr] gap-3 items-end">
            <div>
              <Label className="text-xs font-medium text-slate-500 mb-1 block">Jenis / Periode Laporan</Label>
              <Select value={period} onValueChange={v => setPeriod(v as ReportPeriod)}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Harian (Daily Report)</SelectItem>
                  <SelectItem value="weekly">Mingguan (Weekly Report)</SelectItem>
                  <SelectItem value="monthly">Bulanan (Monthly Report)</SelectItem>
                  <SelectItem value="full">Lengkap — Semua Periode</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {period !== 'full' && (
              <div>
                <Label className="text-xs font-medium text-slate-500 mb-1 block">
                  {period === 'monthly' ? 'Tanggal acuan bulan' : period === 'weekly' ? 'Tanggal acuan minggu' : 'Tanggal laporan'}
                </Label>
                <Input type="date" value={anchorDate} onChange={e => setAnchorDate(e.target.value)} className="text-sm" />
              </div>
            )}
          </div>
          <div>
            <Label className="text-xs font-medium text-slate-500 mb-1 block">Judul Kustom (opsional)</Label>
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder={PERIOD_LABEL[period]} className="text-sm" />
          </div>

          {/* Checklist seksi */}
          <div className="rounded-xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between bg-slate-50 px-3 py-2 border-b border-slate-200">
              <p className="text-[11px] font-bold uppercase tracking-wide text-slate-600">Pilih Seksi yang Dilampirkan ({selected.length}/{DEFAULT_SECTIONS.length})</p>
              <Button variant="ghost" size="sm" onClick={toggleAll} className="h-7 gap-1.5 text-[11px] px-2">
                {allOn ? <><Square className="h-3.5 w-3.5" /> Kosongkan</> : <><SquareCheckBig className="h-3.5 w-3.5" /> Pilih Semua</>}
              </Button>
            </div>
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
              {grouped.map(({ group, items }) => (
                <div key={group}>
                  <p className="px-3 pt-2 pb-1 text-[9px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50/50">{group}</p>
                  {items.map(s => {
                    const on = selected.includes(s.key)
                    return (
                      <label key={s.key} className={`flex items-start gap-2.5 px-3 py-2 cursor-pointer hover:bg-slate-50 ${on ? '' : 'opacity-60'}`}>
                        <Checkbox checked={on} onCheckedChange={() => toggle(s.key)} className="mt-0.5" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-800 leading-tight">{s.label}</p>
                          <p className="text-[10px] text-slate-400 leading-snug">{s.desc}</p>
                        </div>
                      </label>
                    )
                  })}
                </div>
              ))}
            </div>
          </div>
          <p className="text-[10px] text-slate-400 leading-relaxed">
            Laporan berbentuk PDF siap-cetak berisi grafik, Gantt chart, timeline & tabel sesuai pilihan di atas.
            Data absensi, laporan harian/mingguan & KPI mengikuti periode terpilih; progress & Gantt = kondisi terkini.
          </p>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={openReport} disabled={!selected.length || busy || !projectId} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Printer className="h-4 w-4" />} Buat & Cetak PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
