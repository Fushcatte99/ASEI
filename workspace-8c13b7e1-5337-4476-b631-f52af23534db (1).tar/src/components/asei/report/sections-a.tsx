'use client'
// Seksi laporan A: Ringkasan Dashboard, Absensi, Tenaga Kerja, Work Task
import { ROLE_LABEL, DISC_LABEL, ATT_STATUS, TASK_STATUS, PRIORITY, statusBadge, fmtDate, fmtTime, scoreColor } from '@/lib/client'
import { inRange, fmtIDN } from '@/lib/report'
import { SectionHeader, ReportCard, MiniStat, Chip, Table, Tr, Td, Bar, Truncated, empName } from './shared'
import type { SecProps } from './shared'
import { TrendArea, StatusPie, GroupedBars } from './charts'

const STATUS_HEX: Record<string, string> = {
  PRESENT: '#059669', LATE: '#d97706', LEAVE: '#0284c7', SICK: '#ea580c', ABSENT: '#dc2626',
}
const TASK_HEX: Record<string, string> = {
  COMPLETED: '#059669', IN_PROGRESS: '#d97706', PENDING: '#94a3b8', DELAYED: '#dc2626', CANCELLED: '#cbd5e1',
}

// ============ 1. RINGKASAN DASHBOARD ============
export function RingkasanSection({ data, range, no }: SecProps) {
  const d = data.dash
  const attInRange = data.attendance.filter(a => inRange(a.date, range))
  const repInRange = data.dailyReports.filter(r => inRange(r.date, range))
  const doneInRange = data.tasks.filter(t => t.completedAt && inRange(t.completedAt, range))
  const progress = d?.progress

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Ringkasan Dashboard & Kinerja" sub={range ? `${range.label} — angka kehadiran/laporan mengikuti periode, progress = kondisi terkini` : 'Snapshot kondisi terkini seluruh proyek'} />
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-3">
        <MiniStat label="Total Tenaga Kerja" value={d?.headcount.total ?? data.employees.length} sub="orang aktif" bg="#fffbeb" color="#b45309" />
        <MiniStat label="Kehadiran" value={`${d?.attendance.presentToday ?? 0}/${d?.headcount.total ?? '-'}`} sub={`Hari ini • telat ${d?.attendance.lateToday ?? 0}`} bg="#ecfdf5" color="#047857" />
        <MiniStat label="Progress Fisik" value={`${progress?.actualProgress ?? 0}%`} sub={`Rencana ${progress?.plannedProgress ?? 0}%`} bg="#eff6ff" color="#1d4ed8" />
        <MiniStat label="Deviasi" value={`${(progress?.deviation ?? 0) > 0 ? '+' : ''}${progress?.deviation ?? 0}%`} sub="aktual vs rencana" bg={(progress?.deviation ?? 0) < 0 ? '#fef2f2' : '#ecfdf5'} color={(progress?.deviation ?? 0) < 0 ? '#dc2626' : '#047857'} />
        <MiniStat label="Work Task" value={`${d?.taskStats.completed ?? 0}/${d?.taskStats.total ?? 0}`} sub={`selesai • terlambat ${d?.taskStats.delayed ?? 0}`} bg="#fefce8" color="#a16207" />
        <MiniStat label="Zero Accident" value={`${d?.zeroAccidentDays ?? 0}`} sub="hari tanpa kecelakaan" bg="#f0fdfa" color="#0f766e" />
      </div>

      {range && (
        <div className="flex flex-wrap gap-2 mb-3">
          <Chip color="#b45309" soft>Periode: {range.label}</Chip>
          <Chip color="#047857" soft>Absensi tercatat: {attInRange.length}</Chip>
          <Chip color="#1d4ed8" soft>Laporan harian: {repInRange.length}</Chip>
          <Chip color="#059669" soft>Task selesai periode ini: {doneInRange.length}</Chip>
        </div>
      )}

      <ReportCard title="Tren Kehadiran, Skor APD & Mood (14 hari terakhir)" accent="#059669" className="mb-3">
        <TrendArea data={(d?.trend ?? []).map(t => ({ ...t, date: fmtIDN(new Date(t.date)).slice(0, 6) }))} />
      </ReportCard>

      <div className="grid md:grid-cols-2 gap-3">
        <ReportCard title="Progress per Disiplin (Aktual vs Rencana)" accent="#2563eb">
          <GroupedBars
            data={(progress?.discProgress ?? []).map(p => ({ name: DISC_LABEL[p.discipline] ?? p.discipline, aktual: p.actual, rencana: p.planned }))}
            series={[{ key: 'aktual', name: 'Aktual (%)', color: '#2563eb' }, { key: 'rencana', name: 'Rencana (%)', color: '#cbd5e1' }]}
          />
        </ReportCard>
        <ReportCard title="Distribusi Status Work Task" accent="#d97706">
          <StatusPie
            colors={[TASK_HEX.COMPLETED, TASK_HEX.IN_PROGRESS, TASK_HEX.PENDING, TASK_HEX.DELAYED]}
            data={[
              { name: 'Selesai', value: d?.taskStats.completed ?? 0 },
              { name: 'Berjalan', value: d?.taskStats.inProgress ?? 0 },
              { name: 'Menunggu', value: d?.taskStats.pending ?? 0 },
              { name: 'Terlambat', value: d?.taskStats.delayed ?? 0 },
            ]}
          />
        </ReportCard>
      </div>
    </div>
  )
}

// ============ 2. ABSENSI & KEHADIRAN ============
export function AbsensiSection({ data, range, no }: SecProps) {
  const rows = data.attendance.filter(a => inRange(a.date, range)).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  const cnt = (s: string) => rows.filter(a => a.status === s).length
  const withPpe = rows.filter(a => a.ppeScore > 0)
  const avg = (f: (a: typeof rows[number]) => number) => withPpe.length ? Math.round(withPpe.reduce((s, a) => s + f(a), 0) / withPpe.length) : 0
  // SELURUH catatan ditampilkan (tanpa batas)

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Absensi & Kehadiran" sub={range ? `${rows.length} catatan absensi — ${range.label}` : `${rows.length} catatan absensi — seluruh periode`} />
      <div className="grid grid-cols-3 md:grid-cols-7 gap-2 mb-3">
        <MiniStat label="Hadir" value={cnt('PRESENT')} bg="#ecfdf5" color="#047857" />
        <MiniStat label="Terlambat" value={cnt('LATE')} bg="#fffbeb" color="#b45309" />
        <MiniStat label="Izin" value={cnt('LEAVE')} bg="#f0f9ff" color="#0369a1" />
        <MiniStat label="Sakit" value={cnt('SICK')} bg="#fff7ed" color="#c2410c" />
        <MiniStat label="Absen" value={cnt('ABSENT')} bg="#fef2f2" color="#dc2626" />
        <MiniStat label="Rata APD (AI)" value={avg(a => a.ppeScore)} sub="skor 0-100" bg="#fefce8" color="#a16207" />
        <MiniStat label="Rata Mood (AI)" value={avg(a => a.moodScore)} sub="indeks bahagia" bg="#fdf4ff" color="#a21caf" />
      </div>
      <div className="grid md:grid-cols-2 gap-3 mb-3">
        <ReportCard title="Distribusi Status Kehadiran" accent="#059669">
          <StatusPie colors={['#059669', '#d97706', '#0284c7', '#ea580c', '#dc2626']}
            data={[{ name: 'Hadir', value: cnt('PRESENT') }, { name: 'Terlambat', value: cnt('LATE') }, { name: 'Izin', value: cnt('LEAVE') }, { name: 'Sakit', value: cnt('SICK') }, { name: 'Absen', value: cnt('ABSENT') }]} />
        </ReportCard>
        <ReportCard title="Catatan" accent="#64748b">
          <p className="text-[10px] text-slate-600 leading-relaxed">
            Skor APD dan Mood dianalisis otomatis oleh AI dari foto check-in di lokasi (helm, rompi, sarung tangan, sepatu, goggles) serta ekspresi wajah pekerja.
            Nilai APD rata-rata <b className={scoreColor(avg(a => a.ppeScore))}>{avg(a => a.ppeScore)}/100</b> dan indeks mood <b>{avg(a => a.moodScore)}/100</b>
            {rows.length > 0 && <> dari {withPpe.length} absensi berfoto</>}. Keterlambatan tercatat otomatis dari waktu check-in dibanding jadwal shift proyek.
          </p>
          <div className="flex gap-1.5 mt-2 flex-wrap">
            {Object.entries(ATT_STATUS).map(([k, v]) => <Chip key={k} color={STATUS_HEX[k] ?? '#64748b'} soft>{v}: {cnt(k)}</Chip>)}
          </div>
        </ReportCard>
      </div>
      {rows.length > 0 && (
        <Table head={['Tanggal', 'Karyawan', 'Status', 'Masuk', 'Keluar', 'Jam Kerja', 'APD', 'Mood']}>
          {rows.map(a => (
            <Tr key={a.id}>
              <Td>{fmtDate(a.date)}</Td>
              <Td className="font-semibold">{empName(data, a.employeeId)}</Td>
              <Td><Chip color={STATUS_HEX[a.status] ?? '#64748b'} soft>{ATT_STATUS[a.status] ?? a.status}</Chip>{a.lateMinutes > 0 ? ` +${a.lateMinutes}m` : ''}</Td>
              <Td>{fmtTime(a.checkIn)}</Td>
              <Td>{a.checkOut ? fmtTime(a.checkOut) : '—'}</Td>
              <Td>{a.workHours ? `${a.workHours}j` : '—'}</Td>
              <Td className={scoreColor(a.ppeScore)} style={{ fontWeight: 700 }}>{a.ppeScore || '—'}</Td>
              <Td className={scoreColor(a.moodScore)} style={{ fontWeight: 700 }}>{a.moodScore || '—'}</Td>
            </Tr>
          ))}
        </Table>
      )}
    </div>
  )
}

// ============ 3. TENAGA KERJA ============
export function TenagaKerjaSection({ data, no }: SecProps) {
  const emps = data.employees
  const byRole = Object.entries(ROLE_LABEL).map(([k, v]) => ({ role: v, n: emps.filter(e => e.role === k).length })).filter(r => r.n > 0)
  const byDisc = ['GENERAL', 'CIVIL', 'MECHANICAL', 'ELECTRICAL'].map(k => ({ name: DISC_LABEL[k], value: emps.filter(e => e.discipline === k).length }))
  const inducted = emps.filter(e => e.safetyInduction).length
  const keyPeople = emps.filter(e => ['PM', 'SM', 'HSE', 'ENGINEER'].includes(e.role))
  const d = data.dash

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Komposisi Tenaga Kerja" sub={`${emps.length} personel terdaftar dalam proyek`} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
        <MiniStat label="Total Personel" value={emps.length} bg="#fffbeb" color="#b45309" />
        <MiniStat label="Sudah Induksi K3" value={`${inducted}/${emps.length}`} sub={emps.length ? `${Math.round((inducted / emps.length) * 100)}% terinduksi` : '-'} bg="#ecfdf5" color="#047857" />
        <MiniStat label="Disiplin ME" value={byDisc.find(x => x.name === 'Mechanical')?.value ?? 0} sub="dominasi Mechanical" bg="#fff7ed" color="#c2410c" />
        <MiniStat label="Rata Skor APD 7 hari" value={d?.attendance.avgPpe ?? '-'} bg="#fefce8" color="#a16207" />
      </div>
      <div className="grid md:grid-cols-2 gap-3 mb-3">
        <ReportCard title="Komposisi per Disiplin" accent="#ea580c">
          <StatusPie data={byDisc} colors={['#64748b', '#d97706', '#ea580c', '#059669']} />
        </ReportCard>
        <ReportCard title="Peran dalam Proyek" accent="#2563eb">
          <div className="space-y-1.5">
            {byRole.map(r => (
              <div key={r.role} className="flex items-center gap-2">
                <span className="text-[10px] text-slate-600 w-28 shrink-0">{r.role}</span>
                <Bar value={r.n} max={Math.max(...byRole.map(x => x.n), 1)} color="#2563eb" showPct={false} />
                <span className="text-[10px] font-bold text-slate-700 w-6 text-right">{r.n}</span>
              </div>
            ))}
          </div>
        </ReportCard>
      </div>
      <ReportCard title="Personel Kunci" accent="#d97706">
        <div className="grid md:grid-cols-2 gap-x-6 gap-y-1">
          {keyPeople.map(e => (
            <div key={e.id} className="flex items-center justify-between border-b border-slate-100 py-1">
              <span className="text-[10px] font-semibold text-slate-700">{e.name} <span className="text-slate-400 font-normal">• {e.nip}</span></span>
              <Chip color="#d97706" soft>{ROLE_LABEL[e.role] ?? e.role}{e.subDiscipline ? ` — ${e.subDiscipline}` : ''}</Chip>
            </div>
          ))}
        </div>
      </ReportCard>
    </div>
  )
}

// ============ 4. WORK TASK ============
export function WorkTaskSection({ data, range, no }: SecProps) {
  const d = data.dash
  const rows = [...data.tasks]
    .sort((a, b) => {
      const po = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 }
      return (po[a.priority] ?? 4) - (po[b.priority] ?? 4) || new Date(a.dueDate ?? 0).getTime() - new Date(b.dueDate ?? 0).getTime()
    })
  const prioHex: Record<string, string> = { LOW: '#64748b', MEDIUM: '#0284c7', HIGH: '#d97706', CRITICAL: '#dc2626' }
  const doneInRange = data.tasks.filter(t => t.completedAt && inRange(t.completedAt, range))

  return (
    <div className="rpt-section">
      <SectionHeader no={no} title="Work Task & Penugasan" sub={range && doneInRange.length ? `${doneInRange.length} task diselesaikan pada periode ini — status lain = kondisi terkini` : 'Seluruh task proyek — kondisi terkini'} />
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-3">
        <MiniStat label="Total Task" value={d?.taskStats.total ?? data.tasks.length} bg="#f8fafc" />
        <MiniStat label="Selesai" value={d?.taskStats.completed ?? 0} bg="#ecfdf5" color="#047857" />
        <MiniStat label="Berjalan" value={d?.taskStats.inProgress ?? 0} bg="#fffbeb" color="#b45309" />
        <MiniStat label="Menunggu" value={d?.taskStats.pending ?? 0} bg="#f8fafc" color="#475569" />
        <MiniStat label="Terlambat" value={d?.taskStats.delayed ?? 0} bg="#fef2f2" color="#dc2626" />
        <MiniStat label="Overdue" value={d?.taskStats.overdue ?? 0} sub="lewats deadline" bg="#fef2f2" color="#dc2626" />
      </div>
      <Table head={['Task', 'Penanggung Jawab', 'Disiplin', 'Prioritas', 'Status', 'Progress', 'Deadline']}>
        {rows.map(t => (
          <Tr key={t.id}>
            <Td className="font-semibold max-w-[220px]"><Truncated text={t.title} max={60} /></Td>
            <Td>{empName(data, t.assigneeId)}</Td>
            <Td>{DISC_LABEL[t.discipline] ?? t.discipline}</Td>
            <Td><Chip color={prioHex[t.priority] ?? '#64748b'} soft>{PRIORITY[t.priority] ?? t.priority}</Chip></Td>
            <Td><Chip color={TASK_HEX[t.status] ?? '#64748b'} soft>{TASK_STATUS[t.status] ?? t.status}</Chip></Td>
            <Td className="w-24"><Bar value={t.progress} color={TASK_HEX[t.status] === '#059669' ? '#059669' : '#d97706'} /></Td>
            <Td>{fmtDate(t.dueDate)}</Td>
          </Tr>
        ))}
      </Table>
    </div>
  )
}
