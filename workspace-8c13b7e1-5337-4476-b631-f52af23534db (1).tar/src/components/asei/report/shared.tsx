'use client'
// Komponen dasar laporan — dioptimalkan untuk cetak (warna tetap, break-aware)
import type { ReactNode } from 'react'
import type {
  Project, Employee, Attendance, WorkTask, WbsTask, QuantityItem, FabricationItem,
  EquipmentDelivery, DailyReport, WeeklyReport, ProjectDocument, KpiRecord, AiSummary,
  DrawingZone, DrawingFileMeta, DashboardData, SessionInfo,
} from '@/lib/types'
import type { PeriodRange } from '@/lib/report'

export interface ReportData {
  project: Project | null
  dash: DashboardData | null
  employees: Employee[]
  attendance: Attendance[]
  tasks: WorkTask[]
  wbs: WbsTask[]
  quantities: QuantityItem[]
  fabrications: FabricationItem[]
  equipment: EquipmentDelivery[]
  dailyReports: DailyReport[]
  weeklyReports: WeeklyReport[]
  documents: ProjectDocument[]
  kpi: KpiRecord[]
  summaries: AiSummary[]
  zones: DrawingZone[]
  drawings: DrawingFileMeta[]
  user: SessionInfo | null
}

export interface SecProps { data: ReportData; range: PeriodRange | null; no: number }

export function empName(data: ReportData, id: string | null | undefined): string {
  if (!id) return '—'
  return data.employees.find(e => e.id === id)?.name ?? '—'
}

export function SectionHeader({ no, title, sub, accent = '#d97706' }: { no: number; title: string; sub?: string; accent?: string }) {
  return (
    <div className="rpt-section-title flex items-start gap-3 mb-3 break-inside-avoid" style={{ breakAfter: 'avoid' }}>
      <div className="shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold shadow-sm" style={{ background: accent }}>{no}</div>
      <div className="min-w-0">
        <h2 className="text-[15px] font-bold text-slate-900 leading-tight">{title}</h2>
        {sub && <p className="text-[10px] text-slate-500 leading-snug mt-0.5">{sub}</p>}
      </div>
      <div className="flex-1 h-px bg-slate-200 mt-4" />
    </div>
  )
}

export function ReportCard({ title, children, className = '', accent }: { title?: string; children: ReactNode; className?: string; accent?: string }) {
  return (
    <div className={`rpt-card rounded-xl border border-slate-200 bg-white shadow-sm ${className}`} style={{ breakInside: 'avoid' }}>
      {title && (
        <div className="px-4 pt-3 pb-2 border-b border-slate-100 flex items-center gap-2">
          <span className="w-1 h-3.5 rounded-full" style={{ background: accent ?? '#d97706' }} />
          <p className="text-[11px] font-bold uppercase tracking-wide text-slate-600">{title}</p>
        </div>
      )}
      <div className="p-4">{children}</div>
    </div>
  )
}

export function MiniStat({ label, value, sub, color = '#0f172a', bg = '#f8fafc' }: { label: string; value: ReactNode; sub?: string; color?: string; bg?: string }) {
  return (
    <div className="rounded-lg border border-slate-200 px-3 py-2.5" style={{ background: bg, breakInside: 'avoid' }}>
      <p className="text-[9px] font-semibold uppercase tracking-wider text-slate-500">{label}</p>
      <p className="text-xl font-bold leading-tight mt-0.5" style={{ color }}>{value}</p>
      {sub && <p className="text-[9px] text-slate-400 mt-0.5">{sub}</p>}
    </div>
  )
}

export function Chip({ children, color = '#64748b', soft = false }: { children: ReactNode; color?: string; soft?: boolean }) {
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold"
      style={soft
        ? { borderColor: color + '33', background: color + '14', color }
        : { borderColor: color, background: color, color: '#fff' }}
    >
      {children}
    </span>
  )
}

export function Bar({ value, max = 100, color = '#d97706', track = '#f1f5f9', h = 6, showPct = true }: { value: number; max?: number; color?: string; track?: string; h?: number; showPct?: boolean }) {
  const pctv = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0
  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="flex-1 rounded-full overflow-hidden min-w-[40px]" style={{ background: track, height: h }}>
        <div className="rounded-full h-full" style={{ width: `${pctv}%`, background: color }} />
      </div>
      {showPct && <span className="text-[9px] font-bold text-slate-600 w-8 text-right shrink-0">{pctv}%</span>}
    </div>
  )
}

export function Table({ head, children, className = '' }: { head: string[]; children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-lg border border-slate-200 overflow-hidden ${className}`} style={{ breakInside: 'auto' }}>
      <table className="w-full text-[10px]">
        <thead>
          <tr className="bg-slate-100 text-left text-slate-600">
            {head.map((h, i) => <th key={i} className="px-2.5 py-1.5 font-bold uppercase tracking-wide whitespace-nowrap" style={{ fontSize: 9 }}>{h}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">{children}</tbody>
      </table>
    </div>
  )
}

export function Tr({ children }: { children: ReactNode }) {
  return <tr className="align-middle" style={{ breakInside: 'avoid' }}>{children}</tr>
}

export function Td({ children, className = '', style }: { children?: ReactNode; className?: string; style?: React.CSSProperties }) {
  return <td className={`px-2.5 py-1.5 text-slate-700 ${className}`} style={style}>{children}</td>
}

// Teks ditampilkan UTUH (tidak dipotong) — nama panjang otomatis wrap dalam sel
export function Truncated({ text }: { text: string; max?: number }) {
  if (!text) return <span className="text-slate-400">—</span>
  return <span>{text}</span>
}
