'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Camera, Upload, ScanFace, CheckCircle2, XCircle, LogIn, LogOut, HardHat,
  HeartPulse, Target, CalendarDays, Trophy, Loader2, UserCheck, SwitchCamera, Smartphone, RefreshCcw,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { api, APD_LIST, ATT_STATUS, ROLE_LABEL, fmtTime, fmtDate, scoreColor, scoreBg, roleBadge } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { AseiAvatar, SimpleBar, EmptyState } from '../ui-bits'
import type { PhotoAnalysis, Attendance as Att } from '@/lib/types'

export default function AttendanceView() {
  const { employees, attendance, tasks, kpi, refresh } = useAsei()
  const eMap = useMemo(() => empMap(employees), [employees])
  const { toast } = useToast()

  const [empId, setEmpId] = useState('')
  const [photo, setPhoto] = useState<string | null>(null)
  const [analysis, setAnalysis] = useState<PhotoAnalysis | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [camOpen, setCamOpen] = useState(false)
  const [camError, setCamError] = useState('')
  const [facing, setFacing] = useState<'environment' | 'user'>('environment')
  const [camStarting, setCamStarting] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const nativeCamRef = useRef<HTMLInputElement>(null)

  const today = new Date(); today.setHours(0, 0, 0, 0)
  const todayEnd = new Date(); todayEnd.setHours(23, 59, 59, 999)
  const todayAtt = useMemo(() => attendance.filter(a => { const d = new Date(a.date); return d >= today && d <= todayEnd }), [attendance])

  const myToday = todayAtt.find(a => a.employeeId === empId)
  const emp = empId ? eMap[empId] : null

  // KPI data for selected employee
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
  const monthlyKpi = kpi.find(k => k.employeeId === empId && k.period === 'MONTHLY' && new Date(k.periodStart) >= monthStart)
  const weeklyKpi = kpi.find(k => k.employeeId === empId && k.period === 'WEEKLY')
  const myTasks = tasks.filter(t => t.assigneeId === empId)
  const taskCompletion = myTasks.length ? Math.round(myTasks.reduce((s, t) => s + t.progress, 0) / myTasks.length) : 0
  const last7 = attendance.filter(a => a.employeeId === empId && a.ppeScore > 0)
  const avgPpe7 = last7.length ? Math.round(last7.reduce((s, a) => s + a.ppeScore, 0) / last7.length) : 0
  const avgMood7 = last7.length ? Math.round(last7.reduce((s, a) => s + a.moodScore, 0) / last7.length) : 0

  useEffect(() => { if (!empId && employees.length > 0) setEmpId('') }, [employees, empId])

  const stopCam = () => { streamRef.current?.getTracks().forEach(t => t.stop()); streamRef.current = null }
  const closeCam = () => { stopCam(); setCamOpen(false) }

  // Kamera fleksibel: mode 'environment' (belakang, utk foto lokasi/APD) atau 'user' (depan, selfie absensi).
  // Memakai { ideal } agar tetap berfungsi di laptop/webcam (fallback otomatis), dan restart stream saat berganti.
  const startCam = async (mode: 'environment' | 'user' = facing) => {
    if (camStarting) return
    setCamOpen(true); setCamError(''); setCamStarting(true)
    stopCam() // lepaskan stream lama dulu — di HP kamera berakses eksklusif
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: mode }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      })
      streamRef.current = stream
      // sinkronkan label dgn kamera yang benar-benar aktif (bila perangkat memberi info)
      const st = stream.getVideoTracks()[0]?.getSettings?.()
      if (st?.facingMode === 'user' || st?.facingMode === 'environment') setFacing(st.facingMode)
      else setFacing(mode)
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play().catch(() => { /* autoplay ditangani atribut autoPlay+playsInline */ })
      }
    } catch {
      setCamError('Kamera tidak dapat diakses. Izinkan izin kamera pada browser Anda, atau gunakan tombol "Kamera HP" (kamera bawaan) / Upload Foto.')
    } finally {
      setCamStarting(false)
    }
  }
  const switchCam = () => startCam(facing === 'environment' ? 'user' : 'environment')

  // pastikan kamera mati saat tab/view ditutup agar tidak menyala terus di HP
  useEffect(() => () => { streamRef.current?.getTracks().forEach(t => t.stop()) }, [])

  const capture = () => {
    const v = videoRef.current
    if (!v) return
    const c = document.createElement('canvas')
    c.width = v.videoWidth || 640; c.height = v.videoHeight || 480
    const ctx = c.getContext('2d')
    if (ctx) {
      if (facing === 'user') { ctx.translate(c.width, 0); ctx.scale(-1, 1) } // hasil sama seperti yang terlihat (mirror)
      ctx.drawImage(v, 0, 0, c.width, c.height)
    }
    const dataUrl = c.toDataURL('image/jpeg', 0.82)
    setPhoto(dataUrl); setAnalysis(null); closeCam()
  }

  const onFile = (f: File | null) => {
    if (!f) return
    const reader = new FileReader()
    reader.onload = () => { setPhoto(String(reader.result)); setAnalysis(null) }
    reader.readAsDataURL(f)
  }

  const analyzeOnly = async () => {
    if (!photo) return toast({ title: 'Ambil atau upload foto dulu', variant: 'destructive' })
    setAnalyzing(true)
    try {
      const j = await api<{ data: PhotoAnalysis }>('/api/ai/analyze-photo', { method: 'POST', body: JSON.stringify({ photo }) })
      setAnalysis(j.data)
      toast({ title: 'Analisis AI selesai', description: `APD ${j.data.ppeScore}/100 • Mood ${j.data.moodScore}/100` })
    } catch (e) {
      toast({ title: 'Analisis gagal', description: String(e), variant: 'destructive' })
    } finally { setAnalyzing(false) }
  }

  const submit = async () => {
    if (!empId) return toast({ title: 'Pilih karyawan dulu', variant: 'destructive' })
    setSubmitting(true)
    try {
      const j = await api<{ data: { mode: string; attendance: Att; analysis: PhotoAnalysis | null } }>('/api/attendance/checkin', {
        method: 'POST', body: JSON.stringify({ employeeId: empId, photo }),
      })
      setAnalysis(j.data.analysis)
      toast({ title: j.data.mode === 'CHECK_IN' ? 'Check-in berhasil' : 'Check-out berhasil', description: j.data.analysis ? `AI: APD ${j.data.analysis.ppeScore}/100, emosi ${j.data.analysis.emotion}` : 'Tanpa foto (tidak dianalisis AI)' })
      setPhoto(null)
      await refresh('attendance'); await refresh('employees'); await refresh('kpi')
    } catch (e) {
      toast({ title: 'Gagal', description: String(e), variant: 'destructive' })
    } finally { setSubmitting(false) }
  }

  return (
    <div className="space-y-5">
      <div className="grid lg:grid-cols-5 gap-4">
        {/* ---- Capture panel ---- */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><ScanFace className="h-4 w-4 text-amber-500" /> Absensi Foto Lokasi Proyek (Analisis AI APD & Kondisi Mental)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid sm:grid-cols-[1fr_auto] gap-3 items-end">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Pilih Karyawan</label>
                <Select value={empId} onValueChange={setEmpId}>
                  <SelectTrigger className="w-full"><SelectValue placeholder="— Pilih karyawan —" /></SelectTrigger>
                  <SelectContent className="max-h-72">
                    {employees.map(e => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.nip} • {e.name} — {ROLE_LABEL[e.role] ?? e.role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => startCam()} variant="outline" className="gap-1.5"><Camera className="h-4 w-4" /> Kamera</Button>
                <Button onClick={() => fileRef.current?.click()} variant="outline" className="gap-1.5"><Upload className="h-4 w-4" /> Upload</Button>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => onFile(e.target.files?.[0] ?? null)} />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="relative rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 overflow-hidden aspect-[4/3] flex items-center justify-center">
                {photo ? (
                  <img src={photo} alt="Foto absensi" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center text-slate-400 p-4">
                    <Camera className="h-10 w-10 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">Ambil foto langsung di lokasi atau upload foto pekerja.<br />AI akan menganalisis kelengkapan APD & ekspresi wajah.</p>
                  </div>
                )}
              </div>

              {/* AI analysis result */}
              <div className="rounded-xl border bg-slate-50/60 p-3 overflow-y-auto max-h-64">
                {analyzing ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400">
                    <Loader2 className="h-8 w-8 animate-spin text-amber-500 mb-2" />
                    <p className="text-xs">AI sedang menganalisis foto…</p>
                  </div>
                ) : analysis ? (
                  <div className="space-y-2.5 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-500">SKOR APD</span>
                      <span className={`text-lg font-bold ${scoreColor(analysis.ppeScore)}`}>{analysis.ppeScore}/100</span>
                    </div>
                    <SimpleBar value={analysis.ppeScore} color={scoreBg(analysis.ppeScore)} />
                    <div className="grid grid-cols-2 gap-1.5">
                      {APD_LIST.map(item => {
                        const ok = analysis.ppe[item.key as keyof typeof analysis.ppe]
                        return (
                          <div key={item.key} className={`flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs ${ok ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-red-200 bg-red-50 text-red-600'}`}>
                            {ok ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                            {item.label}
                          </div>
                        )
                      })}
                    </div>
                    <div className="flex items-center justify-between rounded-md border px-2 py-1.5 bg-white">
                      <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5"><HeartPulse className="h-3.5 w-3.5 text-rose-500" /> KONDISI WAJAH</span>
                      <span className="text-sm">{analysis.emotion === 'happy' ? '😊' : analysis.emotion === 'neutral' ? '😐' : analysis.emotion === 'tired' ? '😴' : analysis.emotion === 'stressed' ? '😣' : '❓'} <b className="capitalize">{analysis.emotion}</b> · mood {analysis.moodScore}/100</span>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">{analysis.aiNotes}</p>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center p-4">
                    <ScanFace className="h-8 w-8 mb-2 opacity-50" />
                    <p className="text-xs">Hasil analisis AI akan muncul di sini:<br />APD (helm, rompi, sarung tangan, sepatu, goggles),<br />emosi & indeks kebahagiaan pekerja.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button onClick={analyzeOnly} disabled={!photo || analyzing} variant="secondary" className="gap-1.5">
                {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <ScanFace className="h-4 w-4" />} Analisis AI Dulu
              </Button>
              <Button onClick={submit} disabled={!empId || submitting} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : myToday?.checkIn && !myToday?.checkOut ? <LogOut className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
                {myToday?.checkIn && !myToday?.checkOut ? 'Check-Out' : 'Check-In'}
              </Button>
              {photo && <Button variant="ghost" onClick={() => { setPhoto(null); setAnalysis(null) }}>Hapus Foto</Button>}
            </div>
            {emp && myToday && (
              <p className="text-xs text-slate-500 flex items-center gap-1.5">
                <UserCheck className="h-3.5 w-3.5 text-emerald-500" />
                {emp.name}: masuk {fmtTime(myToday.checkIn)} {myToday.checkOut ? `• keluar ${fmtTime(myToday.checkOut)} • ${myToday.workHours} jam` : '• belum check-out'} • status {ATT_STATUS[myToday.status]}
              </p>
            )}
          </CardContent>
        </Card>

        {/* ---- KPI cards for selected employee ---- */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><Target className="h-4 w-4 text-amber-500" /> Kartu Kinerja Karyawan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {!emp ? (
              <EmptyState icon={<Target className="h-10 w-10" />} title="Pilih karyawan" sub="Kartu kinerja harian, mingguan & bulanan tampil di sini" />
            ) : (
              <>
                {/* Daily card */}
                <div className="rounded-xl border border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-amber-700 flex items-center gap-1.5"><CalendarDays className="h-3.5 w-3.5" /> DAILY CARD — Hari Ini</p>
                    {myToday && <Badge className={`border ${roleBadge(myToday.status)} text-[10px]`}>{ATT_STATUS[myToday.status]}</Badge>}
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-2.5 text-center">
                    <div><p className="text-[10px] text-slate-500">Kehadiran</p><p className={`text-sm font-bold ${myToday ? (myToday.status === 'PRESENT' ? 'text-emerald-600' : myToday.status === 'LATE' ? 'text-amber-600' : 'text-red-500') : 'text-slate-400'}`}>{myToday ? (myToday.lateMinutes > 0 ? `Telat ${myToday.lateMinutes}m` : 'Tepat') : 'Belum'}</p></div>
                    <div><p className="text-[10px] text-slate-500">APD (AI)</p><p className={`text-sm font-bold ${scoreColor(myToday?.ppeScore ?? 0)}`}>{myToday?.ppeScore ?? '-'}</p></div>
                    <div><p className="text-[10px] text-slate-500">Mood (AI)</p><p className={`text-sm font-bold ${scoreColor(myToday?.moodScore ?? 0)}`}>{myToday?.moodScore ?? '-'} {myToday?.emotion && myToday.moodScore > 0 ? ['happy', 'neutral', 'tired', 'stressed'].includes(myToday.emotion) ? { happy: '😊', neutral: '😐', tired: '😴', stressed: '😣' }[myToday.emotion] : '' : ''}</p></div>
                  </div>
                  <div className="mt-2.5">
                    <div className="flex justify-between text-[10px] text-slate-500 mb-1"><span>Disiplin & target task</span><span className="font-bold">{taskCompletion}%</span></div>
                    <SimpleBar value={taskCompletion} color={scoreBg(taskCompletion)} height="h-1.5" />
                  </div>
                </div>

                {/* Weekly card */}
                <div className="rounded-xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 p-3">
                  <p className="text-xs font-bold text-emerald-700 flex items-center gap-1.5"><Trophy className="h-3.5 w-3.5" /> WEEKLY CARD</p>
                  <div className="grid grid-cols-3 gap-2 mt-2.5 text-center">
                    <div><p className="text-[10px] text-slate-500">APD 7 hari</p><p className={`text-sm font-bold ${scoreColor(avgPpe7)}`}>{avgPpe7}</p></div>
                    <div><p className="text-[10px] text-slate-500">Mood 7 hari</p><p className={`text-sm font-bold ${scoreColor(avgMood7)}`}>{avgMood7}</p></div>
                    <div><p className="text-[10px] text-slate-500">KPI Mingguan</p><p className={`text-sm font-bold ${scoreColor(weeklyKpi?.overallScore ?? 0)}`}>{weeklyKpi?.overallScore ?? '-'}</p></div>
                  </div>
                </div>

                {/* Monthly KPI card */}
                <div className="rounded-xl border border-orange-200 bg-gradient-to-br from-orange-50 to-amber-50 p-3">
                  <p className="text-xs font-bold text-orange-700 flex items-center gap-1.5"><HardHat className="h-3.5 w-3.5" /> MONTHLY KPI</p>
                  {monthlyKpi ? (
                    <div className="space-y-1.5 mt-2">
                      {([
                        ['Kehadiran', monthlyKpi.attendanceScore], ['Penyelesaian Task', monthlyKpi.taskScore],
                        ['Disiplin', monthlyKpi.disciplineScore], ['Kualitas', monthlyKpi.qualityScore], ['Safety', monthlyKpi.safetyScore],
                      ] as const).map(([label, v]) => (
                        <div key={label} className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500 w-28">{label}</span>
                          <SimpleBar value={v} color={scoreBg(v)} height="h-1.5" />
                          <span className={`text-[10px] font-bold w-8 text-right ${scoreColor(v)}`}>{v}</span>
                        </div>
                      ))}
                      <div className="flex items-center justify-between pt-1 border-t">
                        <span className="text-xs font-semibold text-slate-600">Overall</span>
                        <span className={`text-lg font-bold ${scoreColor(monthlyKpi.overallScore)}`}>{monthlyKpi.overallScore}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 italic">{monthlyKpi.notes}</p>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 mt-2">Belum ada KPI bulanan.</p>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ---- Today's attendance table ---- */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-sm">Absensi Hari Ini — {fmtDate(new Date())}</CardTitle>
            <div className="flex gap-2 text-xs">
              <Badge variant="outline" className="border-emerald-300 text-emerald-700">Hadir {todayAtt.filter(a => a.status === 'PRESENT').length}</Badge>
              <Badge variant="outline" className="border-amber-300 text-amber-700">Telat {todayAtt.filter(a => a.status === 'LATE').length}</Badge>
              <Badge variant="outline" className="border-sky-300 text-sky-700">Izin {todayAtt.filter(a => a.status === 'LEAVE').length}</Badge>
              <Badge variant="outline" className="border-red-300 text-red-700">Absen {todayAtt.filter(a => a.status === 'ABSENT').length}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b text-left text-xs text-slate-500">
                  <th className="px-3 py-2 font-medium">Karyawan</th>
                  <th className="px-3 py-2 font-medium">Posisi</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                  <th className="px-3 py-2 font-medium">Masuk</th>
                  <th className="px-3 py-2 font-medium">Keluar</th>
                  <th className="px-3 py-2 font-medium">APD</th>
                  <th className="px-3 py-2 font-medium">Mood</th>
                  <th className="px-3 py-2 font-medium">Foto</th>
                  <th className="px-3 py-2 font-medium">Catatan AI</th>
                </tr>
              </thead>
              <tbody>
                {todayAtt.map(a => {
                  const e = eMap[a.employeeId]
                  if (!e) return null
                  const det = (() => { try { return JSON.parse(a.ppeDetails) } catch { return {} } })()
                  return (
                    <tr key={a.id} className="border-b last:border-0 hover:bg-slate-50/70">
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2">
                          <AseiAvatar name={e.name} color={e.avatarColor} className="h-7 w-7" />
                          <div><p className="font-medium text-xs">{e.name}</p><p className="text-[10px] text-slate-400">{e.nip}</p></div>
                        </div>
                      </td>
                      <td className="px-3 py-2 text-xs">{e.role === 'WORKER' ? e.subDiscipline : ROLE_LABEL[e.role] ?? e.role}</td>
                      <td className="px-3 py-2"><Badge variant="outline" className={`text-[10px] ${roleBadge(a.status)}`}>{ATT_STATUS[a.status]}</Badge>{a.lateMinutes > 0 && <span className="text-[10px] text-amber-600 ml-1">+{a.lateMinutes}m</span>}</td>
                      <td className="px-3 py-2 text-xs">{fmtTime(a.checkIn)}</td>
                      <td className="px-3 py-2 text-xs">{a.checkOut ? fmtTime(a.checkOut) : '—'}</td>
                      <td className="px-3 py-2"><span className={`text-xs font-bold ${scoreColor(a.ppeScore)}`}>{a.ppeScore || '—'}</span>
                        <div className="flex gap-0.5 mt-0.5">{APD_LIST.map(i => <span key={i.key} title={i.label} className={`h-1.5 w-3 rounded-sm ${det[i.key] ? 'bg-emerald-400' : 'bg-red-300'}`} />)}</div>
                      </td>
                      <td className="px-3 py-2 text-xs"><span className={`font-bold ${scoreColor(a.moodScore)}`}>{a.moodScore || '—'}</span> <span className="text-xs">{a.emotion === 'happy' ? '😊' : a.emotion === 'neutral' ? '😐' : a.emotion === 'tired' ? '😴' : a.emotion === 'stressed' ? '😣' : ''}</span></td>
                      <td className="px-3 py-2">
                        {a.checkInPhoto ? (
                          <Dialog>
                            <DialogTrigger asChild>
                              <button aria-label="Lihat foto"><img src={a.checkInPhoto} alt="Foto check-in" className="h-9 w-12 rounded object-cover border hover:opacity-80" /></button>
                            </DialogTrigger>
                            <DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Foto Check-In — {e.name}</DialogTitle></DialogHeader><img src={a.checkInPhoto} alt="Foto check-in besar" className="w-full rounded-lg" /></DialogContent>
                          </Dialog>
                        ) : <span className="text-[10px] text-slate-400">tidak ada</span>}
                      </td>
                      <td className="px-3 py-2 text-[10px] text-slate-500 max-w-40 truncate" title={a.aiNotes}>{a.aiNotes || '—'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            {todayAtt.length === 0 && <EmptyState title="Belum ada absensi hari ini" sub="Lakukan check-in pertama dengan foto" />}
          </div>
        </CardContent>
      </Card>

      {/* Camera dialog — fleksibel: depan/belakang + fallback kamera bawaan HP */}
      <Dialog open={camOpen} onOpenChange={o => { if (!o) closeCam() }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Camera className="h-4 w-4 text-amber-500" /> Foto Absensi Lokasi</DialogTitle></DialogHeader>
          <div className="relative">
            {camError ? (
              <div className="text-sm text-red-600 bg-red-50 rounded-lg p-3 border border-red-200">{camError}</div>
            ) : (
              <video ref={videoRef} autoPlay playsInline muted
                className={`rounded-xl w-full bg-black aspect-[4/3] ${facing === 'user' ? '-scale-x-100' : ''}`} />
            )}
            {camStarting && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-xl">
                <Loader2 className="h-6 w-6 animate-spin text-white" />
              </div>
            )}
            {!camError && (
              <div className="absolute left-3 top-3 rounded-full bg-black/55 text-white text-[11px] px-2.5 py-1 flex items-center gap-1.5 backdrop-blur-sm">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
                </span>
                {facing === 'environment' ? 'Kamera Belakang' : 'Kamera Depan'}
              </div>
            )}
          </div>
          {!camError && (
            <Button variant="outline" onClick={switchCam} disabled={camStarting} className="w-full gap-1.5">
              <SwitchCamera className="h-4 w-4" /> Ganti Kamera (ke {facing === 'environment' ? 'Depan' : 'Belakang'})
            </Button>
          )}
          <div className="flex flex-wrap gap-2 justify-end">
            <Button variant="outline" onClick={() => nativeCamRef.current?.click()} title="Buka kamera bawaan HP — bila kamera browser bermasalah"
              className="gap-1.5"><Smartphone className="h-4 w-4" /> Kamera HP</Button>
            {camError && <Button variant="outline" onClick={() => startCam(facing)} className="gap-1.5"><RefreshCcw className="h-4 w-4" /> Coba Lagi</Button>}
            <Button variant="ghost" onClick={closeCam}>Tutup</Button>
            {!camError && <Button onClick={capture} disabled={camStarting} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white gap-1.5"><Camera className="h-4 w-4" /> Ambil Foto</Button>}
          </div>
          <p className="text-[11px] text-slate-400">Kamera belakang untuk foto lokasi & APD, kamera depan untuk selfie absensi. Di HP, izinkan akses kamera saat browser meminta izin.</p>
          <input ref={nativeCamRef} type="file" accept="image/*" capture={facing} className="hidden"
            onChange={e => { const f = e.target.files?.[0] ?? null; e.target.value = ''; onFile(f); if (f) closeCam() }} />
        </DialogContent>
      </Dialog>
    </div>
  )
}
