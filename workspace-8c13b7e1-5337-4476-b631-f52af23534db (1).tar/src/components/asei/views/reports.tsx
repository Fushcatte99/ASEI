'use client'
import { useState } from 'react'
import {
  FileText, Plus, Pencil, Trash2, Sparkles, Loader2, ClipboardPen, CalendarDays, Bot,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { api, createRes, updateRes, deleteRes, ROLES, ROLE_LABEL, roleBadge, statusBadge, fmtDate, dateInput, activeProjectId } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { AseiAvatar, EmptyState } from '../ui-bits'
import ReactMarkdown from 'react-markdown'
import type { DailyReport, WeeklyReport, AiSummary } from '@/lib/types'

export default function ReportsView() {
  const [tab, setTab] = useState<'daily' | 'weekly' | 'ai'>('daily')
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'daily', label: 'Laporan Harian', icon: ClipboardPen },
          { id: 'weekly', label: 'Laporan & Rencana Mingguan', icon: CalendarDays },
          { id: 'ai', label: 'AI Summary Generator', icon: Sparkles },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium border transition-colors ${tab === t.id ? 'bg-slate-900 text-white border-slate-900 shadow' : 'bg-white hover:bg-slate-50'}`}>
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>
      {tab === 'daily' && <DailyTab />}
      {tab === 'weekly' && <WeeklyTab />}
      {tab === 'ai' && <AiSummaryTab />}
    </div>
  )
}

/* ============ DAILY ============ */
function DailyTab() {
  const { dailyReports, employees, refresh } = useAsei()
  const eMap = empMap(employees)
  const { toast } = useToast()
  const [fRole, setFRole] = useState('ALL')
  const [form, setForm] = useState<Partial<DailyReport> | null>(null)
  const [saving, setSaving] = useState(false)

  const reports = [...dailyReports].filter(r => fRole === 'ALL' || r.role === fRole).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  const save = async () => {
    if (!form?.employeeId || !form?.activities) return toast({ title: 'Karyawan & aktivitas wajib', variant: 'destructive' })
    setSaving(true)
    try {
      const emp = eMap[form.employeeId]
      const payload = { ...form, role: emp?.role ?? '', discipline: emp?.discipline ?? '' }
      if (form.id) await updateRes('daily-reports', form.id, payload)
      else await createRes('daily-reports', payload)
      toast({ title: form.id ? 'Laporan diperbarui' : 'Laporan harian tersimpan' })
      setForm(null); await refresh('daily-reports')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (r: DailyReport) => {
    if (!confirm('Hapus laporan ini?')) return
    try { await deleteRes('daily-reports', r.id); await refresh('daily-reports'); toast({ title: 'Laporan dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={fRole} onValueChange={setFRole}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Posisi</SelectItem>{ROLES.map(r => <SelectItem key={r} value={r}>{r} — {ROLE_LABEL[r]}</SelectItem>)}</SelectContent>
        </Select>
        <Button size="sm" onClick={() => setForm({ employeeId: '', date: new Date().toISOString(), activities: '', achievements: '', issues: '', planTomorrow: '', weather: 'Cerah', manpowerCount: 0, workHours: 8, status: 'SUBMITTED' })} className="ml-auto gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tulis Laporan</Button>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {reports.map(r => {
          const e = eMap[r.employeeId]
          return (
            <Card key={r.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center gap-2.5">
                  {e && <AseiAvatar name={e.name} color={e.avatarColor} className="h-8 w-8" />}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold truncate">{e?.name ?? '—'}</p>
                    <p className="text-[11px] text-slate-500">{r.role} • {fmtDate(r.date)} • cuaca {r.weather}{r.manpowerCount > 0 ? ` • ${r.manpowerCount} orang` : ''}</p>
                  </div>
                  <Badge variant="outline" className={`text-[9px] ${statusBadge(r.status)}`}>{r.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="px-4 pb-4 pt-0 space-y-2 text-xs">
                <div><p className="text-[10px] font-semibold text-slate-400 uppercase">Aktivitas</p><p className="text-slate-700 leading-relaxed">{r.activities}</p></div>
                {r.achievements && <div><p className="text-[10px] font-semibold text-emerald-500 uppercase">Capaian</p><p className="text-slate-700">{r.achievements}</p></div>}
                {r.issues && <div><p className="text-[10px] font-semibold text-red-400 uppercase">Kendala</p><p className="text-red-700">{r.issues}</p></div>}
                {r.planTomorrow && <div><p className="text-[10px] font-semibold text-slate-400 uppercase">Rencana Besok</p><p className="text-slate-700">{r.planTomorrow}</p></div>}
                <div className="flex gap-1.5 pt-1">
                  <Button size="sm" variant="outline" className="h-6 text-[10px]" onClick={() => setForm({ ...r, date: dateInput(r.date) })}><Pencil className="h-2.5 w-2.5 mr-1" />Edit</Button>
                  <Button size="sm" variant="outline" className="h-6 text-[10px] text-red-600" onClick={() => remove(r)}><Trash2 className="h-2.5 w-2.5 mr-1" />Hapus</Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
      {reports.length === 0 && <EmptyState icon={<FileText className="h-10 w-10" />} title="Belum ada laporan harian" />}

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Laporan Harian' : 'Tulis Laporan Harian'}</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Karyawan *</Label>
                <Select value={form?.employeeId ?? ''} onValueChange={v => setForm(f => ({ ...f, employeeId: v }))}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent className="max-h-60">{employees.map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role})</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Tanggal</Label><Input type="date" value={form?.date ? String(form.date).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} /></div>
            </div>
            <div className="space-y-1"><Label>Aktivitas Hari Ini *</Label><Textarea rows={3} value={form?.activities ?? ''} onChange={e => setForm(f => ({ ...f, activities: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Capaian</Label><Textarea rows={2} value={form?.achievements ?? ''} onChange={e => setForm(f => ({ ...f, achievements: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Kendala / Issue</Label><Textarea rows={2} value={form?.issues ?? ''} onChange={e => setForm(f => ({ ...f, issues: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Rencana Besok</Label><Textarea rows={2} value={form?.planTomorrow ?? ''} onChange={e => setForm(f => ({ ...f, planTomorrow: e.target.value }))} /></div>
            <div className="grid grid-cols-4 gap-2">
              <div className="space-y-1 col-span-2"><Label>Cuaca</Label>
                <Select value={form?.weather ?? 'Cerah'} onValueChange={v => setForm(f => ({ ...f, weather: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{['Cerah', 'Berawan', 'Hujan Ringan', 'Hujan Deras'].map(w => <SelectItem key={w} value={w}>{w}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Manpower</Label><Input type="number" value={form?.manpowerCount ?? 0} onChange={e => setForm(f => ({ ...f, manpowerCount: Number(e.target.value) }))} /></div>
              <div className="space-y-1"><Label>Jam Kerja</Label><Input type="number" value={form?.workHours ?? 8} onChange={e => setForm(f => ({ ...f, workHours: Number(e.target.value) }))} /></div>
            </div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ============ WEEKLY ============ */
function WeeklyTab() {
  const { weeklyReports, employees, refresh } = useAsei()
  const eMap = empMap(employees)
  const { toast } = useToast()
  const [form, setForm] = useState<Partial<WeeklyReport> | null>(null)
  const [saving, setSaving] = useState(false)

  const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7)); weekStart.setHours(0, 0, 0, 0)
  const weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 6)
  const reports = [...weeklyReports].sort((a, b) => new Date(b.weekStart).getTime() - new Date(a.weekStart).getTime())

  const save = async () => {
    if (!form?.employeeId) return toast({ title: 'Karyawan wajib', variant: 'destructive' })
    setSaving(true)
    try {
      const emp = eMap[form.employeeId]
      const payload = { ...form, role: emp?.role ?? '' }
      if (form.id) await updateRes('weekly-reports', form.id, payload)
      else await createRes('weekly-reports', payload)
      toast({ title: form.id ? 'Diperbarui' : 'Tersimpan' })
      setForm(null); await refresh('weekly-reports')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (r: WeeklyReport) => {
    if (!confirm('Hapus?')) return
    try { await deleteRes('weekly-reports', r.id); await refresh('weekly-reports'); toast({ title: 'Dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Badge variant="outline" className="border-amber-300 text-amber-700">Minggu ini: {fmtDate(weekStart)} — {fmtDate(weekEnd)}</Badge>
        <Button size="sm" onClick={() => setForm({ employeeId: '', type: 'REPORT', weekStart: weekStart.toISOString(), weekEnd: weekEnd.toISOString(), achievements: '', issues: '', nextWeekPlan: '', progressSummary: '', status: 'SUBMITTED' })} className="ml-auto gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tulis Weekly</Button>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {reports.map(r => {
          const e = eMap[r.employeeId]
          return (
            <Card key={r.id}>
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-center gap-2.5">
                  {e && <AseiAvatar name={e.name} color={e.avatarColor} className="h-8 w-8" />}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold truncate">{e?.name ?? '—'}</p>
                    <p className="text-[11px] text-slate-500">{r.role} • {fmtDate(r.weekStart)} — {fmtDate(r.weekEnd)}</p>
                  </div>
                  <Badge variant="outline" className={`text-[9px] ${r.type === 'PLAN' ? 'border-sky-300 text-sky-700' : 'border-orange-300 text-orange-700'}`}>{r.type === 'PLAN' ? 'RENCANA' : 'LAPORAN'}</Badge>
                </div>
              </CardHeader>
              <CardContent className="px-4 pb-4 pt-0 space-y-2 text-xs">
                {r.achievements && <div><p className="text-[10px] font-semibold text-emerald-500 uppercase">Capaian</p><p className="text-slate-700">{r.achievements}</p></div>}
                {r.issues && <div><p className="text-[10px] font-semibold text-red-400 uppercase">Kendala</p><p className="text-red-700">{r.issues}</p></div>}
                {r.nextWeekPlan && <div><p className="text-[10px] font-semibold text-slate-400 uppercase">Rencana Minggu Depan</p><p className="text-slate-700">{r.nextWeekPlan}</p></div>}
                {r.progressSummary && <div><p className="text-[10px] font-semibold text-slate-400 uppercase">Ringkasan Progress</p><p className="text-slate-700">{r.progressSummary}</p></div>}
                <div className="flex gap-1.5 pt-1">
                  <Button size="sm" variant="outline" className="h-6 text-[10px]" onClick={() => setForm({ ...r, weekStart: dateInput(r.weekStart), weekEnd: dateInput(r.weekEnd) })}><Pencil className="h-2.5 w-2.5 mr-1" />Edit</Button>
                  <Button size="sm" variant="outline" className="h-6 text-[10px] text-red-600" onClick={() => remove(r)}><Trash2 className="h-2.5 w-2.5 mr-1" />Hapus</Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
      {reports.length === 0 && <EmptyState icon={<CalendarDays className="h-10 w-10" />} title="Belum ada laporan mingguan" />}

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Weekly' : 'Tulis Laporan/Rencana Mingguan'}</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Karyawan *</Label>
                <Select value={form?.employeeId ?? ''} onValueChange={v => setForm(f => ({ ...f, employeeId: v }))}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent className="max-h-60">{employees.map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role})</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Jenis</Label>
                <Select value={form?.type ?? 'REPORT'} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="REPORT">Laporan</SelectItem><SelectItem value="PLAN">Rencana</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Minggu Mulai</Label><Input type="date" value={form?.weekStart ? String(form.weekStart).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, weekStart: e.target.value }))} /></div>
              <div className="space-y-1"><Label>Minggu Selesai</Label><Input type="date" value={form?.weekEnd ? String(form.weekEnd).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, weekEnd: e.target.value }))} /></div>
            </div>
            <div className="space-y-1"><Label>Capaian Minggu Ini</Label><Textarea rows={3} value={form?.achievements ?? ''} onChange={e => setForm(f => ({ ...f, achievements: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Kendala</Label><Textarea rows={2} value={form?.issues ?? ''} onChange={e => setForm(f => ({ ...f, issues: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Rencana Minggu Depan</Label><Textarea rows={3} value={form?.nextWeekPlan ?? ''} onChange={e => setForm(f => ({ ...f, nextWeekPlan: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Ringkasan Progress</Label><Input value={form?.progressSummary ?? ''} onChange={e => setForm(f => ({ ...f, progressSummary: e.target.value }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ============ AI SUMMARY ============ */
function AiSummaryTab() {
  const { summaries, employees, refresh } = useAsei()
  const eMap = empMap(employees)
  const { toast } = useToast()
  const [scope, setScope] = useState('PROJECT')
  const [employeeId, setEmployeeId] = useState('')
  const [role, setRole] = useState('')
  const [days, setDays] = useState(7)
  const [loading, setLoading] = useState(false)

  const generate = async () => {
    if (scope === 'INDIVIDUAL' && !employeeId) return toast({ title: 'Pilih karyawan dulu', variant: 'destructive' })
    if (scope === 'TEAM' && !role) return toast({ title: 'Pilih posisi dulu', variant: 'destructive' })
    setLoading(true)
    try {
      const j = await api<{ data: AiSummary }>('/api/ai/summary', { method: 'POST', body: JSON.stringify({ scope, employeeId, role, days, projectId: activeProjectId() }) })
      toast({ title: 'Ringkasan AI selesai dibuat' })
      await refresh('summaries')
    } catch (e) { toast({ title: 'Gagal generate', description: String(e), variant: 'destructive' }) }
    finally { setLoading(false) }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Sparkles className="h-4 w-4 text-orange-500" /> Generate Ringkasan AI — semua posisi: Worker, Welder, Foreman, Supervisor, Engineer, SM, HSE, PM</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid sm:grid-cols-4 gap-3">
            <div className="space-y-1"><Label>Cakupan</Label>
              <Select value={scope} onValueChange={setScope}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="INDIVIDUAL">Per Individu</SelectItem>
                  <SelectItem value="TEAM">Per Posisi/Tim</SelectItem>
                  <SelectItem value="PROJECT">Seluruh Proyek</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {scope === 'INDIVIDUAL' && (
              <div className="space-y-1"><Label>Karyawan</Label>
                <Select value={employeeId} onValueChange={setEmployeeId}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent className="max-h-60">{employees.map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role})</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            {scope === 'TEAM' && (
              <div className="space-y-1"><Label>Posisi</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent>{ROLES.map(r => <SelectItem key={r} value={r}>{r} — {ROLE_LABEL[r]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1"><Label>Periode Data</Label>
              <Select value={String(days)} onValueChange={v => setDays(Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="1">1 hari terakhir</SelectItem><SelectItem value="7">7 hari terakhir</SelectItem><SelectItem value="14">14 hari</SelectItem><SelectItem value="30">30 hari</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={generate} disabled={loading} className="w-full gap-1.5 bg-gradient-to-r from-orange-500 to-amber-600 text-white">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bot className="h-4 w-4" />} Generate
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {[...summaries].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(s => {
          const e = s.employeeId ? eMap[s.employeeId] : null
          return (
            <Card key={s.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className={`text-[9px] ${s.scope === 'PROJECT' ? 'border-orange-300 text-orange-700' : s.scope === 'TEAM' ? 'border-sky-300 text-sky-700' : 'border-emerald-300 text-emerald-700'}`}>
                    {s.scope === 'PROJECT' ? 'PROYEK' : s.scope === 'TEAM' ? `TIM ${s.role}` : 'INDIVIDU'}
                  </Badge>
                  {e && <span className={`rounded border px-1 text-[9px] ${roleBadge(e.role)}`}>{e.role}</span>}
                  <p className="text-sm font-semibold">{e ? e.name : s.title}</p>
                  <span className="text-[10px] text-slate-400">{fmtDate(s.periodStart)} — {fmtDate(s.periodEnd)}</span>
                  <Button size="sm" variant="outline" className="ml-auto h-6 text-[10px] text-red-600" onClick={async () => { await deleteRes('summaries', s.id); await refresh('summaries') }}><Trash2 className="h-2.5 w-2.5" /></Button>
                </div>
              </CardHeader>
              <CardContent className="prose prose-sm max-w-none text-sm">
                <ReactMarkdown components={{ h2: p => <h2 className="text-sm font-bold text-slate-800 mt-3 mb-1 border-b pb-1">{p.children}</h2>, li: p => <li className="ml-4 list-disc text-xs leading-relaxed my-0.5">{p.children}</li>, p: p => <p className="text-xs leading-relaxed my-1.5">{p.children}</p> }}>{s.content}</ReactMarkdown>
              </CardContent>
            </Card>
          )
        })}
        {summaries.length === 0 && <EmptyState icon={<Sparkles className="h-10 w-10" />} title="Belum ada ringkasan AI" sub="Pilih cakupan lalu klik Generate" />}
      </div>
    </div>
  )
}
