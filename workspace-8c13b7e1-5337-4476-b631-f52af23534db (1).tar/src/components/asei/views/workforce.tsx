'use client'
import { useMemo, useState } from 'react'
import {
  UserPlus, ShieldCheck, HardHat, Pencil, Trash2, Phone, Mail, Search,
  BadgeCheck, TriangleAlert, Network, Users,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { createRes, updateRes, deleteRes, ROLES, ROLE_LABEL, DISCIPLINES, DISC_LABEL, CIVIL_SUBS, ME_SUBS, EE_SUBS, roleBadge, fmtDate, dateInput } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { AseiAvatar, EmptyState } from '../ui-bits'
import { APD_LIST } from '@/lib/client'
import type { Employee } from '@/lib/types'

const EMPTY: Partial<Employee> = {
  name: '', nip: '', role: 'WORKER', discipline: 'CIVIL', subDiscipline: '', position: '',
  managerId: '', phone: '', email: '', status: 'ACTIVE', safetyInduction: false,
  inductionScore: 0, apdStatus: 'INCOMPLETE', apdItems: '{}', notes: '',
}

export default function WorkforceView() {
  const { employees, refresh } = useAsei()
  const eMap = useMemo(() => empMap(employees), [employees])
  const { toast } = useToast()
  const [q, setQ] = useState('')
  const [fRole, setFRole] = useState('ALL')
  const [fDisc, setFDisc] = useState('ALL')
  const [form, setForm] = useState<Partial<Employee> | null>(null)
  const [apdForm, setApdForm] = useState<{ emp: Employee; items: Record<string, boolean> } | null>(null)
  const [saving, setSaving] = useState(false)
  const [viewEmp, setViewEmp] = useState<Employee | null>(null)

  const filtered = employees.filter(e => {
    const okQ = !q || e.name.toLowerCase().includes(q.toLowerCase()) || e.nip.toLowerCase().includes(q.toLowerCase()) || e.position.toLowerCase().includes(q.toLowerCase())
    const okRole = fRole === 'ALL' || e.role === fRole
    const okDisc = fDisc === 'ALL' || e.discipline === fDisc
    return okQ && okRole && okDisc
  })

  const subs = (emp: Employee) => employees.filter(x => x.managerId === emp.id)
  const noInduction = employees.filter(e => !e.safetyInduction).length
  const apdIncomplete = employees.filter(e => e.apdStatus !== 'COMPLETE').length

  const save = async () => {
    if (!form?.name || !form?.nip) return toast({ title: 'Nama & NIP wajib diisi', variant: 'destructive' })
    setSaving(true)
    try {
      if (form.id) await updateRes('employees', form.id, form)
      else await createRes('employees', form)
      toast({ title: form.id ? 'Karyawan diperbarui' : 'Karyawan ditambahkan' })
      setForm(null); await refresh('employees')
    } catch (e) { toast({ title: 'Gagal menyimpan', description: String(e), variant: 'destructive' }) }
    finally { setSaving(false) }
  }

  const remove = async (emp: Employee) => {
    if (!confirm(`Hapus ${emp.name}? Semua data terkait (absensi, task, laporan) tetap ada tapi tidak tersambung.`)) return
    try { await deleteRes('employees', emp.id); toast({ title: 'Karyawan dihapus' }); await refresh('employees') }
    catch (e) { toast({ title: 'Gagal menghapus', description: String(e), variant: 'destructive' }) }
  }

  const saveApd = async () => {
    if (!apdForm) return
    const complete = Object.values(apdForm.items).every(Boolean)
    try {
      await updateRes('employees', apdForm.emp.id, { apdItems: JSON.stringify(apdForm.items), apdStatus: complete ? 'COMPLETE' : 'INCOMPLETE' })
      toast({ title: 'APD diperbarui', description: complete ? 'Lengkap — boleh kerja' : 'Belum lengkap' })
      setApdForm(null); await refresh('employees')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  const toggleInduction = async (emp: Employee) => {
    try {
      await updateRes('employees', emp.id, {
        safetyInduction: !emp.safetyInduction,
        inductionDate: emp.safetyInduction ? null : new Date().toISOString(),
        inductionScore: emp.safetyInduction ? 0 : Math.max(emp.inductionScore, 80),
      })
      await refresh('employees')
      toast({ title: emp.safetyInduction ? 'Induction dicabut' : 'Safety induction selesai dicatat' })
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  const subDiscs = form?.discipline === 'CIVIL' ? CIVIL_SUBS : form?.discipline === 'MECHANICAL' ? ME_SUBS : form?.discipline === 'ELECTRICAL' ? EE_SUBS : []

  return (
    <div className="space-y-4">
      {/* Summary strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border bg-card p-4 shadow-sm"><p className="text-xs text-slate-500">Total Tenaga Kerja</p><p className="text-2xl font-bold">{employees.length}</p></div>
        <div className="rounded-xl border bg-card p-4 shadow-sm"><p className="text-xs text-slate-500">Safety Induction Selesai</p><p className="text-2xl font-bold text-emerald-600">{employees.length - noInduction}<span className="text-sm text-slate-400">/{employees.length}</span></p></div>
        <div className="rounded-xl border bg-card p-4 shadow-sm"><p className="text-xs text-slate-500">APD Lengkap</p><p className="text-2xl font-bold text-amber-600">{employees.length - apdIncomplete}<span className="text-sm text-slate-400">/{employees.length}</span></p></div>
        <div className="rounded-xl border bg-card p-4 shadow-sm"><p className="text-xs text-slate-500">ME (Mechanical)</p><p className="text-2xl font-bold text-orange-600">{employees.filter(e => e.discipline === 'MECHANICAL').length} <span className="text-xs text-slate-400 font-normal">org</span></p></div>
      </div>

      {(noInduction > 0 || apdIncomplete > 0) && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 flex items-start gap-2.5 text-sm">
          <TriangleAlert className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
          <p className="text-amber-800 text-xs sm:text-sm">
            <b>{noInduction}</b> karyawan belum safety induction, <b>{apdIncomplete}</b> karyawan APD tidak lengkap. Selesaikan onboarding sebelum ditugaskan ke area kerja (lihat panel detail karyawan).
          </p>
        </div>
      )}

      {/* Toolbar */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input placeholder="Cari nama, NIP, posisi..." value={q} onChange={e => setQ(e.target.value)} className="pl-8" />
        </div>
        <Select value={fRole} onValueChange={setFRole}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Jabatan</SelectItem>{ROLES.map(r => <SelectItem key={r} value={r}>{r} — {ROLE_LABEL[r]}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={fDisc} onValueChange={setFDisc}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Disiplin</SelectItem>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
        </Select>
        <Button onClick={() => setForm({ ...EMPTY })} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><UserPlus className="h-4 w-4" /> Tambah</Button>
      </div>

      {/* Employee grid */}
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {filtered.map(e => {
          const apd = (() => { try { return JSON.parse(e.apdItems) } catch { return {} } })()
          const manager = e.managerId ? eMap[e.managerId] : null
          return (
            <div key={e.id} className="rounded-xl border bg-card p-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3">
                <AseiAvatar name={e.name} color={e.avatarColor} className="h-11 w-11" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <p className="font-semibold text-sm truncate">{e.name}</p>
                    <Badge variant="outline" className={`text-[9px] ${roleBadge(e.role)}`}>{e.role}</Badge>
                    {e.status !== 'ACTIVE' && <Badge variant="outline" className="text-[9px] border-red-200 text-red-600">Non-aktif</Badge>}
                  </div>
                  <p className="text-xs text-slate-500 truncate">{e.position} • {DISC_LABEL[e.discipline]}{e.subDiscipline ? ` / ${e.subDiscipline}` : ''}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{e.nip} • masuk {fmtDate(e.joinDate)}{manager ? ` • atasan: ${manager.name}` : ''}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-3">
                <Badge variant="outline" className={`text-[10px] gap-1 ${e.safetyInduction ? 'border-emerald-300 text-emerald-700' : 'border-red-300 text-red-600'}`}>
                  <ShieldCheck className="h-3 w-3" /> Induction {e.safetyInduction ? `✓ ${e.inductionScore}` : '✗'}
                </Badge>
                <Badge variant="outline" className={`text-[10px] gap-1 ${e.apdStatus === 'COMPLETE' ? 'border-emerald-300 text-emerald-700' : 'border-amber-300 text-amber-700'}`}>
                  <HardHat className="h-3 w-3" /> APD {e.apdStatus === 'COMPLETE' ? 'Lengkap' : 'Kurang'}
                </Badge>
                {subs(e).length > 0 && <Badge variant="outline" className="text-[10px] gap-1 border-slate-300 text-slate-600"><Users className="h-3 w-3" /> {subs(e).length} bawahan</Badge>}
              </div>
              <div className="flex gap-1.5 mt-3">
                <Button size="sm" variant="outline" className="h-7 text-xs flex-1" onClick={() => setViewEmp(e)}>Detail</Button>
                <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setForm({ ...e, joinDate: dateInput(e.joinDate) })} aria-label="Edit"><Pencil className="h-3 w-3" /></Button>
                <Button size="sm" variant="outline" className="h-7 w-7 p-0 text-red-600 hover:text-red-700" onClick={() => remove(e)} aria-label="Hapus"><Trash2 className="h-3 w-3" /></Button>
              </div>
              <p className="text-[10px] text-slate-400 mt-2 flex gap-3">
                <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{e.phone || '-'}</span>
                <span className="flex items-center gap-1 truncate"><Mail className="h-3 w-3" />{e.email || '-'}</span>
              </p>
            </div>
          )
        })}
      </div>
      {filtered.length === 0 && <EmptyState icon={<Users className="h-10 w-10" />} title="Tidak ada karyawan cocok" sub="Ubah filter atau tambah karyawan baru" />}

      {/* ---- Detail dialog (onboarding: induction + APD + hierarchy) ---- */}
      <Dialog open={!!viewEmp} onOpenChange={o => !o && setViewEmp(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          {viewEmp && (() => {
            const apd = (() => { try { return JSON.parse(viewEmp.apdItems) } catch { return {} } })()
            const chain = (() => {
              const arr: Employee[] = []
              let cur: Employee | undefined = viewEmp
              let g = 0
              while (cur && g++ < 10) { arr.unshift(cur); cur = cur.managerId ? eMap[cur.managerId] : undefined }
              return arr
            })()
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2.5">
                    <AseiAvatar name={viewEmp.name} color={viewEmp.avatarColor} className="h-9 w-9" />
                    <span>{viewEmp.name}</span>
                    <Badge variant="outline" className={`text-[10px] ${roleBadge(viewEmp.role)}`}>{viewEmp.role}</Badge>
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4 text-sm">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="rounded-lg bg-slate-50 p-2.5"><p className="text-slate-400">NIP</p><p className="font-medium">{viewEmp.nip}</p></div>
                    <div className="rounded-lg bg-slate-50 p-2.5"><p className="text-slate-400">Posisi</p><p className="font-medium">{viewEmp.position}</p></div>
                    <div className="rounded-lg bg-slate-50 p-2.5"><p className="text-slate-400">Disiplin</p><p className="font-medium">{DISC_LABEL[viewEmp.discipline]} / {viewEmp.subDiscipline || '-'}</p></div>
                    <div className="rounded-lg bg-slate-50 p-2.5"><p className="text-slate-400">Tanggal Masuk</p><p className="font-medium">{fmtDate(viewEmp.joinDate)}</p></div>
                  </div>

                  {/* Onboarding chain */}
                  <div>
                    <p className="text-xs font-semibold text-slate-500 mb-1.5 flex items-center gap-1.5"><Network className="h-3.5 w-3.5" /> Rantai Komando</p>
                    <div className="flex flex-wrap items-center gap-1 text-[11px]">
                      {chain.map((c, i) => (
                        <span key={c.id} className="flex items-center gap-1">
                          {i > 0 && <span className="text-slate-300">→</span>}
                          <span className={`rounded-md border px-1.5 py-0.5 ${roleBadge(c.role)}`}>{c.name}</span>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Safety induction */}
                  <div className="rounded-xl border p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-lime-600" /> Safety Induction</p>
                      <Switch checked={viewEmp.safetyInduction} onCheckedChange={() => toggleInduction(viewEmp)} />
                    </div>
                    <p className="text-xs text-slate-500 mt-1.5">
                      {viewEmp.safetyInduction
                        ? `Selesai ${fmtDate(viewEmp.inductionDate)} • skor ${viewEmp.inductionScore}/100 — berhak akses area kerja.`
                        : 'BELUM mengikuti induction — tidak boleh masuk area kerja sesuai aturan K3.'}
                    </p>
                  </div>

                  {/* APD */}
                  <div className="rounded-xl border p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold flex items-center gap-1.5"><HardHat className="h-4 w-4 text-amber-600" /> Kelengkapan APD</p>
                      <Button size="sm" variant="outline" className="h-6 text-[10px]" onClick={() => {
                        let cur = {}; try { cur = JSON.parse(viewEmp.apdItems) } catch { }
                        setApdForm({ emp: viewEmp, items: { helmet: false, vest: false, gloves: false, boots: false, goggles: false, ...cur } })
                      }}>Edit Checklist</Button>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {APD_LIST.map(i => (
                        <span key={i.key} className={`text-[10px] rounded-md border px-1.5 py-0.5 ${apd[i.key] ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-red-200 bg-red-50 text-red-600'}`}>
                          {apd[i.key] ? '✓' : '✗'} {i.label}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Subordinates */}
                  <div>
                    <p className="text-xs font-semibold text-slate-500 mb-1.5">Bawahan Langsung ({subs(viewEmp).length})</p>
                    {subs(viewEmp).length === 0 ? <p className="text-xs text-slate-400">Tidak ada.</p> : (
                      <div className="flex flex-wrap gap-1.5">
                        {subs(viewEmp).map(s => (
                          <span key={s.id} className="flex items-center gap-1.5 rounded-md border bg-slate-50 px-2 py-1 text-[11px]">
                            <AseiAvatar name={s.name} color={s.avatarColor} className="h-4 w-4" /> {s.name} <span className="text-slate-400">({s.role})</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </>
            )
          })()}
        </DialogContent>
      </Dialog>

      {/* APD checklist dialog */}
      <Dialog open={!!apdForm} onOpenChange={o => !o && setApdForm(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><HardHat className="h-4 w-4 text-amber-500" /> Checklist APD — {apdForm?.emp.name}</DialogTitle></DialogHeader>
          <div className="space-y-2.5 py-1">
            {APD_LIST.map(i => (
              <div key={i.key} className="flex items-center justify-between rounded-lg border px-3 py-2">
                <span className="text-sm">{i.label}</span>
                <Switch
                  checked={!!apdForm?.items[i.key]}
                  onCheckedChange={v => setApdForm(f => f ? { ...f, items: { ...f.items, [i.key]: v } } : f)}
                />
              </div>
            ))}
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setApdForm(null)}>Batal</Button><Button onClick={saveApd} className="gap-1.5"><BadgeCheck className="h-4 w-4" /> Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Employee form dialog */}
      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Karyawan' : 'Tambah Karyawan Baru'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label>Nama Lengkap *</Label><Input value={form?.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Budi Santoso" /></div>
            <div className="space-y-1"><Label>NIP *</Label><Input value={form?.nip ?? ''} onChange={e => setForm(f => ({ ...f, nip: e.target.value }))} placeholder="cth: ASEI-035" /></div>
            <div className="space-y-1"><Label>Jabatan</Label>
              <Select value={form?.role ?? 'WORKER'} onValueChange={v => setForm(f => ({ ...f, role: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROLES.map(r => <SelectItem key={r} value={r}>{r} — {ROLE_LABEL[r]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'CIVIL'} onValueChange={v => setForm(f => ({ ...f, discipline: v, subDiscipline: '' }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {subDiscs.length > 0 && (
              <div className="space-y-1"><Label>Sub-Bagian</Label>
                <Select value={form?.subDiscipline ?? ''} onValueChange={v => setForm(f => ({ ...f, subDiscipline: v }))}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent>{subDiscs.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1"><Label>Jabatan/Posisi Detail</Label><Input value={form?.position ?? ''} onChange={e => setForm(f => ({ ...f, position: e.target.value }))} placeholder="cth: Welder 6G" /></div>
            <div className="space-y-1"><Label>Atasan Langsung</Label>
              <Select value={form?.managerId ?? ''} onValueChange={v => setForm(f => ({ ...f, managerId: v }))}>
                <SelectTrigger><SelectValue placeholder="— tanpa atasan —" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {employees.filter(x => x.id !== form?.id).map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'ACTIVE'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ACTIVE">Aktif</SelectItem><SelectItem value="LEAVE">Cuti</SelectItem><SelectItem value="INACTIVE">Non-aktif</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Telepon</Label><Input value={form?.phone ?? ''} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="08xx" /></div>
            <div className="space-y-1"><Label>Email</Label><Input value={form?.email ?? ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="nama@asei.co.id" /></div>
            <div className="space-y-1"><Label>Tanggal Masuk</Label><Input type="date" value={form?.joinDate ? String(form.joinDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, joinDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Skor Induction (jika sudah)</Label><Input type="number" value={form?.inductionScore ?? 0} onChange={e => setForm(f => ({ ...f, inductionScore: Number(e.target.value) }))} /></div>
            <div className="sm:col-span-2 space-y-1"><Label>Catatan</Label><Textarea rows={2} value={form?.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
            <div className="sm:col-span-2 flex items-center justify-between rounded-lg border px-3 py-2">
              <span className="text-sm">Sudah Safety Induction</span>
              <Switch checked={!!form?.safetyInduction} onCheckedChange={v => setForm(f => ({ ...f, safetyInduction: v }))} />
            </div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">{form?.id ? 'Simpan Perubahan' : 'Tambah'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
