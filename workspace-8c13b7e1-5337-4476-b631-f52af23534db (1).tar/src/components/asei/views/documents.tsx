'use client'
import { useState } from 'react'
import {
  FolderOpen, Plus, Pencil, Trash2, FileCheck2, ShieldAlert, BookOpen, Search,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { createRes, updateRes, deleteRes, DISCIPLINES, DISC_LABEL, DOC_TYPES, DOC_PHASE, statusBadge, fmtDate, dateInput } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { EmptyState } from '../ui-bits'
import type { ProjectDocument } from '@/lib/types'

const TYPE_ICON: Record<string, typeof FolderOpen> = {
  JSA: ShieldAlert, SOW: BookOpen, PRELIM: FileCheck2,
}

export default function DocumentsView() {
  const { documents, employees, refresh } = useAsei()
  const eMap = empMap(employees)
  const { toast } = useToast()
  const [q, setQ] = useState('')
  const [fType, setFType] = useState('ALL')
  const [detail, setDetail] = useState<ProjectDocument | null>(null)
  const [form, setForm] = useState<Partial<ProjectDocument> | null>(null)
  const [saving, setSaving] = useState(false)

  const docs = documents.filter(d => {
    const okQ = !q || d.title.toLowerCase().includes(q.toLowerCase()) || d.docNo.toLowerCase().includes(q.toLowerCase()) || d.content.toLowerCase().includes(q.toLowerCase())
    const okT = fType === 'ALL' || d.type === fType
    return okQ && okT
  })

  const save = async () => {
    if (!form?.title) return toast({ title: 'Judul dokumen wajib', variant: 'destructive' })
    setSaving(true)
    try {
      if (form.id) await updateRes('documents', form.id, form)
      else await createRes('documents', form)
      toast({ title: form.id ? 'Dokumen diperbarui' : 'Dokumen dibuat' })
      setForm(null); await refresh('documents')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (d: ProjectDocument) => {
    if (!confirm(`Hapus "${d.title}"?`)) return
    try { await deleteRes('documents', d.id); await refresh('documents'); toast({ title: 'Dokumen dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input placeholder="Cari dokumen / nomor / isi..." value={q} onChange={e => setQ(e.target.value)} className="pl-8" />
        </div>
        <Select value={fType} onValueChange={setFType}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Jenis</SelectItem>{Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
        </Select>
        <Button onClick={() => setForm({ title: '', docNo: '', type: 'JSA', discipline: 'GENERAL', phase: 'EXECUTION', content: '', version: 'A', status: 'DRAFT' })} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Buat Dokumen</Button>
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {docs.map(d => {
          const Icon = TYPE_ICON[d.type] ?? FolderOpen
          return (
            <div key={d.id} className="rounded-xl border bg-card p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <div className="flex items-start gap-3">
                <div className="rounded-lg bg-slate-900 p-2 text-amber-400 shrink-0"><Icon className="h-5 w-5" /></div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold leading-snug line-clamp-2">{d.title}</p>
                  <p className="text-[10px] font-mono text-slate-400 mt-0.5">{d.docNo} • rev {d.version}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2.5">
                <Badge variant="outline" className="text-[9px] border-amber-300 text-amber-700">{DOC_TYPES[d.type] ?? d.type}</Badge>
                <Badge variant="outline" className="text-[9px] border-slate-300 text-slate-600">{DISC_LABEL[d.discipline]}</Badge>
                <Badge variant="outline" className="text-[9px]">{DOC_PHASE[d.phase] ?? d.phase}</Badge>
                <Badge variant="outline" className={`text-[9px] ${statusBadge(d.status)}`}>{d.status}</Badge>
              </div>
              <p className="text-xs text-slate-500 line-clamp-3 mt-2 flex-1">{d.content}</p>
              <p className="text-[10px] text-slate-400 mt-2">Pembuat: {eMap[d.authorId]?.name ?? '-'} {d.approvedBy && `• Disetujui: ${d.approvedBy}`}</p>
              <div className="flex gap-1.5 mt-3">
                <Button size="sm" variant="outline" className="h-7 text-xs flex-1" onClick={() => setDetail(d)}>Baca</Button>
                <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setForm({ ...d, validFrom: dateInput(d.validFrom), validTo: dateInput(d.validTo) })} aria-label="Edit"><Pencil className="h-3 w-3" /></Button>
                <Button size="sm" variant="outline" className="h-7 w-7 p-0 text-red-600" onClick={() => remove(d)} aria-label="Hapus"><Trash2 className="h-3 w-3" /></Button>
              </div>
            </div>
          )
        })}
      </div>
      {docs.length === 0 && <EmptyState icon={<FolderOpen className="h-10 w-10" />} title="Tidak ada dokumen" sub="Buat dokumen SOW, JSA, ITP, dll" />}

      {/* Detail reader */}
      <Dialog open={!!detail} onOpenChange={o => !o && setDetail(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {detail && (
            <>
              <DialogHeader>
                <DialogTitle>{detail.title}</DialogTitle>
                <p className="text-xs text-slate-400 font-mono">{detail.docNo} • rev {detail.version} • {DOC_TYPES[detail.type]} • {DOC_PHASE[detail.phase]} • berlaku {fmtDate(detail.validFrom)} s/d {fmtDate(detail.validTo)}</p>
              </DialogHeader>
              <div className="rounded-lg bg-slate-50 border p-4 text-sm leading-relaxed whitespace-pre-wrap">{detail.content}</div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Form */}
      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Dokumen' : 'Buat Dokumen Proyek'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 space-y-1"><Label>Judul *</Label><Input value={form?.title ?? ''} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="cth: JSA - Hydrotest Piping" /></div>
            <div className="space-y-1"><Label>Nomor Dokumen</Label><Input value={form?.docNo ?? ''} onChange={e => setForm(f => ({ ...f, docNo: e.target.value }))} placeholder="ASEI-PRJ-..." /></div>
            <div className="space-y-1"><Label>Jenis</Label>
              <Select value={form?.type ?? 'JSA'} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'GENERAL'} onValueChange={v => setForm(f => ({ ...f, discipline: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Fase Proyek</Label>
              <Select value={form?.phase ?? 'EXECUTION'} onValueChange={v => setForm(f => ({ ...f, phase: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(DOC_PHASE).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'DRAFT'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{['DRAFT', 'IN_REVIEW', 'APPROVED', 'EXPIRED'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Revisi</Label><Input value={form?.version ?? 'A'} onChange={e => setForm(f => ({ ...f, version: e.target.value }))} /></div>
            <div className="sm:col-span-2 space-y-1"><Label>Isi Dokumen *</Label><Textarea rows={8} value={form?.content ?? ''} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} placeholder="Tulis langkah kerja, bahaya, kontrol risiko, hold point, dll..." /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
