'use client'
import { useState } from 'react'
import {
  Ruler, Wrench, Truck, Plus, Pencil, Trash2, PackageCheck, Ship, Factory,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { createRes, updateRes, deleteRes, DISCIPLINES, DISC_LABEL, EQ_STATUS, FAB_STATUS, statusBadge, fmtDate, dateInput, pct, scoreColor } from '@/lib/client'
import { useAsei } from '../store'
import { SimpleBar } from '../ui-bits'
import type { QuantityItem, FabricationItem, EquipmentDelivery } from '@/lib/types'

const TABS = [
  { id: 'qty', label: 'Quantity Installed', icon: Ruler },
  { id: 'fab', label: 'Fabrication', icon: Wrench },
  { id: 'eq', label: 'Equipment Delivery', icon: Truck },
] as const

export default function ProgressView() {
  const [tab, setTab] = useState<string>('qty')
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium border transition-colors ${tab === t.id ? 'bg-slate-900 text-white border-slate-900 shadow' : 'bg-white hover:bg-slate-50'}`}>
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>
      {tab === 'qty' && <QuantityTab />}
      {tab === 'fab' && <FabricationTab />}
      {tab === 'eq' && <EquipmentTab />}
    </div>
  )
}

/* ================= QUANTITY ================= */
function QuantityTab() {
  const { quantities, refresh } = useAsei()
  const { toast } = useToast()
  const [form, setForm] = useState<Partial<QuantityItem> | null>(null)
  const [saving, setSaving] = useState(false)
  const [fDisc, setFDisc] = useState('ALL')

  const items = quantities.filter(q => fDisc === 'ALL' || q.discipline === fDisc)
  const overall = items.length ? Math.round(items.reduce((s, q) => s + pct(q.installedQty, q.plannedQty), 0) / items.length) : 0

  const save = async () => {
    if (!form?.name) return toast({ title: 'Nama item wajib', variant: 'destructive' })
    setSaving(true)
    try {
      if (form.id) await updateRes('quantities', form.id, form)
      else await createRes('quantities', form)
      toast({ title: form.id ? 'Item diperbarui' : 'Item ditambahkan' })
      setForm(null); await refresh('quantities')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (q: QuantityItem) => {
    if (!confirm(`Hapus "${q.name}"?`)) return
    try { await deleteRes('quantities', q.id); await refresh('quantities'); toast({ title: 'Item dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="rounded-lg bg-orange-50 border border-orange-200 px-3 py-1.5">
            <span className="text-xs text-orange-700">Rata-rata pencapaian: <b className="text-sm">{overall}%</b></span>
          </div>
          <Select value={fDisc} onValueChange={setFDisc}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="ALL">Semua Disiplin</SelectItem>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
          </Select>
          <Button size="sm" onClick={() => setForm({ name: '', discipline: 'CIVIL', subDiscipline: '', unit: 'm3', plannedQty: 0, installedQty: 0, location: '', area: '', status: 'ON_PROGRESS' })} className="ml-auto gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tambah Item</Button>
        </div>
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-slate-50 border-b text-left text-xs text-slate-500">
              <th className="px-3 py-2 font-medium">Item Pekerjaan</th><th className="px-3 py-2 font-medium">Disiplin/Sub</th>
              <th className="px-3 py-2 font-medium">Rencana</th><th className="px-3 py-2 font-medium">Terpasang</th>
              <th className="px-3 py-2 font-medium w-36">Progress</th><th className="px-3 py-2 font-medium">Lokasi</th>
              <th className="px-3 py-2 font-medium">Status</th><th className="px-3 py-2"></th>
            </tr></thead>
            <tbody>
              {items.map(q => (
                <tr key={q.id} className="border-b last:border-0 hover:bg-slate-50/70">
                  <td className="px-3 py-2 font-medium text-xs">{q.name}</td>
                  <td className="px-3 py-2 text-xs">{DISC_LABEL[q.discipline]}<span className="text-slate-400"> / {q.subDiscipline || '-'}</span></td>
                  <td className="px-3 py-2 text-xs">{q.plannedQty} {q.unit}</td>
                  <td className="px-3 py-2 text-xs font-semibold">{q.installedQty} {q.unit}</td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <SimpleBar value={pct(q.installedQty, q.plannedQty)} color={pct(q.installedQty, q.plannedQty) >= 100 ? 'bg-emerald-500' : 'bg-orange-500'} height="h-1.5" />
                      <span className={`text-xs font-bold w-9 text-right ${scoreColor(pct(q.installedQty, q.plannedQty))}`}>{pct(q.installedQty, q.plannedQty)}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs">{q.location || '-'}</td>
                  <td className="px-3 py-2"><Badge variant="outline" className={`text-[9px] ${statusBadge(q.status)}`}>{q.status === 'ON_PROGRESS' ? 'Berjalan' : q.status === 'COMPLETED' ? 'Selesai' : q.status === 'NOT_STARTED' ? 'Belum Mulai' : q.status}</Badge></td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => setForm({ ...q, startDate: dateInput(q.startDate), endDate: dateInput(q.endDate) })} aria-label="Edit"><Pencil className="h-3 w-3" /></Button>
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0 text-red-600" onClick={() => remove(q)} aria-label="Hapus"><Trash2 className="h-3 w-3" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Quantity Item' : 'Tambah Quantity Item'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 space-y-1"><Label>Nama Item *</Label><Input value={form?.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Beton K-250 pondasi" /></div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'CIVIL'} onValueChange={v => setForm(f => ({ ...f, discipline: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Sub-Bagian</Label><Input value={form?.subDiscipline ?? ''} onChange={e => setForm(f => ({ ...f, subDiscipline: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Satuan</Label><Input value={form?.unit ?? ''} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'ON_PROGRESS'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="NOT_STARTED">Belum Mulai</SelectItem><SelectItem value="ON_PROGRESS">Berjalan</SelectItem><SelectItem value="COMPLETED">Selesai</SelectItem><SelectItem value="DELAYED">Terlambat</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Rencana (qty)</Label><Input type="number" value={form?.plannedQty ?? 0} onChange={e => setForm(f => ({ ...f, plannedQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Terpasang (qty)</Label><Input type="number" value={form?.installedQty ?? 0} onChange={e => setForm(f => ({ ...f, installedQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Lokasi</Label><Input value={form?.location ?? ''} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Area</Label><Input value={form?.area ?? ''} onChange={e => setForm(f => ({ ...f, area: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Mulai</Label><Input type="date" value={form?.startDate ? String(form.startDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Target Selesai</Label><Input type="date" value={form?.endDate ? String(form.endDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

/* ================= FABRICATION ================= */
function FabricationTab() {
  const { fabrications, refresh } = useAsei()
  const { toast } = useToast()
  const [form, setForm] = useState<Partial<FabricationItem> | null>(null)
  const [saving, setSaving] = useState(false)

  const fabPct = (f: FabricationItem) => f.totalQty ? Math.min(100, Math.round((f.weldedQty / f.totalQty) * 100)) : 0

  const save = async () => {
    if (!form?.name) return toast({ title: 'Nama item wajib', variant: 'destructive' })
    setSaving(true)
    try {
      if (form.id) await updateRes('fabrications', form.id, form)
      else await createRes('fabrications', form)
      toast({ title: form.id ? 'Item diperbarui' : 'Item ditambahkan' })
      setForm(null); await refresh('fabrications')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (f: FabricationItem) => {
    if (!confirm(`Hapus "${f.name}"?`)) return
    try { await deleteRes('fabrications', f.id); await refresh('fabrications'); toast({ title: 'Item dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center gap-2">
          <div className="rounded-lg bg-teal-50 border border-teal-200 px-3 py-1.5 text-xs text-teal-700 flex items-center gap-1.5"><Factory className="h-3.5 w-3.5" /> Pipeline: Cutting → Fit-Up → Welding → NDT → Painting → Delivery</div>
          <Button size="sm" onClick={() => setForm({ name: '', drawingNo: '', discipline: 'MECHANICAL', material: '', unit: 'pcs', totalQty: 1, cutQty: 0, fitUpQty: 0, weldedQty: 0, ndtQty: 0, paintedQty: 0, deliveredQty: 0, workshop: 'WS-1', status: 'CUTTING' })} className="ml-auto gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tambah Spool/Item</Button>
        </div>
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-slate-50 border-b text-left text-xs text-slate-500">
              <th className="px-3 py-2 font-medium">Item / Drawing</th><th className="px-3 py-2 font-medium">Material</th>
              <th className="px-3 py-2 text-center font-medium">Cut</th><th className="px-3 py-2 text-center font-medium">Fit-Up</th>
              <th className="px-3 py-2 text-center font-medium">Weld</th><th className="px-3 py-2 text-center font-medium">NDT</th>
              <th className="px-3 py-2 text-center font-medium">Paint</th><th className="px-3 py-2 text-center font-medium">Deliv</th>
              <th className="px-3 py-2 font-medium w-28">Progress</th><th className="px-3 py-2 font-medium">Status</th><th className="px-3 py-2"></th>
            </tr></thead>
            <tbody>
              {fabrications.map(f => (
                <tr key={f.id} className="border-b last:border-0 hover:bg-slate-50/70">
                  <td className="px-3 py-2">
                    <p className="font-medium text-xs">{f.name}</p>
                    <p className="text-[10px] text-slate-400">{f.drawingNo} • {f.workshop}</p>
                  </td>
                  <td className="px-3 py-2 text-xs">{f.material}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.cutQty}/{f.totalQty}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.fitUpQty}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.weldedQty}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.ndtQty}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.paintedQty}</td>
                  <td className="px-3 py-2 text-center text-xs">{f.deliveredQty}</td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <SimpleBar value={fabPct(f)} color={fabPct(f) >= 100 ? 'bg-emerald-500' : 'bg-teal-500'} height="h-1.5" />
                      <span className={`text-xs font-bold w-9 ${scoreColor(fabPct(f))}`}>{fabPct(f)}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2"><Badge variant="outline" className="text-[9px] border-slate-300 text-slate-600">{FAB_STATUS[f.status] ?? f.status}</Badge></td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => setForm({ ...f })} aria-label="Edit"><Pencil className="h-3 w-3" /></Button>
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0 text-red-600" onClick={() => remove(f)} aria-label="Hapus"><Trash2 className="h-3 w-3" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Item Fabrikasi' : 'Tambah Item Fabrikasi'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 space-y-1"><Label>Nama Item *</Label><Input value={form?.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Spool SP-A-014" /></div>
            <div className="space-y-1"><Label>Drawing No</Label><Input value={form?.drawingNo ?? ''} onChange={e => setForm(f => ({ ...f, drawingNo: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Material</Label><Input value={form?.material ?? ''} onChange={e => setForm(f => ({ ...f, material: e.target.value }))} placeholder="A106 Gr.B" /></div>
            <div className="space-y-1"><Label>Workshop</Label><Input value={form?.workshop ?? ''} onChange={e => setForm(f => ({ ...f, workshop: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'CUTTING'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(FAB_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Total Qty</Label><Input type="number" value={form?.totalQty ?? 0} onChange={e => setForm(f => ({ ...f, totalQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Cut Qty</Label><Input type="number" value={form?.cutQty ?? 0} onChange={e => setForm(f => ({ ...f, cutQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Fit-Up Qty</Label><Input type="number" value={form?.fitUpQty ?? 0} onChange={e => setForm(f => ({ ...f, fitUpQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Welded Qty</Label><Input type="number" value={form?.weldedQty ?? 0} onChange={e => setForm(f => ({ ...f, weldedQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>NDT Qty</Label><Input type="number" value={form?.ndtQty ?? 0} onChange={e => setForm(f => ({ ...f, ndtQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Painted Qty</Label><Input type="number" value={form?.paintedQty ?? 0} onChange={e => setForm(f => ({ ...f, paintedQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Delivered Qty</Label><Input type="number" value={form?.deliveredQty ?? 0} onChange={e => setForm(f => ({ ...f, deliveredQty: Number(e.target.value) }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

/* ================= EQUIPMENT DELIVERY ================= */
function EquipmentTab() {
  const { equipment, refresh } = useAsei()
  const { toast } = useToast()
  const [form, setForm] = useState<Partial<EquipmentDelivery> | null>(null)
  const [saving, setSaving] = useState(false)

  const statusIcon = (s: string) => s === 'INSTALLED' ? <PackageCheck className="h-3 w-3" /> : s === 'SHIPPED' ? <Ship className="h-3 w-3" /> : null
  const isLate = (e: EquipmentDelivery) => !e.actualDate && e.plannedDate && new Date(e.plannedDate) < new Date() && !['ARRIVED', 'INSTALLED'].includes(e.status)

  const save = async () => {
    if (!form?.equipmentName) return toast({ title: 'Nama equipment wajib', variant: 'destructive' })
    setSaving(true)
    try {
      if (form.id) await updateRes('equipment', form.id, form)
      else await createRes('equipment', form)
      toast({ title: form.id ? 'Equipment diperbarui' : 'Equipment ditambahkan' })
      setForm(null); await refresh('equipment')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }
  const remove = async (e: EquipmentDelivery) => {
    if (!confirm(`Hapus "${e.equipmentName}"?`)) return
    try { await deleteRes('equipment', e.id); await refresh('equipment'); toast({ title: 'Equipment dihapus' }) }
    catch (err) { toast({ title: 'Gagal', description: String(err), variant: 'destructive' }) }
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center gap-2">
          <div className="rounded-lg bg-violet-50 border border-violet-200 px-3 py-1.5 text-xs text-violet-700 flex items-center gap-1.5">
            <Truck className="h-3.5 w-3.5" /> {equipment.filter(e => ['ARRIVED', 'INSTALLED'].includes(e.status)).length}/{equipment.length} equipment tiba
            {equipment.filter(isLate).length > 0 && <span className="text-red-600 font-semibold"> • {equipment.filter(isLate).length} terlambat!</span>}
          </div>
          <Button size="sm" onClick={() => setForm({ equipmentName: '', tagNo: '', discipline: 'MECHANICAL', supplier: '', qty: 1, unit: 'unit', status: 'PLANNED', storageLocation: '' })} className="ml-auto gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tambah Equipment</Button>
        </div>
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-slate-50 border-b text-left text-xs text-slate-500">
              <th className="px-3 py-2 font-medium">Equipment</th><th className="px-3 py-2 font-medium">Tag</th>
              <th className="px-3 py-2 font-medium">Disiplin</th><th className="px-3 py-2 font-medium">Supplier</th>
              <th className="px-3 py-2 font-medium">Rencana Tiba</th><th className="px-3 py-2 font-medium">Aktual</th>
              <th className="px-3 py-2 font-medium">Status</th><th className="px-3 py-2 font-medium">Lokasi Simpan</th><th className="px-3 py-2"></th>
            </tr></thead>
            <tbody>
              {equipment.map(e => (
                <tr key={e.id} className={`border-b last:border-0 hover:bg-slate-50/70 ${isLate(e) ? 'bg-red-50/50' : ''}`}>
                  <td className="px-3 py-2 font-medium text-xs">{e.equipmentName}</td>
                  <td className="px-3 py-2 text-xs font-mono">{e.tagNo}</td>
                  <td className="px-3 py-2 text-xs">{DISC_LABEL[e.discipline]}</td>
                  <td className="px-3 py-2 text-xs">{e.supplier}</td>
                  <td className="px-3 py-2 text-xs">{fmtDate(e.plannedDate)}</td>
                  <td className="px-3 py-2 text-xs">{e.actualDate ? fmtDate(e.actualDate) : '—'}</td>
                  <td className="px-3 py-2">
                    <Badge variant="outline" className={`text-[9px] gap-1 ${isLate(e) ? 'border-red-300 text-red-600' : e.status === 'INSTALLED' ? 'border-emerald-300 text-emerald-700' : 'border-slate-300 text-slate-600'}`}>
                      {statusIcon(e.status)} {EQ_STATUS[e.status] ?? e.status}{isLate(e) ? ' (LATE)' : ''}
                    </Badge>
                  </td>
                  <td className="px-3 py-2 text-xs">{e.storageLocation || '—'}</td>
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => setForm({ ...e, plannedDate: dateInput(e.plannedDate), actualDate: dateInput(e.actualDate) })} aria-label="Edit"><Pencil className="h-3 w-3" /></Button>
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0 text-red-600" onClick={() => remove(e)} aria-label="Hapus"><Trash2 className="h-3 w-3" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Equipment Delivery' : 'Tambah Equipment'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 space-y-1"><Label>Nama Equipment *</Label><Input value={form?.equipmentName ?? ''} onChange={e => setForm(f => ({ ...f, equipmentName: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Tag No</Label><Input value={form?.tagNo ?? ''} onChange={e => setForm(f => ({ ...f, tagNo: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'MECHANICAL'} onValueChange={v => setForm(f => ({ ...f, discipline: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1"><Label>Supplier</Label><Input value={form?.supplier ?? ''} onChange={e => setForm(f => ({ ...f, supplier: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'PLANNED'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(EQ_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Rencana Tiba</Label><Input type="date" value={form?.plannedDate ? String(form.plannedDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, plannedDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Aktual Tiba</Label><Input type="date" value={form?.actualDate ? String(form.actualDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, actualDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Lokasi Simpan</Label><Input value={form?.storageLocation ?? ''} onChange={e => setForm(f => ({ ...f, storageLocation: e.target.value }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
