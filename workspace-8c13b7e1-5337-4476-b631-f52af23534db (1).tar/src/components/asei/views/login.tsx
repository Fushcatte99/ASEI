'use client'
import { useState } from 'react'
import { Lock, LogIn, Eye, EyeOff, ShieldCheck, Loader2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAsei } from '../store'

/** Halaman login — username & password dari administrator */
export default function LoginView() {
  const { login } = useAsei()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (busy) return
    setError('')
    if (!username.trim() || !password) {
      setError('Username dan password wajib diisi')
      return
    }
    setBusy(true)
    const res = await login(username.trim(), password)
    if (!res.ok) setError(res.error ?? 'Login gagal')
    setBusy(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center rounded-2xl bg-white p-2 shadow-xl shadow-black/30 ring-1 ring-slate-700 mb-4">
            <img src="/logo-asei.png" alt="Logo ASEI" className="h-14 w-auto object-contain" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">ASEI HR Project Management</h1>
          <p className="text-sm text-slate-400 mt-1">Software Manajemen Proyek Konstruksi Terintegrasi</p>
        </div>

        <div className="rounded-2xl bg-white shadow-2xl shadow-black/40 p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-5">
            <div className="h-9 w-9 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 leading-tight">Masuk ke Aplikasi</h2>
              <p className="text-xs text-slate-500">Gunakan akun yang diberikan administrator</p>
            </div>
          </div>

          <form onSubmit={submit} className="grid gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="login-username">Username</Label>
              <Input
                id="login-username"
                autoComplete="username"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="cth: masteradmin09"
                disabled={busy}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="login-password">Password</Label>
              <div className="relative">
                <Input
                  id="login-password"
                  type={showPw ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pr-10"
                  disabled={busy}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(v => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  aria-label={showPw ? 'Sembunyikan password' : 'Tampilkan password'}
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-orange-900/30 transition hover:opacity-95 disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
              {busy ? 'Memproses...' : 'Masuk'}
            </button>
          </form>
        </div>

        <p className="text-center text-[11px] text-slate-500 mt-5 flex items-center justify-center gap-1.5">
          <Lock className="h-3 w-3" /> Data proyek dilindungi — wajib login untuk mengakses
        </p>
      </div>
    </div>
  )
}
