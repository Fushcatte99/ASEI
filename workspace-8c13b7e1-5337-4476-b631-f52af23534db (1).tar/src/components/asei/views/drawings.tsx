'use client'
import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react'
import {
  MousePointer2, Pencil, Highlighter, Square, Circle, ArrowUpRight, Type, Upload, Download,
  Image as ImageIcon, FileText, FileBox, Loader2, Trash2, Undo2, ZoomIn, ZoomOut, Maximize2,
  MapPin, PencilLine, Plus, Save, Eraser, ChevronLeft, ChevronRight, Layers,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAsei } from '../store'
import { api, createRes, updateRes, deleteRes, listRes, activeProjectId, DISCIPLINES, DISC_LABEL, MARK_COLORS, ZONE_COLORS, ZONE_STATUS, fmtDateTime } from '@/lib/client'
import { cn } from '@/lib/utils'
import type { DrawingFileMeta, DrawingMark, DrawingZone } from '@/lib/types'

type ToolId = 'select' | 'pen' | 'highlight' | 'rect' | 'ellipse' | 'arrow' | 'text'

const TOOLS: { id: ToolId; icon: typeof Pencil; label: string }[] = [
  { id: 'select', icon: MousePointer2, label: 'Pilih / Geser' },
  { id: 'pen', icon: Pencil, label: 'Pensil bebas' },
  { id: 'highlight', icon: Highlighter, label: 'Highlighter' },
  { id: 'rect', icon: Square, label: 'Kotak marking area' },
  { id: 'ellipse', icon: Circle, label: 'Lingkaran' },
  { id: 'arrow', icon: ArrowUpRight, label: 'Panah' },
  { id: 'text', icon: Type, label: 'Teks / keterangan' },
]

const WIDTHS: { v: number; label: string }[] = [
  { v: 2, label: 'Tipis' }, { v: 3, label: 'Sedang' }, { v: 5, label: 'Tebal' }, { v: 8, label: 'Sangat Tebal' },
]

const parsePts = (s: string): number[][] => { try { const v = JSON.parse(s); return Array.isArray(v) ? v : [] } catch { return [] } }
const ftypeIcon = (t: string) => t === 'PDF' ? FileText : t === 'CAD' ? FileBox : ImageIcon

// ---------- canvas render helpers ----------
function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

function drawZoneChip(ctx: CanvasRenderingContext2D, x: number, y: number, text: string, color: string) {
  const fs = 11
  ctx.font = `600 ${fs}px ui-sans-serif, system-ui, sans-serif`
  const w = ctx.measureText(text).width + 12
  const h = fs + 7
  ctx.fillStyle = color
  roundRect(ctx, x - 1, y - h - 2, w, h, 5)
  ctx.fill()
  ctx.fillStyle = '#fff'
  ctx.textBaseline = 'top'
  ctx.fillText(text, x + 5, y - h + 2)
}

function strokePath(ctx: CanvasRenderingContext2D, p: number[][]) {
  if (p.length < 2) return
  ctx.beginPath()
  ctx.moveTo(p[0][0], p[0][1])
  for (let i = 1; i < p.length; i++) ctx.lineTo(p[i][0], p[i][1])
  ctx.stroke()
}

function drawMarkOn(ctx: CanvasRenderingContext2D, m: DrawingMark, W: number, H: number, zones: DrawingZone[], selected: boolean) {
  const pts = parsePts(m.points).map(([x, y]) => [x * W, y * H])
  if (!pts.length) return
  const sw = Math.max(1, m.strokeWidth)
  ctx.save()
  ctx.strokeStyle = m.color
  ctx.fillStyle = m.color
  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'
  if (m.type === 'pen' || m.type === 'highlight') {
    ctx.lineWidth = m.type === 'highlight' ? sw * 3.5 : sw
    if (m.type === 'highlight') ctx.globalAlpha = 0.32
    strokePath(ctx, pts)
  } else if (m.type === 'rect') {
    ctx.lineWidth = sw
    const [a, b] = [pts[0], pts[1] ?? pts[0]]
    ctx.strokeRect(a[0], a[1], b[0] - a[0], b[1] - a[1])
  } else if (m.type === 'ellipse') {
    ctx.lineWidth = sw
    const [a, b] = [pts[0], pts[1] ?? pts[0]]
    ctx.beginPath()
    ctx.ellipse((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, Math.abs(b[0] - a[0]) / 2, Math.abs(b[1] - a[1]) / 2, 0, 0, Math.PI * 2)
    ctx.stroke()
  } else if (m.type === 'arrow') {
    ctx.lineWidth = sw
    const [a, b] = [pts[0], pts[1] ?? pts[0]]
    const ang = Math.atan2(b[1] - a[1], b[0] - a[0])
    const head = Math.max(10, sw * 4)
    ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(b[0], b[1])
    ctx.lineTo(b[0] - head * Math.cos(ang - Math.PI / 6.5), b[1] - head * Math.sin(ang - Math.PI / 6.5))
    ctx.lineTo(b[0] - head * Math.cos(ang + Math.PI / 6.5), b[1] - head * Math.sin(ang + Math.PI / 6.5))
    ctx.closePath(); ctx.fill()
  } else if (m.type === 'text') {
    const fs = Math.max(13, sw + 12)
    ctx.font = `bold ${fs}px ui-sans-serif, system-ui, sans-serif`
    ctx.textBaseline = 'top'
    ctx.lineWidth = 3.5
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'
    ctx.strokeText(m.text, pts[0][0], pts[0][1])
    ctx.fillText(m.text, pts[0][0], pts[0][1])
  }
  if (m.zoneId) {
    const z = zones.find(zz => zz.id === m.zoneId)
    if (z) drawZoneChip(ctx, pts[0][0], pts[0][1], `${z.code ? z.code + ' · ' : ''}${z.name}`, z.color)
  }
  if (selected) {
    ctx.globalAlpha = 1
    ctx.setLineDash([5, 4])
    ctx.lineWidth = 1.2
    ctx.strokeStyle = '#2563eb'
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
    for (const [x, y] of pts) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y) }
    if (m.type === 'text') { const fs = Math.max(13, sw + 12); maxX = minX + ctx.measureText(m.text).width; maxY = minY + fs }
    ctx.strokeRect(minX - 6, minY - 6, maxX - minX + 12, maxY - minY + 12)
    ctx.setLineDash([])
  }
  ctx.restore()
}

function hitTest(m: DrawingMark, nx: number, ny: number, W: number, H: number, ctx: CanvasRenderingContext2D): boolean {
  const pts = parsePts(m.points).map(([x, y]) => [x * W, y * H])
  if (!pts.length) return false
  const px = nx * W, py = ny * H
  const tol = 10
  const nearSeg = (a: number[], b: number[]) => {
    const dx = b[0] - a[0], dy = b[1] - a[1]
    const len2 = dx * dx + dy * dy || 1
    const t = Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / len2))
    return Math.hypot(px - (a[0] + t * dx), py - (a[1] + t * dy)) < tol
  }
  if (m.type === 'pen' || m.type === 'highlight') {
    const lw = m.type === 'highlight' ? Math.max(1, m.strokeWidth) * 3.5 : Math.max(1, m.strokeWidth)
    return pts.some((p, i) => i > 0 && nearSeg(pts[i - 1], p)) || (pts.length === 1 && Math.hypot(px - pts[0][0], py - pts[0][1]) < lw)
  }
  if (m.type === 'arrow') return nearSeg(pts[0], pts[1] ?? pts[0])
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const [x, y] of pts) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y) }
  if (m.type === 'text') {
    const fs = Math.max(13, Math.max(1, m.strokeWidth) + 12)
    ctx.font = `bold ${fs}px ui-sans-serif, system-ui, sans-serif`
    maxX = minX + ctx.measureText(m.text).width
    maxY = minY + fs
  }
  return px >= minX - tol && px <= maxX + tol && py >= minY - tol && py <= maxY + tol
}

async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(String(r.result))
    r.onerror = () => rej(new Error('Gagal membaca file'))
    r.readAsDataURL(file)
  })
}

async function maybeCompress(file: File, dataUrl: string): Promise<{ dataUrl: string; note: string }> {
  if (!file.type.startsWith('image/') || dataUrl.length < 5_500_000) return { dataUrl, note: '' }
  const img = new Image()
  await new Promise<void>((res, rej) => { img.onload = () => res(); img.onerror = () => rej(new Error('Gambar rusak')); img.src = dataUrl })
  const max = 2400
  const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight))
  if (scale >= 1) return { dataUrl, note: '' }
  const c = document.createElement('canvas')
  c.width = Math.round(img.naturalWidth * scale)
  c.height = Math.round(img.naturalHeight * scale)
  c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height)
  return { dataUrl: c.toDataURL('image/jpeg', 0.85), note: 'Gambar besar dikompresi otomatis (JPEG)' }
}

export default function DrawingsView() {
  const { zones, refresh, activeProjectId: storePid } = useAsei()
  const [drawings, setDrawings] = useState<DrawingFileMeta[]>([])
  const [loadingD, setLoadingD] = useState(true)
  const [sel, setSel] = useState<DrawingFileMeta | null>(null)
  const [marks, setMarks] = useState<DrawingMark[]>([])
  const [tool, setTool] = useState<ToolId>('pen')
  const [color, setColor] = useState(MARK_COLORS[0])
  const [strokeW, setStrokeW] = useState(3)
  const [zoneLink, setZoneLink] = useState('')
  const [zoom, setZoom] = useState(1)
  const [baseSrc, setBaseSrc] = useState<HTMLImageElement | HTMLCanvasElement | null>(null)
  const [nat, setNat] = useState({ w: 0, h: 0 })
  const [pageNo, setPageNo] = useState(1)
  const [numPages, setNumPages] = useState(0)
  const [selId, setSelId] = useState<string | null>(null)
  const [savedAt, setSavedAt] = useState<number | null>(null)
  const [, forceRedraw] = useReducer((x: number) => x + 1, 0)

  // dialogs
  const [upOpen, setUpOpen] = useState(false)
  const [upMeta, setUpMeta] = useState({ title: '', drawingNo: '', discipline: 'GENERAL', notes: '' })
  const [upFile, setUpFile] = useState<File | null>(null)
  const [upBusy, setUpBusy] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [editForm, setEditForm] = useState({ title: '', drawingNo: '', discipline: 'GENERAL', notes: '' })
  const [zoneOpen, setZoneOpen] = useState(false)
  const [zoneEditId, setZoneEditId] = useState<string | null>(null)
  const [zoneForm, setZoneForm] = useState({ name: '', code: '', discipline: 'CIVIL', status: 'PLANNED', color: ZONE_COLORS[0], description: '' })
  const [confirm, setConfirm] = useState<{ title: string; desc: string; action: () => void } | null>(null)
  const [textDraft, setTextDraft] = useState<{ nx: number; ny: number; value: string } | null>(null)
  const textDraftRef = useRef<{ nx: number; ny: number; value: string } | null>(null)

  useEffect(() => { textDraftRef.current = textDraft }, [textDraft])

  const containerRef = useRef<HTMLDivElement>(null)
  const baseRef = useRef<HTMLCanvasElement>(null)
  const ovRef = useRef<HTMLCanvasElement>(null)
  const imgRef = useRef<HTMLImageElement>(null)
  const pdfDocRef = useRef<{ numPages: number; getPage: (n: number) => Promise<unknown> } | null>(null)
  const tempRef = useRef<DrawingMark | null>(null)
  const dragRef = useRef<{ id: string; startNx: number; startNy: number; orig: number[][]; offX: number; offY: number } | null>(null)
  const [contW, setContW] = useState(900)

  const fileUrl = sel ? `/api/drawings/${sel.id}/file` : ''
  const dispW = Math.max(200, Math.floor(contW * zoom))
  const dispH = nat.w > 0 ? Math.floor(dispW * nat.h / nat.w) : 0

  const loadDrawings = useCallback(async () => {
    setLoadingD(true)
    try {
      const data = await api<{ data: DrawingFileMeta[] }>(`/api/drawings?projectId=${activeProjectId()}`).then(j => j.data)
      setDrawings(data)
      setSel(cur => (cur && data.some(d => d.id === cur.id) ? data.find(d => d.id === cur.id)! : null))
    } catch { setDrawings([]) }
    finally { setLoadingD(false) }
  }, [])

  useEffect(() => { loadDrawings() }, [loadDrawings, storePid])

  useEffect(() => { // ganti proyek: reset
    setSel(null); setMarks([]); setBaseSrc(null); setNat({ w: 0, h: 0 }); setPageNo(1); setNumPages(0)
  }, [activeProjectId])

  const fetchMarks = useCallback(async (drawingId: string) => {
    try { setMarks(await listRes<DrawingMark[]>('marks', `drawingId=${drawingId}`)) }
    catch { setMarks([]) }
  }, [])

  useEffect(() => { if (sel) { fetchMarks(sel.id); setSelId(null) } }, [sel, fetchMarks])

  // container width observer
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const ro = new ResizeObserver(entries => {
      const w = entries[0]?.contentRect.width
      if (w) setContW(Math.max(200, w))
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [sel])

  // gambar dasar untuk IMAGE
  useEffect(() => {
    if (!sel || sel.fileType !== 'IMAGE') return
    setBaseSrc(null); setNat({ w: 0, h: 0 })
    const img = imgRef.current
    if (!img) return
    img.src = fileUrl
    img.onload = () => { setBaseSrc(img); setNat({ w: img.naturalWidth, h: img.naturalHeight }) }
  }, [sel, fileUrl])

  // render PDF page via pdfjs
  useEffect(() => {
    let cancelled = false
    async function renderPdf() {
      if (!sel || sel.fileType !== 'PDF') return
      setBaseSrc(null); setNumPages(0)
      try {
        const pdfjs = await import('pdfjs-dist')
        pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs'
        if (!pdfDocRef.current) {
          const doc = await pdfjs.getDocument({ url: fileUrl }).promise
          pdfDocRef.current = doc as unknown as typeof pdfDocRef.current
        }
        const doc = pdfDocRef.current
        if (!doc || cancelled) return
        setNumPages(doc.numPages)
        const page = (await doc.getPage(Math.min(pageNo, doc.numPages))) as { getViewport: (o: { scale: number }) => { width: number; height: number }; render: (o: Record<string, unknown>) => { promise: Promise<void> } }
        const vp1 = page.getViewport({ scale: 1 })
        const scale = Math.min(2000 / vp1.width, 2.2)
        const vp = page.getViewport({ scale })
        const c = document.createElement('canvas')
        c.width = Math.floor(vp.width); c.height = Math.floor(vp.height)
        await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise
        if (cancelled) return
        setNat({ w: vp1.width, h: vp1.height })
        setBaseSrc(c)
      } catch { if (!cancelled) { setBaseSrc(null); setNumPages(0) } }
    }
    renderPdf()
    return () => { cancelled = true }
  }, [sel, fileUrl, pageNo])

  useEffect(() => { if (sel && sel.fileType !== 'PDF') pdfDocRef.current = null }, [sel])

  // gambar base canvas
  useEffect(() => {
    const c = baseRef.current
    if (!c || !baseSrc || dispW < 1 || dispH < 1) return
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    c.width = Math.floor(dispW * dpr); c.height = Math.floor(dispH * dpr)
    const ctx = c.getContext('2d')!
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, dispW, dispH)
    ctx.drawImage(baseSrc, 0, 0, dispW, dispH)
  }, [baseSrc, dispW, dispH])

  // gambar overlay (marks)
  const redraw = useCallback(() => {
    const c = ovRef.current
    if (!c || dispW < 1 || dispH < 1) return
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    c.width = Math.floor(dispW * dpr); c.height = Math.floor(dispH * dpr)
    const ctx = c.getContext('2d')!
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, dispW, dispH)
    for (const m of marks) if (m.id !== dragRef.current?.id) drawMarkOn(ctx, m, dispW, dispH, zones, m.id === selId)
    if (tempRef.current) drawMarkOn(ctx, tempRef.current, dispW, dispH, zones, false)
    if (dragRef.current) {
      const cur = marks.find(m => m.id === dragRef.current!.id)
      if (cur) {
        const moved: DrawingMark = { ...cur, points: JSON.stringify(dragRef.current.orig.map(([x, y]) => [x + dragRef.current!.offX, y + dragRef.current!.offY])) }
        drawMarkOn(ctx, moved, dispW, dispH, zones, true)
      }
    }
  }, [marks, zones, selId, dispW, dispH])

  useEffect(() => { redraw() }, [redraw])

  const toNx = (e: React.PointerEvent): [number, number] => {
    const r = ovRef.current!.getBoundingClientRect()
    return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]
  }

  const commitMark = async (m: { drawingId: string; type: string; color: string; strokeWidth: number; points: string; text: string; zoneId: string }) => {
    const tmpId = `tmp-${Date.now()}`
    const optimistic: DrawingMark = { ...(m as Omit<DrawingMark, 'id' | 'projectId' | 'author' | 'createdAt' | 'updatedAt'>), id: tmpId, projectId: activeProjectId(), author: '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
    setMarks(prev => [...prev, optimistic])
    try {
      const saved = await createRes('marks', { ...m, drawingId: sel?.id ?? '' })
      setMarks(prev => prev.map(x => (x.id === tmpId ? ((saved as { data: DrawingMark }).data ?? x) : x)))
      setSavedAt(Date.now())
    } catch {
      setMarks(prev => prev.filter(x => x.id !== tmpId))
    }
  }

  const onPointerDown = (e: React.PointerEvent) => {
    if (!sel || textDraft) return
    const [nx, ny] = toNx(e)
    if (tool === 'select') {
      const ctx = ovRef.current!.getContext('2d')!
      for (let i = marks.length - 1; i >= 0; i--) {
        if (hitTest(marks[i], nx, ny, dispW, dispH, ctx)) {
          setSelId(marks[i].id)
          dragRef.current = { id: marks[i].id, startNx: nx, startNy: ny, orig: parsePts(marks[i].points), offX: 0, offY: 0 }
          ovRef.current!.setPointerCapture(e.pointerId)
          forceRedraw()
          return
        }
      }
      setSelId(null)
      return
    }
    if (tool === 'text') { setTextDraft({ nx, ny, value: '' }); return }
    tempRef.current = {
      id: `tmp-${Date.now()}`, projectId: activeProjectId(), drawingId: sel.id, type: tool, color,
      strokeWidth: strokeW, text: '', zoneId: zoneLink, author: '', createdAt: '', updatedAt: '',
      points: tool === 'pen' || tool === 'highlight' ? JSON.stringify([[nx, ny]]) : JSON.stringify([[nx, ny], [nx, ny]]),
    }
    ovRef.current!.setPointerCapture(e.pointerId)
    forceRedraw()
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (!sel) return
    const [nx, ny] = toNx(e)
    if (dragRef.current) {
      dragRef.current.offX = nx - dragRef.current.startNx
      dragRef.current.offY = ny - dragRef.current.startNy
      forceRedraw()
      return
    }
    const t = tempRef.current
    if (!t) return
    const pts = parsePts(t.points)
    if (t.type === 'pen' || t.type === 'highlight') {
      const last = pts[pts.length - 1]
      if (Math.hypot((nx - last[0]) * dispW, (ny - last[1]) * dispH) > 2) pts.push([nx, ny])
      t.points = JSON.stringify(pts)
    } else {
      t.points = JSON.stringify([pts[0], [nx, ny]])
    }
    forceRedraw()
  }

  const onPointerUp = async () => {
    if (dragRef.current) {
      const d = dragRef.current
      dragRef.current = null
      if (Math.abs(d.offX) > 0.0001 || Math.abs(d.offY) > 0.0001) {
        const moved = d.orig.map(([x, y]) => [x + d.offX, y + d.offY])
        setMarks(prev => prev.map(m => (m.id === d.id ? { ...m, points: JSON.stringify(moved) } : m)))
        try { await updateRes('marks', d.id, { points: JSON.stringify(moved) }); setSavedAt(Date.now()) } catch { /* keep */ }
      }
      forceRedraw()
      return
    }
    const t = tempRef.current
    if (!t) return
    tempRef.current = null
    const pts = parsePts(t.points)
    if (t.type === 'pen' || t.type === 'highlight') {
      if (pts.length < 2) { forceRedraw(); return }
    } else {
      const dist = Math.hypot((pts[1][0] - pts[0][0]) * dispW, (pts[1][1] - pts[0][1]) * dispH)
      if (dist < 6) { forceRedraw(); return }
    }
    await commitMark(t)
    forceRedraw()
  }

  const commitText = async () => {
    if (!textDraft || !sel) return
    const v = textDraft.value.trim()
    if (v) {
      await commitMark({
        drawingId: sel.id, type: 'text', color, strokeWidth: strokeW, text: v, zoneId: zoneLink,
        points: JSON.stringify([[textDraft.nx, textDraft.ny]]),
      })
    }
    setTextDraft(null)
  }

  const undoLast = async () => {
    if (!marks.length) return
    const last = [...marks].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))[0]
    setMarks(prev => prev.filter(m => m.id !== last.id))
    if (selId === last.id) setSelId(null)
    try { await deleteRes('marks', last.id); setSavedAt(Date.now()) } catch { /* keep */ }
  }

  const deleteSelected = async () => {
    if (!selId) return
    setMarks(prev => prev.filter(m => m.id !== selId))
    setSelId(null)
    try { await deleteRes('marks', selId); setSavedAt(Date.now()) } catch { /* keep */ }
  }

  const clearAll = () => {
    if (!marks.length || !sel) return
    setConfirm({
      title: 'Hapus semua marking?',
      desc: `Semua ${marks.length} anotasi pada gambar "${sel.title}" akan dihapus permanen.`,
      action: async () => {
        const ids = marks.map(m => m.id)
        setMarks([]); setSelId(null)
        await Promise.all(ids.filter(id => !id.startsWith('tmp-')).map(id => deleteRes('marks', id).catch(() => {})))
        setSavedAt(Date.now())
      },
    })
  }

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (document.activeElement?.tagName ?? '').toLowerCase()
      if (tag === 'input' || tag === 'textarea') return
      if ((e.key === 'Delete' || e.key === 'Backspace') && selId) { e.preventDefault(); deleteSelected() }
      if (e.key === 'Escape') setSelId(null)
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  // ============ Upload ============
  const pickFile = (f: File | null) => {
    if (!f) return
    setUpFile(f)
    setUpMeta(m => ({ ...m, title: f.name.replace(/\.[^.]+$/, '') }))
  }

  const doUpload = async () => {
    if (!upFile) return
    setUpBusy(true)
    try {
      let dataUrl = await fileToDataUrl(upFile)
      const comp = await maybeCompress(upFile, dataUrl)
      dataUrl = comp.dataUrl
      if (dataUrl.length > 13_000_000) throw new Error('Ukuran file maksimal 10 MB')
      const saved = await api<{ data: DrawingFileMeta }>('/api/drawings', {
        method: 'POST',
        body: JSON.stringify({
          projectId: activeProjectId(), fileName: upFile.name, dataUrl,
          title: upMeta.title, drawingNo: upMeta.drawingNo, discipline: upMeta.discipline, notes: upMeta.notes,
        }),
      })
      await loadDrawings()
      setSel(saved.data)
      setUpOpen(false); setUpFile(null)
      setUpMeta({ title: '', drawingNo: '', discipline: 'GENERAL', notes: '' })
      setZoom(1); setPageNo(1)
    } catch (e) {
      setConfirm({ title: 'Upload gagal', desc: String(e instanceof Error ? e.message : e), action: () => {} })
    } finally { setUpBusy(false) }
  }

  // ============ Zona & gambar CRUD ============
  const openZoneNew = () => { setZoneEditId(null); setZoneForm({ name: '', code: '', discipline: 'CIVIL', status: 'PLANNED', color: ZONE_COLORS[0], description: '' }); setZoneOpen(true) }
  const openZoneEdit = (z: DrawingZone) => { setZoneEditId(z.id); setZoneForm({ name: z.name, code: z.code, discipline: z.discipline, status: z.status, color: z.color, description: z.description }); setZoneOpen(true) }
  const submitZone = async () => {
    if (!zoneForm.name.trim()) return
    if (zoneEditId) await updateRes('zones', zoneEditId, zoneForm)
    else await createRes('zones', zoneForm)
    await refresh('zones')
    setZoneOpen(false)
  }

  const sortedMarks = useMemo(() => [...marks].sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1)), [marks])
  const markZoneName = (m: DrawingMark) => zones.find(z => z.id === m.zoneId)?.name ?? ''

  const canDraw = !!sel && sel.fileType !== 'CAD'
  const SelIcon = sel ? ftypeIcon(sel.fileType) : null

  return (
    <div className="grid gap-4 xl:grid-cols-[300px_minmax(0,1fr)]">
      {/* ============ PANEL KIRI ============ */}
      <div>
        <Tabs defaultValue="drawings">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="drawings" className="gap-1.5 text-xs"><ImageIcon className="h-3.5 w-3.5" /> Gambar</TabsTrigger>
            <TabsTrigger value="zones" className="gap-1.5 text-xs"><MapPin className="h-3.5 w-3.5" /> Zona &amp; Area</TabsTrigger>
          </TabsList>

          <TabsContent value="drawings" className="mt-3 space-y-2">
            <Button onClick={() => setUpOpen(true)} className="w-full gap-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-600 hover:to-orange-700">
              <Upload className="h-4 w-4" /> Upload Gambar (CAD/PDF/PNG)
            </Button>
            <p className="text-[10px] text-slate-500 px-1">Format: PNG, JPG, WebP, PDF, DXF/DWG • maks 10 MB</p>
            {loadingD && <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>}
            {!loadingD && drawings.length === 0 && (
              <div className="rounded-lg border border-dashed p-4 text-center text-xs text-slate-500">
                Belum ada gambar proyek. Upload gambar site plan, isometric, layout, atau CAD untuk mulai marking.
              </div>
            )}
            {drawings.map(d => {
              const Icon = ftypeIcon(d.fileType)
              return (
                <div key={d.id} className={cn('group flex items-start gap-2 rounded-lg border p-2.5 cursor-pointer transition-colors', sel?.id === d.id ? 'border-amber-400 bg-amber-50' : 'bg-white hover:bg-slate-50')}
                  onClick={() => { setSel(d); setZoom(1); setPageNo(1); pdfDocRef.current = null }}>
                  <Icon className={cn('mt-0.5 h-4 w-4 shrink-0', d.fileType === 'CAD' ? 'text-slate-500' : 'text-amber-600')} />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold truncate">{d.title}</p>
                    <p className="text-[10px] text-slate-500 truncate">
                      {d.drawingNo ? d.drawingNo + ' • ' : ''}{d.fileType} • {d.sizeKb} KB
                    </p>
                    <p className="text-[10px] text-slate-400">{DISC_LABEL[d.discipline] ?? d.discipline} • {fmtDateTime(d.createdAt)}</p>
                  </div>
                  <div className="flex flex-col gap-1 opacity-60 group-hover:opacity-100">
                    <button aria-label="Edit gambar" className="rounded p-1 hover:bg-slate-200" onClick={(e) => { e.stopPropagation(); setSel(d); setEditForm({ title: d.title, drawingNo: d.drawingNo, discipline: d.discipline, notes: d.notes }); setEditOpen(true) }}>
                      <PencilLine className="h-3 w-3 text-slate-600" />
                    </button>
                    <button aria-label="Hapus gambar" className="rounded p-1 hover:bg-red-100" onClick={(e) => {
                      e.stopPropagation()
                      setConfirm({ title: `Hapus gambar "${d.title}"?`, desc: 'Gambar dan seluruh marking di atasnya akan dihapus permanen.', action: async () => { await api(`/api/drawings/${d.id}`, { method: 'DELETE' }); await loadDrawings() } })
                    }}>
                      <Trash2 className="h-3 w-3 text-red-500" />
                    </button>
                  </div>
                </div>
              )
            })}
          </TabsContent>

          <TabsContent value="zones" className="mt-3 space-y-2">
            <Button onClick={openZoneNew} variant="outline" className="w-full gap-2 border-amber-300 text-amber-700 hover:bg-amber-50">
              <Plus className="h-4 w-4" /> Tambah Zona Pekerjaan
            </Button>
            {zones.length === 0 && (
              <div className="rounded-lg border border-dashed p-4 text-center text-xs text-slate-500">
                Belum ada zona. Tambahkan zona pekerjaan/area (cth: Area A - Ponds, Rack Listrik) lalu tandai di gambar.
              </div>
            )}
            {zones.map(z => (
              <div key={z.id} className="group flex items-start gap-2 rounded-lg border bg-white p-2.5">
                <span className="mt-1 h-3 w-3 shrink-0 rounded-full border border-white shadow" style={{ background: z.color }} />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold truncate">{z.name}</p>
                  <p className="text-[10px] text-slate-500 truncate">{z.code ? z.code + ' • ' : ''}{DISC_LABEL[z.discipline] ?? z.discipline}</p>
                  <span className="mt-1 inline-block rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[9px] font-semibold text-slate-600">{ZONE_STATUS[z.status] ?? z.status}</span>
                  {z.description && <p className="mt-1 text-[10px] leading-snug text-slate-400 line-clamp-2">{z.description}</p>}
                </div>
                <div className="flex flex-col gap-1 opacity-60 group-hover:opacity-100">
                  <button aria-label="Edit zona" className="rounded p-1 hover:bg-slate-200" onClick={() => openZoneEdit(z)}><PencilLine className="h-3 w-3 text-slate-600" /></button>
                  <button aria-label="Hapus zona" className="rounded p-1 hover:bg-red-100" onClick={() => setConfirm({ title: `Hapus zona "${z.name}"?`, desc: 'Zona dihapus dari daftar. Marking yang terhubung tetap ada tanpa label zona.', action: async () => { await deleteRes('zones', z.id); await refresh('zones') } })}>
                    <Trash2 className="h-3 w-3 text-red-500" />
                  </button>
                </div>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </div>

      {/* ============ AREA VIEWER ============ */}
      <div className="min-w-0 space-y-3">
        {!sel ? (
          <div className="flex h-[420px] flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed bg-white/60 text-center">
            <div className="rounded-2xl bg-gradient-to-br from-amber-100 to-orange-100 p-4"><Upload className="h-8 w-8 text-amber-600" /></div>
            <div>
              <p className="font-semibold text-slate-700">{drawings.length === 0 ? 'Belum ada gambar proyek' : 'Pilih gambar dari daftar di kiri'}</p>
              <p className="mt-1 text-xs text-slate-500 max-w-sm">Upload site plan, P&amp;ID, isometric, shop drawing (PDF/PNG) atau arsip CAD, lalu tandai zona &amp; beri keterangan di gambar.</p>
            </div>
            <Button onClick={() => setUpOpen(true)} className="gap-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Upload className="h-4 w-4" /> Upload Sekarang</Button>
          </div>
        ) : (
          <>
            {/* Toolbar */}
            <div className="rounded-xl border bg-white p-2 space-y-2">
              <div className="flex flex-wrap items-center gap-1.5">
                {TOOLS.map(t => (
                  <Button key={t.id} variant={tool === t.id ? 'default' : 'outline'} size="sm"
                    disabled={!canDraw && t.id !== 'select'}
                    title={t.label}
                    onClick={() => { setTool(t.id); setSelId(null) }}
                    className={cn('h-8 w-8 p-0', tool === t.id && 'bg-gradient-to-r from-amber-500 to-orange-600 text-white')}>
                    <t.icon className="h-4 w-4" />
                  </Button>
                ))}
                <span className="mx-1 h-6 w-px bg-slate-200" />
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" title="Perkecil" onClick={() => setZoom(z => Math.max(0.5, Math.round((z - 0.25) * 100) / 100))} disabled={!baseSrc}><ZoomOut className="h-4 w-4" /></Button>
                  <span className="w-12 text-center text-xs font-semibold text-slate-600">{Math.round(zoom * 100)}%</span>
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" title="Perbesar" onClick={() => setZoom(z => Math.min(4, Math.round((z + 0.25) * 100) / 100))} disabled={!baseSrc}><ZoomIn className="h-4 w-4" /></Button>
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" title="Fit lebar" onClick={() => setZoom(1)} disabled={!baseSrc}><Maximize2 className="h-4 w-4" /></Button>
                </div>
                {numPages > 1 && (
                  <div className="ml-2 flex items-center gap-1 rounded-lg border px-1.5 py-0.5">
                    <button aria-label="Halaman sebelumnya" disabled={pageNo <= 1} onClick={() => setPageNo(p => p - 1)} className="rounded p-1 hover:bg-slate-100 disabled:opacity-30"><ChevronLeft className="h-3.5 w-3.5" /></button>
                    <span className="text-[11px] font-medium text-slate-600">Hal {pageNo}/{numPages}</span>
                    <button aria-label="Halaman berikutnya" disabled={pageNo >= numPages} onClick={() => setPageNo(p => p + 1)} className="rounded p-1 hover:bg-slate-100 disabled:opacity-30"><ChevronRight className="h-3.5 w-3.5" /></button>
                  </div>
                )}
                <span className="ml-auto flex items-center gap-1 text-[10px] font-medium text-emerald-600"><Save className="h-3 w-3" /> {savedAt ? `Tersimpan ${new Date(savedAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}` : 'Simpan otomatis'}</span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 border-t pt-2">
                <span className="text-[10px] font-semibold uppercase text-slate-400 mr-1">Warna</span>
                {MARK_COLORS.map(c => (
                  <button key={c} aria-label={`Warna ${c}`} onClick={() => setColor(c)}
                    className={cn('h-5 w-5 rounded-full border-2 transition-transform', color === c ? 'scale-110 border-slate-700' : 'border-transparent ring-1 ring-slate-200')}
                    style={{ background: c }} />
                ))}
                <span className="mx-1 h-5 w-px bg-slate-200" />
                <Select value={String(strokeW)} onValueChange={v => setStrokeW(Number(v))}>
                  <SelectTrigger className="h-7 w-[110px] text-[11px]"><SelectValue /></SelectTrigger>
                  <SelectContent>{WIDTHS.map(w => <SelectItem key={w.v} value={String(w.v)}>{w.label}</SelectItem>)}</SelectContent>
                </Select>
                <span className="mx-1 h-5 w-px bg-slate-200" />
                <span className="text-[10px] font-semibold uppercase text-slate-400">Zona</span>
                <Select value={zoneLink || '__none'} onValueChange={v => setZoneLink(v === '__none' ? '' : v)}>
                  <SelectTrigger className="h-7 w-[170px] text-[11px]"><SelectValue placeholder="Tanpa zona" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">— Tanpa zona —</SelectItem>
                    {zones.map(z => <SelectItem key={z.id} value={z.id}>{z.code ? z.code + ' · ' : ''}{z.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <span className="mx-1 h-5 w-px bg-slate-200" />
                <Button variant="outline" size="sm" className="h-7 gap-1 px-2 text-[11px]" onClick={undoLast} disabled={!marks.length}><Undo2 className="h-3 w-3" /> Undo</Button>
                <Button variant="outline" size="sm" className="h-7 gap-1 px-2 text-[11px]" onClick={deleteSelected} disabled={!selId}><Trash2 className="h-3 w-3" /> Hapus Pilihan</Button>
                <Button variant="outline" size="sm" className="h-7 gap-1 px-2 text-[11px] text-red-600 hover:bg-red-50" onClick={clearAll} disabled={!marks.length}><Eraser className="h-3 w-3" /> Bersihkan</Button>
                <span className="ml-auto text-[10px] text-slate-400">{marks.length} marking</span>
              </div>
            </div>

            {/* Canvas / viewer */}
            {sel.fileType === 'CAD' ? (
              <div className="flex h-[420px] flex-col items-center justify-center gap-3 rounded-xl border bg-slate-50 text-center">
                <div className="rounded-2xl bg-slate-200 p-4"><FileBox className="h-8 w-8 text-slate-600" /></div>
                <div>
                  <p className="font-semibold text-slate-700">{sel.fileName}</p>
                  <p className="mt-1 text-xs text-slate-500 max-w-md">File CAD ({sel.fileType}) tersimpan sebagai arsip proyek dan bisa diunduh. Browser tidak bisa merender DXF/DWG — upload versi PNG/PDF dari gambar yang sama untuk marking &amp; anotasi.</p>
                </div>
                <a href={fileUrl} download={sel.fileName}><Button className="gap-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Download className="h-4 w-4" /> Unduh File CAD</Button></a>
              </div>
            ) : (
              <div ref={containerRef} className="relative overflow-auto rounded-xl border bg-slate-200/70" style={{ height: 'min(68vh, 640px)' }}>
                {!baseSrc && (
                  <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/70">
                    <div className="flex items-center gap-2 text-sm text-slate-500"><Loader2 className="h-4 w-4 animate-spin" /> Merender gambar...</div>
                  </div>
                )}
                <div className="relative m-0" style={{ width: dispW, height: dispH }}>
                  <canvas ref={baseRef} className="absolute inset-0" style={{ width: dispW, height: dispH }} />
                  <canvas
                    ref={ovRef}
                    className="absolute inset-0 touch-none"
                    style={{ width: dispW, height: dispH, cursor: !canDraw ? 'default' : tool === 'select' ? 'default' : 'crosshair' }}
                    onPointerDown={onPointerDown}
                    onPointerMove={onPointerMove}
                    onPointerUp={onPointerUp}
                    onPointerLeave={onPointerUp}
                  />
                  {textDraft && (
                    <div className="absolute z-20" style={{ left: textDraft.nx * dispW, top: textDraft.ny * dispH }}>
                      <Input
                        autoFocus
                        value={textDraft.value}
                        onChange={e => setTextDraft(d => (d ? { ...d, value: e.target.value } : d))}
                        onKeyDown={e => { if (e.key === 'Enter') commitText(); if (e.key === 'Escape') { textDraftRef.current = null; setTextDraft(null) } }}
                        onBlur={commitText}
                        placeholder="Ketik keterangan lalu Enter…"
                        className="h-8 w-48 text-xs shadow-lg"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Info + aksi file */}
            <div className="flex flex-wrap items-center gap-2 rounded-xl border bg-white px-3 py-2">
              {SelIcon && <SelIcon className="h-4 w-4 text-amber-600" />}
              <div className="min-w-0">
                <p className="text-xs font-bold truncate">{sel.title}</p>
                <p className="text-[10px] text-slate-500">{sel.fileName} • {sel.fileType} • {sel.sizeKb} KB{sel.drawingNo ? ` • No. ${sel.drawingNo}` : ''}</p>
              </div>
              {sel.notes && <p className="hidden md:block text-[10px] text-slate-400 truncate max-w-xs">{sel.notes}</p>}
              <div className="ml-auto flex gap-2">
                <a href={fileUrl} download={sel.fileName}><Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs"><Download className="h-3.5 w-3.5" /> Unduh</Button></a>
                <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs" onClick={() => { setEditForm({ title: sel.title, drawingNo: sel.drawingNo, discipline: sel.discipline, notes: sel.notes }); setEditOpen(true) }}><PencilLine className="h-3.5 w-3.5" /> Edit Info</Button>
              </div>
            </div>

            {/* Daftar marking */}
            {marks.length > 0 && (
              <div className="rounded-xl border bg-white p-3">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-bold text-slate-600"><Layers className="h-3.5 w-3.5" /> Daftar Marking ({marks.length})</p>
                <div className="max-h-40 space-y-1.5 overflow-y-auto pr-1">
                  {sortedMarks.map((m, i) => (
                    <div key={m.id} className={cn('flex items-center gap-2 rounded-lg border px-2 py-1.5 text-[11px] cursor-pointer', selId === m.id ? 'border-blue-400 bg-blue-50' : 'bg-white hover:bg-slate-50')}
                      onClick={() => { setTool('select'); setSelId(m.id) }}>
                      <span className="w-5 text-center font-bold text-slate-400">{i + 1}</span>
                      <span className="h-3 w-3 rounded-full shrink-0" style={{ background: m.color }} />
                      <span className="font-medium capitalize w-20 shrink-0">{m.type === 'highlight' ? 'highlight' : m.type}</span>
                      <span className="truncate text-slate-500 flex-1">{m.text || (markZoneName(m) ? `Zona: ${markZoneName(m)}` : '—')}</span>
                      <button aria-label="Hapus marking" className="rounded p-1 hover:bg-red-100" onClick={e => { e.stopPropagation(); if (!m.id.startsWith('tmp-')) { setMarks(prev => prev.filter(x => x.id !== m.id)); if (selId === m.id) setSelId(null); deleteRes('marks', m.id) } }}>
                        <Trash2 className="h-3 w-3 text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* img tersembunyi untuk memuat gambar */}
      <img ref={imgRef} alt="" className="hidden" />

      {/* ============ DIALOG UPLOAD ============ */}
      <Dialog open={upOpen} onOpenChange={setUpOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle>Upload Gambar Proyek</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <label
              className={cn('flex cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed p-5 text-center transition-colors', upFile ? 'border-emerald-400 bg-emerald-50' : 'border-slate-300 bg-slate-50 hover:border-amber-400 hover:bg-amber-50')}
              onDragOver={e => e.preventDefault()}
              onDrop={e => { e.preventDefault(); pickFile(e.dataTransfer.files?.[0] ?? null) }}
            >
              <input type="file" className="sr-only" accept=".png,.jpg,.jpeg,.webp,.pdf,.dxf,.dwg" onChange={e => pickFile(e.target.files?.[0] ?? null)} />
              <Upload className="h-6 w-6 text-amber-600" />
              <span className="text-xs font-semibold">{upFile ? upFile.name : 'Klik atau tarik file ke sini'}</span>
              <span className="text-[10px] text-slate-500">PNG, JPG, WebP, PDF, DXF, DWG • maks 10 MB</span>
            </label>
            <div className="grid gap-1.5">
              <Label>Judul</Label>
              <Input value={upMeta.title} onChange={e => setUpMeta(m => ({ ...m, title: e.target.value }))} placeholder="cth: Site Plan Area Utility" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>No. Gambar</Label>
                <Input value={upMeta.drawingNo} onChange={e => setUpMeta(m => ({ ...m, drawingNo: e.target.value }))} placeholder="cth: SP-A-101" />
              </div>
              <div className="grid gap-1.5">
                <Label>Disiplin</Label>
                <Select value={upMeta.discipline} onValueChange={v => setUpMeta(m => ({ ...m, discipline: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Catatan</Label>
              <Textarea rows={2} value={upMeta.notes} onChange={e => setUpMeta(m => ({ ...m, notes: e.target.value }))} placeholder="Opsional: keterangan gambar..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUpOpen(false)}>Batal</Button>
            <Button onClick={doUpload} disabled={!upFile || upBusy} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white">
              {upBusy && <Loader2 className="h-4 w-4 animate-spin" />} Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ DIALOG EDIT GAMBAR ============ */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle>Edit Info Gambar</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label>Judul</Label>
              <Input value={editForm.title} onChange={e => setEditForm(f => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>No. Gambar</Label>
                <Input value={editForm.drawingNo} onChange={e => setEditForm(f => ({ ...f, drawingNo: e.target.value }))} />
              </div>
              <div className="grid gap-1.5">
                <Label>Disiplin</Label>
                <Select value={editForm.discipline} onValueChange={v => setEditForm(f => ({ ...f, discipline: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Catatan</Label>
              <Textarea rows={2} value={editForm.notes} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Batal</Button>
            <Button disabled={!editForm.title.trim()} onClick={async () => {
              if (!sel) return
              await api(`/api/drawings/${sel.id}`, { method: 'PATCH', body: JSON.stringify(editForm) })
              await loadDrawings(); setEditOpen(false)
            }}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ DIALOG ZONA ============ */}
      <Dialog open={zoneOpen} onOpenChange={setZoneOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader><DialogTitle>{zoneEditId ? 'Edit Zona Pekerjaan' : 'Tambah Zona Pekerjaan'}</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Nama Zona *</Label>
                <Input value={zoneForm.name} onChange={e => setZoneForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Area A - Ponds" />
              </div>
              <div className="grid gap-1.5">
                <Label>Kode</Label>
                <Input value={zoneForm.code} onChange={e => setZoneForm(f => ({ ...f, code: e.target.value }))} placeholder="cth: ZN-A" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Disiplin</Label>
                <Select value={zoneForm.discipline} onValueChange={v => setZoneForm(f => ({ ...f, discipline: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Status</Label>
                <Select value={zoneForm.status} onValueChange={v => setZoneForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(ZONE_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Warna Penanda</Label>
              <div className="flex flex-wrap gap-2">
                {ZONE_COLORS.map(c => (
                  <button key={c} aria-label={`Warna ${c}`} onClick={() => setZoneForm(f => ({ ...f, color: c }))}
                    className={cn('h-7 w-7 rounded-full border-2 transition-transform', zoneForm.color === c ? 'scale-110 border-slate-700' : 'border-transparent ring-1 ring-slate-200')}
                    style={{ background: c }} />
                ))}
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Deskripsi</Label>
              <Textarea rows={2} value={zoneForm.description} onChange={e => setZoneForm(f => ({ ...f, description: e.target.value }))} placeholder="Lingkup / batas area..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setZoneOpen(false)}>Batal</Button>
            <Button onClick={submitZone} disabled={!zoneForm.name.trim()} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">
              {zoneEditId ? 'Simpan' : 'Tambah Zona'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============ KONFIRMASI ============ */}
      <AlertDialog open={!!confirm} onOpenChange={o => !o && setConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirm?.title}</AlertDialogTitle>
            <AlertDialogDescription>{confirm?.desc}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => { confirm?.action(); setConfirm(null) }}>Ya, Lanjutkan</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
