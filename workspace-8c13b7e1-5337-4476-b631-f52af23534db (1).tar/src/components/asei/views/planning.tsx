'use client'
import { useMemo, useState } from 'react'
import {
  Plus, Pencil, Trash2, ZoomIn, ZoomOut, Bot, Loader2, Network, Flag, CalendarRange,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { api, createRes, updateRes, deleteRes, DISCIPLINES, DISC_LABEL, DISC_HEX, WBS_STATUS, dateInput, fmtDateShort } from '@/lib/client'
import { useAsei } from '../store'
import type { WbsTask, SuggestedTask } from '@/lib/types'

const DAY_MS = 86400000

export default function PlanningView() {
  const { wbs, refresh } = useAsei()
  const { toast } = useToast()
  const [zoom, setZoom] = useState(12) // px per day
  const [fDisc, setFDisc] = useState('ALL')
  const [showCrit, setShowCrit] = useState(true)
  const [form, setForm] = useState<Partial<WbsTask> | null>(null)
  const [saving, setSaving] = useState(false)
  const [aiOpen, setAiOpen] = useState(false)

  const rows = useMemo(() => [...wbs].sort((a, b) => {
    const [a1, a2] = a.wbsCode.split('.').map(Number)
    const [b1, b2] = b.wbsCode.split('.').map(Number)
    return a1 - b1 || (a2 ?? 0) - (b2 ?? 0)
  }), [wbs])

  const visible = rows.filter(r => fDisc === 'ALL' || r.discipline === fDisc || (r.level === 1 && rows.some(c => c.parentId === r.wbsCode && (fDisc === 'ALL' || c.discipline === fDisc))))

  const projStart = useMemo(() => new Date(Math.min(...rows.map(r => new Date(r.startDate).getTime()))), [rows])
  const projEnd = useMemo(() => new Date(Math.max(...rows.map(r => new Date(r.endDate).getTime()))), [rows])
  const totalDays = Math.ceil((projEnd.getTime() - projStart.getTime()) / DAY_MS) + 1
  const todayOffset = Math.floor((Date.now() - projStart.getTime()) / DAY_MS)

  const months = useMemo(() => {
    const arr: { label: string; days: number }[] = []
    const cur = new Date(projStart)
    for (let i = 0; i < totalDays; i++) {
      const d = new Date(projStart); d.setDate(d.getDate() + i)
      const key = d.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })
      const last = arr[arr.length - 1]
      if (last && last.label === key) last.days++
      else arr.push({ label: key, days: 1 })
    }
    return arr
  }, [projStart, totalDays])

  const offsetOf = (d: string | Date) => Math.floor((new Date(d).getTime() - projStart.getTime()) / DAY_MS)

  const barColor = (t: WbsTask) => {
    if (t.isMilestone) return 'bg-slate-900'
    if (showCrit && t.status === 'DELAYED') return 'bg-red-500'
    return 'bg-gradient-to-r ' + (t.progress >= 100 ? 'from-emerald-400 to-emerald-500' : 'from-amber-400 to-orange-500')
  }

  const save = async () => {
    if (!form?.name || !form?.wbsCode) return toast({ title: 'WBS Code & Nama wajib', variant: 'destructive' })
    setSaving(true)
    try {
      const payload = {
        ...form,
        startDate: form.startDate || new Date().toISOString(),
        endDate: form.endDate || new Date(Date.now() + 7 * DAY_MS).toISOString(),
      }
      if (form.id) await updateRes('wbs', form.id, payload)
      else await createRes('wbs', payload)
      toast({ title: form.id ? 'Aktivitas diperbarui' : 'Aktivitas ditambahkan' })
      setForm(null); await refresh('wbs')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) } finally { setSaving(false) }
  }

  const remove = async (t: WbsTask) => {
    if (!confirm(`Hapus "${t.name}"?`)) return
    try { await deleteRes('wbs', t.id); await refresh('wbs'); toast({ title: 'Aktivitas dihapus' }) }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  const emptyForm = () => {
    const last = rows[rows.length - 1]
    const nextCode = last ? String((Number(last.wbsCode) || rows.filter(r => r.level === 1).length) + 1) + '.1' : '1.1'
    setForm({
      wbsCode: nextCode, name: '', discipline: 'MECHANICAL', subDiscipline: '', level: 2,
      startDate: dateInput(new Date()), endDate: dateInput(new Date(Date.now() + 7 * DAY_MS)),
      duration: 8, progress: 0, plannedProgress: 0, weight: 0, predecessors: '[]', resources: '',
      status: 'NOT_STARTED', isMilestone: false, criticalPath: false,
    })
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 rounded-lg border bg-white px-3 py-1.5 text-xs">
          <CalendarRange className="h-3.5 w-3.5 text-orange-500" />
          <b>{fmtDateShort(projStart)}</b> → <b>{fmtDateShort(projEnd)}</b>
          <span className="text-slate-400">({totalDays} hari)</span>
        </div>
        <Select value={fDisc} onValueChange={setFDisc}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Disiplin</SelectItem>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
        </Select>
        <div className="flex items-center gap-1.5 text-xs">
          <Switch checked={showCrit} onCheckedChange={setShowCrit} id="crit" /> <Label htmlFor="crit" className="text-xs">Highlight delay</Label>
        </div>
        <div className="flex rounded-lg border overflow-hidden">
          <button className="px-2 py-2 hover:bg-slate-50" onClick={() => setZoom(z => Math.max(5, z - 3))} aria-label="Zoom out"><ZoomOut className="h-4 w-4" /></button>
          <span className="px-2 py-2 text-xs border-x">{zoom}px/hari</span>
          <button className="px-2 py-2 hover:bg-slate-50" onClick={() => setZoom(z => Math.min(24, z + 3))} aria-label="Zoom in"><ZoomIn className="h-4 w-4" /></button>
        </div>
        <div className="ml-auto flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setAiOpen(true)} className="gap-1.5 border-orange-300 text-orange-700 hover:bg-orange-50"><Bot className="h-4 w-4" /> AI Plan Suggest</Button>
          <Button size="sm" onClick={emptyForm} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tambah Aktivitas</Button>
        </div>
      </div>

      {/* Gantt */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-max">
              {/* Header */}
              <div className="flex sticky top-0 z-20 bg-white border-b shadow-sm">
                <div className="w-[420px] shrink-0 grid grid-cols-[64px_1fr_84px] border-r text-xs font-semibold text-slate-600 bg-slate-50">
                  <div className="px-2 py-2.5">WBS</div>
                  <div className="px-2 py-2.5">Nama Aktivitas</div>
                  <div className="px-2 py-2.5">Progress</div>
                </div>
                <div style={{ width: totalDays * zoom }}>
                  <div className="flex border-b border-slate-100">
                    {months.map((m, i) => (
                      <div key={i} style={{ width: m.days * zoom }} className="px-2 py-1 text-[10px] font-semibold text-slate-500 border-r border-slate-200 truncate bg-amber-50/60">{m.label}</div>
                    ))}
                  </div>
                  <div className="flex">
                    {Array.from({ length: totalDays }).map((_, i) => {
                      const d = new Date(projStart); d.setDate(d.getDate() + i)
                      const weekend = d.getDay() === 0 || d.getDay() === 6
                      return (
                        <div key={i} style={{ width: zoom }} className={`shrink-0 border-r border-slate-100 text-center text-[8px] py-0.5 ${weekend ? 'bg-slate-100 text-slate-400' : 'text-slate-500'}`}>
                          {zoom >= 10 ? d.getDate() : ''}
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Rows */}
              <div className="relative">
                {visible.map(t => {
                  const start = offsetOf(t.startDate)
                  const end = offsetOf(t.endDate)
                  const left = Math.max(0, start) * zoom
                  const width = Math.max(zoom * 0.8, (end - start + 1) * zoom)
                  const isSummary = t.level === 1
                  const preds = (() => { try { return JSON.parse(t.predecessors) } catch { return [] } })()
                  return (
                    <div key={t.id} className={`flex border-b border-slate-100 group ${isSummary ? 'bg-slate-50/80' : 'hover:bg-amber-50/30'}`}>
                      <div className={`w-[420px] shrink-0 grid grid-cols-[64px_1fr_84px] border-r items-center ${isSummary ? 'font-semibold' : ''}`}>
                        <div className="px-2 py-1.5 text-[10px] font-mono text-slate-500">{t.wbsCode}</div>
                        <div className="px-2 py-1.5 flex items-center gap-1.5 min-w-0">
                          {t.isMilestone && <Flag className="h-3 w-3 text-rose-500 shrink-0" />}
                          <span className={`text-xs truncate ${isSummary ? 'font-semibold text-slate-800 uppercase' : ''}`} title={t.name}>{t.name}</span>
                          {t.level === 2 && <span className="h-2 w-2 rounded-full shrink-0" style={{ background: DISC_HEX[t.discipline] }} />}
                        </div>
                        <div className="px-2 py-1.5">
                          <div className="flex items-center gap-1">
                            <div className="flex-1 h-1.5 rounded bg-slate-200 overflow-hidden">
                              <div className={`h-full ${t.progress >= 100 ? 'bg-emerald-500' : 'bg-orange-500'}`} style={{ width: `${t.progress}%` }} />
                            </div>
                            <span className="text-[9px] font-bold w-7">{t.progress}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="relative" style={{ width: totalDays * zoom, height: 34 }}>
                        {/* gridlines */}
                        <div className="absolute inset-0 flex pointer-events-none">
                          {Array.from({ length: totalDays }).map((_, i) => {
                            const d = new Date(projStart); d.setDate(d.getDate() + i)
                            const weekend = d.getDay() === 0 || d.getDay() === 6
                            return <div key={i} style={{ width: zoom }} className={`shrink-0 border-r border-slate-100 ${weekend ? 'bg-slate-50' : ''}`} />
                          })}
                        </div>
                        {/* today line */}
                        {todayOffset >= 0 && todayOffset <= totalDays && (
                          <div className="absolute top-0 bottom-0 w-0.5 bg-red-500/70 z-10" style={{ left: todayOffset * zoom + zoom / 2 }}>
                            <span className="absolute -top-0.5 -left-2 h-2 w-2 rounded-full bg-red-500" />
                          </div>
                        )}
                        {t.isMilestone ? (
                          <div className="absolute top-1/2 -translate-y-1/2 z-[5]" style={{ left: left + width / 2 - 7 }}>
                            <div className="h-3.5 w-3.5 rotate-45 bg-slate-900 border border-white shadow" title={`Milestone: ${t.name} (${fmtDateShort(t.endDate)})`} />
                          </div>
                        ) : (
                          <button
                            className={`absolute top-1/2 -translate-y-1/2 h-5 rounded-md ${barColor(t)} shadow-sm z-[5] group-hover:shadow-md transition-shadow ${t.status === 'DELAYED' && showCrit ? 'ring-2 ring-red-300' : ''}`}
                            style={{ left, width }}
                            onClick={() => setForm({ ...t, startDate: dateInput(t.startDate), endDate: dateInput(t.endDate) })}
                            title={`${t.wbsCode} ${t.name}\n${fmtDateShort(t.startDate)} → ${fmtDateShort(t.endDate)} • ${t.duration} hari\nProgress ${t.progress}% (plan ${t.plannedProgress}%)\n${preds.length ? 'Predecessor: ' + preds.join(', ') : ''}${t.resources ? '\nResource: ' + t.resources : ''}\nKlik untuk edit`}
                          >
                            {/* planned marker */}
                            <span className="absolute top-0 bottom-0 right-0 bg-black/25 rounded-r-md" style={{ width: `${Math.max(0, 100 - t.plannedProgress)}%` }} title={`Plan ${t.plannedProgress}%`} />
                            {t.progress > 0 && <span className="absolute left-1 top-1/2 -translate-y-1/2 text-[8px] font-bold text-white drop-shadow">{t.progress >= 25 ? `${t.progress}%` : ''}</span>}
                          </button>
                        )}
                      </div>
                      {/* actions */}
                      <div className="absolute right-2 hidden group-hover:flex gap-1 z-20" />
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-4 px-4 py-2.5 border-t text-[10px] text-slate-500">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-5 rounded bg-gradient-to-r from-amber-400 to-orange-500" /> Berjalan</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-5 rounded bg-gradient-to-r from-emerald-400 to-emerald-500" /> Selesai</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-5 rounded bg-slate-900" /> Milestone</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-0.5 bg-red-500" /> Hari ini</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-5 rounded bg-black/25" /> Area gelap = rencana belum tercapai</span>
            <span className="ml-auto">Klik bar untuk edit • Hover untuk detail</span>
          </div>
        </CardContent>
      </Card>

      {/* WBS table (Primavera-style data) */}
      <Card>
        <CardContent className="p-0">
          <div className="px-4 py-2.5 border-b flex items-center gap-2">
            <Network className="h-4 w-4 text-orange-500" />
            <p className="text-sm font-semibold">Data WBS — Tabel Aktivitas (ala Primavera P6)</p>
            <Badge variant="outline" className="text-[10px]">{visible.length} baris</Badge>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="bg-slate-50 border-b text-left text-slate-500">
                {['WBS', 'Nama', 'Disiplin/Sub', 'Mulai', 'Selesai', 'Dur', 'Progres', 'Plan', 'Pred.', 'Resource', 'Status', ''].map(h => (
                  <th key={h} className="px-2.5 py-2 font-medium whitespace-nowrap">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {visible.map(t => {
                  const preds = (() => { try { return JSON.parse(t.predecessors) } catch { return [] } })()
                  const isSummary = t.level === 1
                  return (
                    <tr key={t.id} className={`border-b last:border-0 ${isSummary ? 'bg-slate-50/70 font-semibold' : 'hover:bg-slate-50/60'}`}>
                      <td className="px-2.5 py-1.5 font-mono">{t.wbsCode}</td>
                      <td className="px-2.5 py-1.5 max-w-56 truncate" title={t.name}>{t.name}</td>
                      <td className="px-2.5 py-1.5">{isSummary ? '' : <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full" style={{ background: DISC_HEX[t.discipline] }} />{t.subDiscipline || DISC_LABEL[t.discipline]}</span>}</td>
                      <td className="px-2.5 py-1.5 whitespace-nowrap">{fmtDateShort(t.startDate)}</td>
                      <td className="px-2.5 py-1.5 whitespace-nowrap">{fmtDateShort(t.endDate)}</td>
                      <td className="px-2.5 py-1.5 text-center">{t.isMilestone ? 'MS' : `${t.duration}d`}</td>
                      <td className={`px-2.5 py-1.5 font-bold ${t.progress >= 100 ? 'text-emerald-600' : t.progress > 0 ? 'text-orange-600' : 'text-slate-400'}`}>{t.progress}%</td>
                      <td className="px-2.5 py-1.5 text-slate-500">{t.plannedProgress}%</td>
                      <td className="px-2.5 py-1.5 text-slate-500">{preds.join(', ') || '-'}</td>
                      <td className="px-2.5 py-1.5 max-w-28 truncate">{t.resources || '-'}</td>
                      <td className="px-2.5 py-1.5"><Badge variant="outline" className={`text-[9px] ${t.status === 'DELAYED' ? 'border-red-300 text-red-600' : t.status === 'COMPLETED' ? 'border-emerald-300 text-emerald-700' : 'border-slate-300 text-slate-600'}`}>{WBS_STATUS[t.status] ?? t.status}</Badge></td>
                      <td className="px-2.5 py-1.5">
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" className="h-5 w-5 p-0" onClick={() => setForm({ ...t, startDate: dateInput(t.startDate), endDate: dateInput(t.endDate) })} aria-label="Edit"><Pencil className="h-2.5 w-2.5" /></Button>
                          <Button size="sm" variant="outline" className="h-5 w-5 p-0 text-red-600" onClick={() => remove(t)} aria-label="Hapus"><Trash2 className="h-2.5 w-2.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Edit dialog */}
      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Aktivitas WBS' : 'Tambah Aktivitas WBS'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label>WBS Code *</Label><Input value={form?.wbsCode ?? ''} onChange={e => setForm(f => ({ ...f, wbsCode: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Level</Label>
              <Select value={String(form?.level ?? 2)} onValueChange={v => setForm(f => ({ ...f, level: Number(v), parentId: Number(v) === 1 ? '' : (f?.wbsCode ?? '').split('.')[0] }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="1">1 — Ringkasan (Summary)</SelectItem><SelectItem value="2">2 — Aktivitas</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1"><Label>Nama Aktivitas *</Label><Input value={form?.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'MECHANICAL'} onValueChange={v => setForm(f => ({ ...f, discipline: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Sub-Bagian</Label><Input value={form?.subDiscipline ?? ''} onChange={e => setForm(f => ({ ...f, subDiscipline: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Mulai *</Label><Input type="date" value={form?.startDate ? String(form.startDate).slice(0, 10) : ''} onChange={e => {
              const v = e.target.value
              setForm(f => {
                if (!f || !v) return { ...f, startDate: v }
                const dur = f.duration && f.duration > 0 ? f.duration : 1
                const end = new Date(new Date(v).getTime() + (dur - 1) * DAY_MS)
                return { ...f, startDate: v, endDate: end.toISOString() }
              })
            }} /></div>
            <div className="space-y-1"><Label>Selesai *</Label><Input type="date" value={form?.endDate ? String(form.endDate).slice(0, 10) : ''} onChange={e => {
              const v = e.target.value
              setForm(f => {
                if (!f || !v || !f.startDate) return { ...f, endDate: v }
                const dur = Math.max(1, Math.round((new Date(v).getTime() - new Date(f.startDate).getTime()) / DAY_MS) + 1)
                return { ...f, endDate: v, duration: dur }
              })
            }} /></div>
            <div className="space-y-1"><Label>Durasi (hari kerja)</Label><Input type="number" min={1} value={form?.duration ?? 1} onChange={e => {
              const dur = Math.max(1, Number(e.target.value))
              setForm(f => {
                if (!f || !f.startDate) return { ...f, duration: dur }
                const end = new Date(new Date(f.startDate).getTime() + (dur - 1) * DAY_MS)
                return { ...f, duration: dur, endDate: end.toISOString() }
              })
            }} /></div>
            <div className="space-y-1"><Label>Bobot (%)</Label><Input type="number" min={0} value={form?.weight ?? 0} onChange={e => setForm(f => ({ ...f, weight: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Progress Aktual %</Label><Input type="number" min={0} max={100} value={form?.progress ?? 0} onChange={e => setForm(f => ({ ...f, progress: Math.max(0, Math.min(100, Number(e.target.value))) }))} /></div>
            <div className="space-y-1"><Label>Progress Rencana %</Label><Input type="number" min={0} max={100} value={form?.plannedProgress ?? 0} onChange={e => setForm(f => ({ ...f, plannedProgress: Math.max(0, Math.min(100, Number(e.target.value))) }))} /></div>
            <div className="space-y-1"><Label>Predecessors (kode, pisah koma)</Label><Input value={(() => { try { const p = JSON.parse(form?.predecessors ?? '[]'); return Array.isArray(p) ? p.join(', ') : '' } catch { return '' } })()} onChange={e => setForm(f => ({ ...f, predecessors: JSON.stringify(e.target.value.split(',').map(x => x.trim()).filter(Boolean)) }))} placeholder="cth: 4.2, 5.1" /></div>
            <div className="space-y-1"><Label>Resource / Crew</Label><Input value={form?.resources ?? ''} onChange={e => setForm(f => ({ ...f, resources: e.target.value }))} placeholder="cth: Piping Crew" /></div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'NOT_STARTED'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(WBS_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Budget (Rp)</Label><Input type="number" value={form?.budget ?? 0} onChange={e => setForm(f => ({ ...f, budget: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Actual Cost (Rp)</Label><Input type="number" value={form?.actualCost ?? 0} onChange={e => setForm(f => ({ ...f, actualCost: Number(e.target.value) }))} /></div>
            <div className="sm:col-span-2 flex flex-wrap gap-6">
              <div className="flex items-center gap-2"><Switch checked={!!form?.isMilestone} onCheckedChange={v => setForm(f => ({ ...f, isMilestone: v }))} id="ms" /><Label htmlFor="ms" className="text-xs">Milestone</Label></div>
              <div className="flex items-center gap-2"><Switch checked={!!form?.criticalPath} onCheckedChange={v => setForm(f => ({ ...f, criticalPath: v }))} id="cp" /><Label htmlFor="cp" className="text-xs">Critical Path</Label></div>
            </div>
            <div className="sm:col-span-2 space-y-1"><Label>Notes</Label><Textarea rows={2} value={form?.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">Simpan</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AiPlanDialog open={aiOpen} onOpenChange={setAiOpen} onDone={() => refresh('wbs')} />
    </div>
  )
}

/* ============ AI PLAN SUGGEST DIALOG ============ */
function AiPlanDialog({ open, onOpenChange, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; onDone: () => void }) {
  const { toast } = useToast()
  const [disc, setDisc] = useState('MECHANICAL')
  const [scope, setScope] = useState('Instalasi piping area proses (erection, welding, hydrotest)')
  const [start, setStart] = useState(new Date().toISOString().slice(0, 10))
  const [loading, setLoading] = useState(false)
  const [tasks, setTasks] = useState<SuggestedTask[] | null>(null)
  const [adding, setAdding] = useState(false)

  const generate = async () => {
    setLoading(true); setTasks(null)
    try {
      const j = await api<{ data: SuggestedTask[] }>('/api/ai/plan', { method: 'POST', body: JSON.stringify({ discipline: disc, scope, startDate: start }) })
      setTasks(j.data)
      toast({ title: 'AI menghasilkan plan', description: `${j.data.length} aktivitas` })
    } catch (e) { toast({ title: 'AI plan gagal', description: String(e), variant: 'destructive' }) }
    finally { setLoading(false) }
  }

  const apply = async () => {
    if (!tasks?.length) return
    setAdding(true)
    try {
      // map "after" names to codes
      const codeMap: Record<string, string> = {}
      let parentCode = ''
      const existing = await api<{ data: WbsTask[] }>('/api/data/wbs')
      const lvl1 = existing.data.filter(t => t.level === 1)
      parentCode = String(lvl1.length + 1)
      const baseStart = new Date(start).getTime()
      let cursor = baseStart
      for (const [i, t] of tasks.entries()) {
        const code = `${parentCode}.${i + 1}`
        codeMap[t.name] = code
        const afterCodes = (t.after ?? []).map(n => codeMap[n]).filter(Boolean)
        const sDate = i === 0 ? baseStart : cursor
        const eDate = sDate + (Math.max(1, t.duration) - 1) * DAY_MS
        cursor = eDate + DAY_MS
        await createRes('wbs', {
          wbsCode: code, name: t.name, discipline: t.discipline || disc, subDiscipline: t.subDiscipline ?? '',
          parentId: parentCode, level: 2, order: i + 1,
          startDate: new Date(sDate).toISOString(), endDate: new Date(eDate).toISOString(),
          duration: Math.max(1, t.duration), progress: 0, plannedProgress: 0, weight: t.weight ?? 0,
          predecessors: JSON.stringify(afterCodes), resources: t.resources ?? '',
          status: 'NOT_STARTED', isMilestone: false, criticalPath: false,
        })
      }
      toast({ title: 'Plan AI ditambahkan ke WBS', description: `${tasks.length} aktivitas masuk jadwal` })
      setTasks(null); onOpenChange(false); onDone()
    } catch (e) { toast({ title: 'Gagal menambahkan', description: String(e), variant: 'destructive' }) }
    finally { setAdding(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Bot className="h-5 w-5 text-orange-500" /> AI Plan Suggest — ala Primavera Scheduler</DialogTitle>
        </DialogHeader>
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="space-y-1"><Label>Disiplin</Label>
            <Select value={disc} onValueChange={setDisc}>
              <SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1"><Label>Mulai</Label><Input type="date" value={start} onChange={e => setStart(e.target.value)} /></div>
          <div className="sm:col-span-3 space-y-1"><Label>Lingkup Pekerjaan</Label><Textarea rows={2} value={scope} onChange={e => setScope(e.target.value)} /></div>
        </div>
        <Button onClick={generate} disabled={loading} className="gap-1.5 bg-gradient-to-r from-orange-500 to-amber-600 text-white w-fit">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bot className="h-4 w-4" />} Generate Plan
        </Button>
        {tasks && (
          <div className="rounded-lg border overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="bg-slate-50 border-b text-left text-slate-500"><th className="px-2 py-1.5">#</th><th className="px-2 py-1.5">Aktivitas</th><th className="px-2 py-1.5">Durasi</th><th className="px-2 py-1.5">Setelah</th><th className="px-2 py-1.5">Resource</th><th className="px-2 py-1.5">Bobot</th></tr></thead>
              <tbody>{tasks.map((t, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="px-2 py-1.5">{i + 1}</td>
                  <td className="px-2 py-1.5 font-medium">{t.name}</td>
                  <td className="px-2 py-1.5">{t.duration} hari</td>
                  <td className="px-2 py-1.5 text-slate-500">{(t.after ?? []).join(', ') || '-'}</td>
                  <td className="px-2 py-1.5 text-slate-500">{t.resources || '-'}</td>
                  <td className="px-2 py-1.5">{t.weight ?? 0}%</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
        <DialogFooter>
          {tasks && <Button onClick={apply} disabled={adding} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white">{adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Tambahkan ke WBS</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
