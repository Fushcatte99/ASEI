'use client'
import { useCallback, useEffect, useState } from 'react'
import {
  UserCog, Plus, Pencil, Trash2, RefreshCw, Loader2, KeyRound, Users,
  ShieldCheck, ShieldAlert, Search, UserX,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { api, fmtDateTime } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { useToast } from '@/hooks/use-toast'
import type { UserAccount, Employee } from '@/lib/types'

interface FormState { username: string; name: string; password: string; role: string; employeeId: string; isActive: boolean }
const emptyForm: FormState = { username: '', name: '', password: '', role: 'STAFF', employeeId: '', isActive: true }

export default function AccountsView() {
  const { employees, user } = useAsei()
  const { toast } = useToast()
  const [accounts, setAccounts] = useState<UserAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [dlgOpen, setDlgOpen] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [delTarget, setDelTarget] = useState<UserAccount | null>(null)

  const em = empMap(employees as Employee[])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const j = await api<{ data: UserAccount[] }>('/api/admin/accounts')
      setAccounts(j.data)
    } catch (e) {
      toast({ title: 'Gagal memuat akun', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    } finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  const openCreate = () => { setEditId(null); setForm(emptyForm); setDlgOpen(true) }
  const openEdit = (a: UserAccount) => {
    setEditId(a.id)
    setForm({ username: a.username, name: a.name, password: '', role: a.role, employeeId: a.employeeId ?? '', isActive: a.isActive })
    setDlgOpen(true)
  }

  const submit = async () => {
    setSaving(true)
    try {
      if (editId) {
        const body: Record<string, unknown> = {
          username: form.username, name: form.name, role: form.role,
          employeeId: form.employeeId, isActive: form.isActive,
        }
        if (form.password) body.password = form.password
        await api(`/api/admin/accounts/${editId}`, { method: 'PATCH', body: JSON.stringify(body) })
        toast({ title: 'Akun diperbarui' })
      } else {
        await api('/api/admin/accounts', { method: 'POST', body: JSON.stringify(form) })
        toast({ title: 'Akun dibuat', description: `${form.username} siap digunakan` })
      }
      setDlgOpen(false)
      await load()
    } catch (e) {
      toast({ title: 'Gagal menyimpan akun', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    } finally { setSaving(false) }
  }

  const doDelete = async () => {
    if (!delTarget) return
    try {
      await api(`/api/admin/accounts/${delTarget.id}`, { method: 'DELETE' })
      toast({ title: `Akun "${delTarget.username}" dihapus` })
      await load()
    } catch (e) {
      toast({ title: 'Gagal menghapus akun', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    } finally { setDelTarget(null) }
  }

  const filtered = accounts.filter(a =>
    !query ||
    a.username.toLowerCase().includes(query.toLowerCase()) ||
    (a.name ?? '').toLowerCase().includes(query.toLowerCase()) ||
    (a.employeeName ?? '').toLowerCase().includes(query.toLowerCase()),
  )
  const adminCount = accounts.filter(a => a.role === 'MASTER_ADMIN').length
  const staffCount = accounts.filter(a => a.role === 'STAFF').length
  const activeCount = accounts.filter(a => a.isActive).length

  return (
    <div className="space-y-4">
      {/* Statistik */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Total Akun', value: accounts.length, icon: Users, cls: 'bg-slate-100 text-slate-700' },
          { label: 'Master Admin', value: adminCount, icon: ShieldCheck, cls: 'bg-violet-100 text-violet-700' },
          { label: 'Akun Staf', value: staffCount, icon: UserCog, cls: 'bg-amber-100 text-amber-700' },
          { label: 'Aktif', value: activeCount, icon: ShieldAlert, cls: 'bg-emerald-100 text-emerald-700' },
        ].map(c => (
          <div key={c.label} className="rounded-xl border bg-white p-4 flex items-center gap-3">
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${c.cls}`}>
              <c.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-900 leading-none">{loading ? '-' : c.value}</p>
              <p className="text-[11px] text-slate-500 mt-1">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="rounded-xl border bg-white p-3 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari username / nama / pekerja..." className="pl-8 h-9" />
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading} className="gap-1.5">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Muat Ulang
        </Button>
        <Button size="sm" onClick={openCreate} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:opacity-90">
          <Plus className="h-4 w-4" /> Tambah Akun
        </Button>
      </div>

      {/* Tabel akun */}
      <div className="rounded-xl border bg-white overflow-hidden">
        <div className="max-h-[62vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-[11px] uppercase tracking-wide sticky top-0 z-10">
              <tr>
                <th className="text-left font-semibold px-4 py-2.5">Username</th>
                <th className="text-left font-semibold px-4 py-2.5">Nama</th>
                <th className="text-left font-semibold px-4 py-2.5">Role</th>
                <th className="text-left font-semibold px-4 py-2.5 hidden md:table-cell">Terhubung Pekerja</th>
                <th className="text-left font-semibold px-4 py-2.5 hidden lg:table-cell">Login Terakhir</th>
                <th className="text-left font-semibold px-4 py-2.5">Status</th>
                <th className="text-right font-semibold px-4 py-2.5">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {loading && (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400"><Loader2 className="h-6 w-6 animate-spin inline" /></td></tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400 text-sm">Tidak ada akun ditemukan</td></tr>
              )}
              {filtered.map(a => {
                const isSelf = a.id === user?.uid
                return (
                  <tr key={a.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-2.5">
                      <span className="font-semibold text-slate-900">{a.username}</span>
                      {isSelf && <span className="ml-1.5 rounded bg-amber-100 text-amber-700 border border-amber-200 px-1 py-0.5 text-[10px] font-semibold">ANDA</span>}
                    </td>
                    <td className="px-4 py-2.5 text-slate-600 max-w-[160px] truncate">{a.name || '-'}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[10px] font-semibold ${a.role === 'MASTER_ADMIN' ? 'bg-violet-100 text-violet-700 border-violet-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                        {a.role === 'MASTER_ADMIN' ? <ShieldCheck className="h-3 w-3" /> : <UserCog className="h-3 w-3" />}
                        {a.role === 'MASTER_ADMIN' ? 'MASTER ADMIN' : 'STAFF'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-slate-600 hidden md:table-cell max-w-[200px] truncate">
                      {a.employeeName ?? <span className="text-slate-300">—</span>}
                    </td>
                    <td className="px-4 py-2.5 text-slate-500 text-xs hidden lg:table-cell">{a.lastLoginAt ? fmtDateTime(a.lastLoginAt) : 'Belum pernah'}</td>
                    <td className="px-4 py-2.5">
                      <span className={`inline-flex rounded px-1.5 py-0.5 text-[10px] font-semibold ${a.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                        {a.isActive ? 'AKTIF' : 'NONAKTIF'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => openEdit(a)} className="p-1.5 rounded hover:bg-amber-50 text-amber-600" title="Edit akun">
                          <Pencil className="h-4 w-4" />
                        </button>
                        {!isSelf && (
                          <button onClick={() => setDelTarget(a)} className="p-1.5 rounded hover:bg-red-50 text-red-600" title="Hapus akun">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dialog tambah/edit */}
      <Dialog open={dlgOpen} onOpenChange={setDlgOpen}>
        <DialogContent className="sm:max-w-md" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>{editId ? 'Edit Akun' : 'Tambah Akun Baru'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="acc-username">Username *</Label>
              <Input id="acc-username" value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value.toLowerCase() }))} placeholder="cth: staff35" disabled={!!editId && editId === user?.uid} />
              <p className="text-[11px] text-slate-400">Huruf kecil, angka, titik, garis bawah, strip. Minimal 3 karakter.</p>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="acc-name">Nama Lengkap</Label>
              <Input id="acc-name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="cth: Budi Santoso" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="acc-password">{editId ? 'Password Baru (opsional)' : 'Password *'}</Label>
              <div className="relative">
                <KeyRound className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input id="acc-password" type="text" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder={editId ? 'Kosongkan jika tidak diubah' : 'Minimal 6 karakter'} className="pl-8" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Role</Label>
                <Select value={form.role} onValueChange={v => setForm(f => ({ ...f, role: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="STAFF">STAFF</SelectItem>
                    <SelectItem value="MASTER_ADMIN">MASTER ADMIN</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Terhubung Pekerja</Label>
                <Select value={form.employeeId || 'none'} onValueChange={v => setForm(f => ({ ...f, employeeId: v === 'none' ? '' : v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent className="max-h-60">
                    <SelectItem value="none"><span className="text-slate-400">— Tidak terhubung —</span></SelectItem>
                    {employees.map(e => (
                      <SelectItem key={e.id} value={e.id} disabled={accounts.some(a => a.employeeId === e.id && a.id !== editId)}>
                        {e.nip} • {e.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg border bg-slate-50 p-3">
              <Switch id="acc-active" checked={form.isActive} onCheckedChange={v => setForm(f => ({ ...f, isActive: v }))} disabled={!!editId && editId === user?.uid} />
              <Label htmlFor="acc-active" className="text-xs font-normal leading-snug">Akun aktif (bisa login). Nonaktif = tidak bisa login, data tetap tersimpan.</Label>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDlgOpen(false)}>Batal</Button>
            <Button onClick={submit} disabled={saving || !form.username.trim() || (!editId && !form.password)} className="gap-1.5">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {editId ? 'Simpan Perubahan' : 'Buat Akun'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus */}
      <AlertDialog open={!!delTarget} onOpenChange={v => !v && setDelTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus akun &quot;{delTarget?.username}&quot;?</AlertDialogTitle>
            <AlertDialogDescription className="flex items-start gap-2">
              <UserX className="h-4 w-4 mt-0.5 shrink-0 text-red-500" />
              Akun tidak bisa login lagi setelah dihapus. Data pekerja terkait tidak ikut terhapus. Akun dapat dibuat ulang kapan saja.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-red-600 hover:bg-red-700">Ya, Hapus Akun</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
