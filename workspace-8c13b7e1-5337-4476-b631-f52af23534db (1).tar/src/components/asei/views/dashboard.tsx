'use client'
import { useEffect, useState } from 'react'
import {
  Users, Clock4, AlertTriangle, ClipboardList, ShieldCheck, HeartPulse,
  HardHat, Wrench, Zap, Camera, TrendingUp, Award,
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend,
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { api, DISC_HEX, DISC_LABEL, roleBadge, activeProjectId } from '@/lib/client'
import { useAsei } from '../store'
import { StatCard, SimpleBar, AseiAvatar } from '../ui-bits'
import type { DashboardData } from '@/lib/types'

export default function DashboardView({ onNavigate }: { onNavigate: (id: string) => void }) {
  const [data, setData] = useState<DashboardData | null>(null)
  const projects = useAsei(s => s.projects)
  const activePid = useAsei(s => s.activeProjectId)
  const activeProject = projects.find(p => p.id === activePid)

  useEffect(() => {
    api<{ data: DashboardData }>(`/api/dashboard?projectId=${activeProjectId()}`).then(j => setData(j.data)).catch(() => {})
  }, [])

  if (!data) return <div className="py-20 text-center text-sm text-slate-400">Memuat dashboard...</div>

  const trendData = data.trend.map(t => ({
    ...t,
    label: new Date(t.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }),
  }))

  const discData = data.progress.discProgress.map(d => ({
    name: DISC_LABEL[d.discipline],
    Aktual: d.actual,
    Rencana: d.planned,
  }))

  const radarData = [
    { subject: 'APD', score: data.attendance.avgPpe },
    { subject: 'Mood', score: data.attendance.avgMood },
    { subject: 'Task', score: Math.round((data.taskStats.completed / Math.max(1, data.taskStats.total)) * 100) },
    { subject: 'Fabrikasi', score: data.fabProgress },
    { subject: 'Equipment', score: Math.round((data.eqStats.arrived / Math.max(1, data.eqStats.total)) * 100) },
  ]

  return (
    <div className="space-y-5">
      {/* Hero strip */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-orange-900 text-white p-5 sm:p-6 relative overflow-hidden">
        <div className="absolute -right-8 -top-8 opacity-10 rotate-12"><HardHat className="h-44 w-44" /></div>
        <p className="text-xs uppercase tracking-widest text-amber-400 font-semibold">Proyek Berjalan</p>
        <h2 className="text-xl sm:text-2xl font-bold mt-1">{activeProject?.name ?? 'Proyek'}</h2>
        {(activeProject?.client || activeProject?.location) && (
          <p className="text-xs text-slate-400">{[activeProject?.client, activeProject?.location].filter(Boolean).join(' • ')}</p>
        )}
        <p className="text-sm text-slate-300 mt-1">Progress fisik <span className="font-bold text-white">{data.progress.actualProgress}%</span> vs rencana <span className="font-bold text-white">{data.progress.plannedProgress}%</span>
          <span className={`ml-2 rounded-full px-2 py-0.5 text-xs font-semibold ${data.progress.deviation >= 0 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
            {data.progress.deviation >= 0 ? '+' : ''}{data.progress.deviation}% deviasi
          </span>
        </p>
        <div className="mt-4 max-w-xl">
          <SimpleBar value={data.progress.actualProgress} color="bg-gradient-to-r from-amber-400 to-orange-500" height="h-2.5" />
        </div>
        <div className="flex flex-wrap gap-2 mt-4 text-xs">
          <span className="rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Zero accident {data.zeroAccidentDays} hari</span>
          <span className="rounded-full bg-white/10 text-slate-200 border border-white/20 px-3 py-1 flex items-center gap-1.5"><Users className="h-3.5 w-3.5" /> {data.headcount.total} personel aktif</span>
          <span className="rounded-full bg-white/10 text-slate-200 border border-white/20 px-3 py-1 flex items-center gap-1.5"><Camera className="h-3.5 w-3.5" /> APD hari ini rata-rata {data.attendance.avgPpe}/100</span>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard title="Hadir Hari Ini" value={data.attendance.presentToday} sub={`${data.attendance.lateToday} terlambat`} icon={<Clock4 className="h-5 w-5" />} accent="bg-emerald-500" onClick={() => onNavigate('attendance')} />
        <StatCard title="Rata-rata APD" value={data.attendance.avgPpe} sub="skor AI 0-100" icon={<HardHat className="h-5 w-5" />} accent="bg-amber-500" onClick={() => onNavigate('attendance')} />
        <StatCard title="Indeks Mood" value={data.attendance.avgMood} sub="kebahagiaan tim" icon={<HeartPulse className="h-5 w-5" />} accent="bg-rose-500" onClick={() => onNavigate('attendance')} />
        <StatCard title="Task Aktif" value={data.taskStats.inProgress + data.taskStats.pending} sub={`${data.taskStats.overdue} overdue`} icon={<ClipboardList className="h-5 w-5" />} accent="bg-orange-500" onClick={() => onNavigate('tasks')} />
        <StatCard title="Fabrikasi" value={`${data.fabProgress}%`} sub={`${data.fabTotal} item workshop`} icon={<Wrench className="h-5 w-5" />} accent="bg-teal-500" onClick={() => onNavigate('progress')} />
        <StatCard title="Equipment Tiba" value={`${data.eqStats.arrived}/${data.eqStats.total}`} sub={`${data.eqStats.delayed} terlambat`} icon={<TrendingUp className="h-5 w-5" />} accent="bg-violet-500" onClick={() => onNavigate('progress')} />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Kehadiran, Skor APD & Mood — 7 Hari Terakhir</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="gPpe" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="gMood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Area type="monotone" dataKey="ppe" name="Skor APD" stroke="#f59e0b" fill="url(#gPpe)" strokeWidth={2} />
                <Area type="monotone" dataKey="mood" name="Indeks Mood" stroke="#10b981" fill="url(#gMood)" strokeWidth={2} />
                <Area type="stepAfter" dataKey="present" name="Kehadiran" stroke="#64748b" fill="#64748b22" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Kesehatan Proyek (AI Insight)</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius="72%">
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                <Radar dataKey="score" stroke="#ea580c" fill="#f97316" fillOpacity={0.45} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Progress per Disiplin (Aktual vs Rencana)</CardTitle></CardHeader>
          <CardContent className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={discData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Aktual" fill="#ea580c" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Rencana" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Award className="h-4 w-4 text-amber-500" /> Top & Bawah Performa (KPI Bulanan)</CardTitle></CardHeader>
          <CardContent className="grid sm:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-semibold text-emerald-600 mb-2">5 Terbaik</p>
              <div className="space-y-2">
                {data.topPerformers.map((p, i) => (
                  <div key={p.id} className="flex items-center gap-2">
                    <span className="w-5 text-xs font-bold text-slate-400">#{i + 1}</span>
                    <AseiAvatar name={p.name} className="h-7 w-7" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium truncate">{p.name}</p>
                      <span className={`inline-block rounded border px-1 text-[9px] ${roleBadge(p.role)}`}>{p.role}</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">{p.score}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-red-500 mb-2">Perlu Perhatian</p>
              <div className="space-y-2">
                {data.lowPerformers.map((p, i) => (
                  <div key={p.id} className="flex items-center gap-2">
                    <span className="w-5 text-xs font-bold text-slate-400">#{i + 1}</span>
                    <AseiAvatar name={p.name} className="h-7 w-7" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium truncate">{p.name}</p>
                      <span className={`inline-block rounded border px-1 text-[9px] ${roleBadge(p.role)}`}>{p.role}</span>
                    </div>
                    <span className="text-xs font-bold text-red-500">{p.score}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Discipline quick stats */}
      <div className="grid sm:grid-cols-3 gap-3">
        {[
          { d: 'CIVIL', icon: HardHat, qty: data.qtyStats.find(q => q.discipline === 'CIVIL')?.avgPct ?? 0, items: data.progress.discProgress.find(x => x.discipline === 'CIVIL') },
          { d: 'MECHANICAL', icon: Wrench, qty: data.qtyStats.find(q => q.discipline === 'MECHANICAL')?.avgPct ?? 0, items: data.progress.discProgress.find(x => x.discipline === 'MECHANICAL') },
          { d: 'ELECTRICAL', icon: Zap, qty: data.qtyStats.find(q => q.discipline === 'ELECTRICAL')?.avgPct ?? 0, items: data.progress.discProgress.find(x => x.discipline === 'ELECTRICAL') },
        ].map(({ d, icon: Icon, qty, items }) => (
          <div key={d} className="rounded-xl border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="rounded-lg p-2 text-white" style={{ background: DISC_HEX[d] }}><Icon className="h-5 w-5" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{DISC_LABEL[d]}</p>
                <p className="text-xs text-slate-500">{items ? `${items.count} aktivitas WBS` : ''} • kuantitas {qty}%</p>
              </div>
              <span className="text-xl font-bold" style={{ color: DISC_HEX[d] }}>{items?.actual ?? 0}%</span>
            </div>
            <SimpleBar value={items?.actual ?? 0} color="bg-orange-500" className="mt-3" />
          </div>
        ))}
      </div>

      {data.taskStats.overdue > 0 && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-red-700">{data.taskStats.overdue} work task melewati tenggat</p>
            <p className="text-xs text-red-600 mt-0.5">Segera tinjau penugasan di menu Work Task dan koordinasikan ulang dengan supervisor terkait.</p>
          </div>
        </div>
      )}
    </div>
  )
}
