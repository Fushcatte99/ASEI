'use client'
import { useMemo, useState } from 'react'
import { Target, Trophy, Search, CalendarDays, Calculator, History } from 'lucide-react'
import {
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ROLE_LABEL, roleBadge, scoreColor, scoreBg, fmtDate, api } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { AseiAvatar, SimpleBar, EmptyState } from '../ui-bits'
import { useToast } from '@/hooks/use-toast'
import type { KpiRecord, Employee } from '@/lib/types'

interface Bucket { key: string; label: string; start: Date; end: Date; isCurrent: boolean }

export default function KpiView() {
  const { kpi, employees, attendance, tasks, refresh, activeProjectId } = useAsei()
  const { toast } = useToast()
  const eMap = useMemo(() => empMap(employees), [employees])
  const [q, setQ] = useState('')
  const [selId, setSelId] = useState('')
  const [period, setPeriod] = useState<'MONTHLY' | 'WEEKLY'>('MONTHLY')
  const [bucketKey, setBucketKey] = useState('')
  const [recalcing, setRecalcing] = useState(false)

  const today = new Date()
  const day0 = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate())

  // ===== Kelompokkan data KPI per periode (bulan utk MONTHLY, minggu utk WEEKLY) =====
  const buckets = useMemo<Bucket[]>(() => {
    const map = new Map<string, Bucket>()
    for (const k of kpi.filter(x => x.period === period)) {
      const s = day0(new Date(k.periodStart))
      const e = day0(new Date(k.periodEnd))
      const key = period === 'MONTHLY'
        ? `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}`
        : s.toISOString().slice(0, 10)
      const isCurrent = period === 'MONTHLY'
        ? s.getFullYear() === today.getFullYear() && s.getMonth() === today.getMonth()
        : today >= s && today <= e
      const label = period === 'MONTHLY'
        ? s.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })
        : `${fmtDate(s)} — ${fmtDate(e)}`
      const prev = map.get(key)
      if (!prev || s > prev.start) map.set(key, { key, label, start: s, end: e, isCurrent })
    }
    return [...map.values()].sort((a, b) => b.start.getTime() - a.start.getTime())
  }, [kpi, period])

  // Default: periode berjalan bila ada datanya; kalau tidak, pakai periode terakhir yang ada data
  const effectiveKey = useMemo(() => {
    if (bucketKey && buckets.some(b => b.key === bucketKey)) return bucketKey
    return buckets.find(b => b.isCurrent)?.key ?? buckets[0]?.key ?? ''
  }, [bucketKey, buckets])
  const activeBucket = buckets.find(b => b.key === effectiveKey)
  const currentBucket = buckets.find(b => b.isCurrent)
  const isLatest = activeBucket?.key === buckets[0]?.key

  const records = useMemo(() => (activeBucket
    ? kpi
      .filter(k => k.period === period && day0(new Date(k.periodStart)).getTime() === activeBucket.start.getTime())
      .map(k => ({ k, e: eMap[k.employeeId] }))
      .filter(x => !!x.k && !!x.e)
    : []), [kpi, period, activeBucket, eMap])

  const ranked = records
    .filter(({ e }) => !q || e.name.toLowerCase().includes(q.toLowerCase()) || e.role.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => b.k.overallScore - a.k.overallScore)

  const selRec = selId ? records.find(x => x.k.employeeId === selId) : undefined
  const selected: { k?: KpiRecord; e?: Employee } = selRec ?? (ranked[0] ? { k: ranked[0].k, e: ranked[0].e } : {})

  // live stats for selected
  const myAtt = selected.e ? attendance.filter(a => a.employeeId === selected.e!.id) : []
  const attPct = myAtt.length ? Math.round(myAtt.filter(a => ['PRESENT', 'LATE'].includes(a.status)).length / myAtt.length * 100) : 0
  const myTasks = selected.e ? tasks.filter(t => t.assigneeId === selected.e!.id) : []
  const taskPct = myTasks.length ? Math.round(myTasks.reduce((s, t) => s + t.progress, 0) / myTasks.length) : 0

  const radarData = selected.k ? [
    { subject: 'Kehadiran', score: selected.k.attendanceScore },
    { subject: 'Task', score: selected.k.taskScore },
    { subject: 'Disiplin', score: selected.k.disciplineScore },
    { subject: 'Kualitas', score: selected.k.qualityScore },
    { subject: 'Safety', score: selected.k.safetyScore },
  ] : []

  const histData = [...ranked].map(x => ({ name: x.e?.name.split(' ')[0] ?? '?', score: x.k?.overallScore ?? 0 }))

  const recalc = async () => {
    setRecalcing(true)
    try {
      const j = await api<{ ok: boolean; monthly: number; weekly: number }>('/api/kpi/recalc', {
        method: 'POST',
        body: JSON.stringify({ projectId: activeProjectId, tzOffset: new Date().getTimezoneOffset() }),
      })
      toast({ title: 'KPI periode berjalan dihitung ulang', description: `Bulanan: ${j.monthly} karyawan • Mingguan: ${j.weekly} karyawan — dihitung dari absensi & work task live.` })
      setBucketKey('')
      await refresh('kpi')
    } catch (e) {
      toast({ title: 'Gagal menghitung KPI', description: String(e), variant: 'destructive' })
    } finally { setRecalcing(false) }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <InputCustom value={q} onChange={setQ} />
        </div>
        <Select value={period} onValueChange={v => { setPeriod(v as 'MONTHLY' | 'WEEKLY'); setBucketKey(''); setSelId('') }}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="MONTHLY">KPI Bulanan</SelectItem><SelectItem value="WEEKLY">KPI Mingguan</SelectItem></SelectContent>
        </Select>
        {buckets.length > 0 && (
          <Select value={effectiveKey} onValueChange={v => { setBucketKey(v); setSelId('') }}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Pilih periode" /></SelectTrigger>
            <SelectContent>{buckets.map(b => <SelectItem key={b.key} value={b.key}>{b.label}</SelectItem>)}</SelectContent>
          </Select>
        )}
        <Badge variant="outline" className="border-amber-300 text-amber-700 gap-1.5">
          {activeBucket?.isCurrent ? <CalendarDays className="h-3 w-3" /> : <History className="h-3 w-3" />}
          {activeBucket?.isCurrent ? 'Periode berjalan' : isLatest ? 'Data terakhir' : 'Periode'}: {activeBucket?.label ?? '-'}
        </Badge>
        <Button size="sm" onClick={recalc} disabled={recalcing || !activeProjectId} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-600 hover:to-orange-700">
          <Calculator className={recalcing ? 'h-4 w-4 animate-spin' : 'h-4 w-4'} />
          Hitung Ulang KPI Bulan Ini
        </Button>
      </div>

      {!currentBucket && (
        <div className="rounded-lg border border-sky-200 bg-sky-50 text-sky-900 px-3 py-2 text-xs flex items-start gap-2">
          <History className="h-4 w-4 shrink-0 mt-0.5" />
          <span>
            Belum ada data KPI untuk periode berjalan ({period === 'MONTHLY' ? today.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' }) : `minggu ${fmtDate(today)}`}). Klik <b>Hitung Ulang KPI Bulan Ini</b> untuk menghitung KPI periode berjalan otomatis dari data absensi & work task — tidak perlu input manual.
          </span>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Ranking list */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Trophy className="h-4 w-4 text-amber-500" /> Ranking Karyawan</CardTitle></CardHeader>
          <CardContent className="max-h-[520px] overflow-y-auto space-y-1.5 p-2">
            {ranked.map(({ k, e }, i) => (
              <button key={k.id} onClick={() => setSelId(k.employeeId)}
                className={`w-full flex items-center gap-2.5 rounded-lg border p-2 text-left transition-colors ${selected?.k?.id === k.id ? 'border-amber-400 bg-amber-50' : 'hover:bg-slate-50'}`}>
                <span className={`w-6 text-center text-xs font-bold ${i === 0 ? 'text-amber-500' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-orange-700' : 'text-slate-300'}`}>#{i + 1}</span>
                <AseiAvatar name={e.name} color={e.avatarColor} className="h-8 w-8" />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium truncate">{e.name}</p>
                  <span className={`inline-block rounded border px-1 text-[9px] ${roleBadge(e.role)}`}>{e.role}</span>
                </div>
                <span className={`text-sm font-bold ${scoreColor(k.overallScore)}`}>{k.overallScore}</span>
              </button>
            ))}
            {ranked.length === 0 && (
              <EmptyState icon={<Trophy className="h-10 w-10" />} title="Belum ada data KPI periode ini"
                sub="Klik “Hitung Ulang KPI Bulan Ini” untuk menghitung otomatis dari data absensi & work task." />
            )}
          </CardContent>
        </Card>

        {/* Detail selected */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2 flex-wrap">
              <Target className="h-4 w-4 text-orange-500" />
              {selected.e && <AseiAvatar name={selected.e.name} color={selected.e.avatarColor} className="h-7 w-7" />}
              <span>{selected.e?.name ?? '-'}</span>
              {selected.e && <span className={`rounded border px-1.5 text-[9px] ${roleBadge(selected.e.role)}`}>{ROLE_LABEL[selected.e.role]}</span>}
              <span className="ml-auto text-lg font-bold"><span className={scoreColor(selected.k?.overallScore ?? 0)}>{selected.k?.overallScore ?? 0}</span><span className="text-xs text-slate-400 font-normal">/100</span></span>
            </CardTitle>
          </CardHeader>
          <CardContent className="grid sm:grid-cols-2 gap-4">
            <div className="h-56">
              {selected.k ? (
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData} outerRadius="75%">
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                    <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                    <Radar dataKey="score" stroke="#ea580c" fill="#f97316" fillOpacity={0.4} />
                    <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                  </RadarChart>
                </ResponsiveContainer>
              ) : <EmptyState title="Pilih karyawan" />}
            </div>
            <div className="space-y-2.5">
              {selected.k && ([
                ['Kehadiran', selected.k.attendanceScore, attPct], ['Penyelesaian Task', selected.k.taskScore, taskPct],
                ['Disiplin', selected.k.disciplineScore, selected.k.disciplineScore], ['Kualitas Kerja', selected.k.qualityScore, selected.k.qualityScore],
                ['Safety / APD', selected.k.safetyScore, selected.k.safetyScore],
              ] as const).map(([label, v, live]) => (
                <div key={label}>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-slate-500">{label}</span>
                    <span className="font-bold"><span className={scoreColor(v)}>{v}</span> <span className="text-slate-300">| live {live}%</span></span>
                  </div>
                  <SimpleBar value={v} color={scoreBg(v)} height="h-1.5" />
                </div>
              ))}
              {selected.k && <p className="text-[11px] text-slate-500 italic pt-1 border-t">{selected.k.notes}</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm">Perbandingan Skor Seluruh Karyawan — {activeBucket?.label ?? '-'}</CardTitle></CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={histData} margin={{ top: 5, right: 5, bottom: 40, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" interval={0} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
              <Bar dataKey="score" name="Skor" radius={[4, 4, 0, 0]} fill="#ea580c" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

// small wrapper to avoid importing Input twice with different names
function InputCustom({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder="Cari karyawan / jabatan..."
      className="w-full rounded-md border border-input bg-background px-8 py-2 text-sm shadow-sm outline-none focus:ring-2 focus:ring-amber-400"
    />
  )
}
