'use client'
import { useMemo, useState } from 'react'
import {
  ClipboardList, Plus, Pencil, Trash2, Search, CalendarClock,
  ChevronDown, ChevronRight, UserPlus,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { createRes, updateRes, deleteRes, ROLES, ROLE_LABEL, DISCIPLINES, DISC_LABEL, CIVIL_SUBS, ME_SUBS, EE_SUBS, TASK_STATUS, PRIORITY, roleBadge, statusBadge, fmtDate, dateInput, pct, scoreColor } from '@/lib/client'
import { useAsei, empMap } from '../store'
import { AseiAvatar, SimpleBar, EmptyState } from '../ui-bits'
import type { WorkTask } from '@/lib/types'

const EMPTY: Partial<WorkTask> = {
  title: '', description: '', discipline: 'CIVIL', subDiscipline: '', category: 'INSTALLATION',
  assigneeId: '', assignerId: '', priority: 'MEDIUM', status: 'PENDING',
  startDate: new Date().toISOString().slice(0, 10),
  dueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
  progress: 0, targetQty: 0, actualQty: 0, unit: '', location: '', notes: '',
}

export default function TasksView() {
  const { tasks, employees, refresh } = useAsei()
  const eMap = useMemo(() => empMap(employees), [employees])
  const { toast } = useToast()
  const [q, setQ] = useState('')
  const [fStatus, setFStatus] = useState('ALL')
  const [fDisc, setFDisc] = useState('ALL')
  const [viewMode, setViewMode] = useState<'LIST' | 'BY_PERSON'>('LIST')
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [form, setForm] = useState<Partial<WorkTask> | null>(null)
  const [saving, setSaving] = useState(false)

  const filtered = tasks.filter(t => {
    const okQ = !q || t.title.toLowerCase().includes(q.toLowerCase()) || t.location.toLowerCase().includes(q.toLowerCase())
    const okS = fStatus === 'ALL' || t.status === fStatus
    const okD = fDisc === 'ALL' || t.discipline === fDisc
    return okQ && okS && okD
  })

  const byStatus = (s: string) => filtered.filter(t => t.status === s)
  const overdue = (t: WorkTask) => t.status !== 'COMPLETED' && t.status !== 'CANCELLED' && t.dueDate && new Date(t.dueDate) < new Date()

  const save = async () => {
    if (!form?.title || !form?.assigneeId) return toast({ title: 'Judul & penerima task wajib', variant: 'destructive' })
    setSaving(true)
    try {
      const payload = { ...form, completedAt: form.status === 'COMPLETED' ? (form.completedAt ?? new Date().toISOString()) : null }
      if (form.id) await updateRes('tasks', form.id, payload)
      else await createRes('tasks', payload)
      toast({ title: form.id ? 'Task diperbarui' : 'Task dibuat & ditugaskan' })
      setForm(null); await refresh('tasks')
    } catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
    finally { setSaving(false) }
  }

  const remove = async (t: WorkTask) => {
    if (!confirm(`Hapus task "${t.title}"?`)) return
    try { await deleteRes('tasks', t.id); toast({ title: 'Task dihapus' }); await refresh('tasks') }
    catch (e) { toast({ title: 'Gagal', description: String(e), variant: 'destructive' }) }
  }

  const subDiscs = form?.discipline === 'CIVIL' ? CIVIL_SUBS : form?.discipline === 'MECHANICAL' ? ME_SUBS : form?.discipline === 'ELECTRICAL' ? EE_SUBS : []

  const TaskRow = ({ t }: { t: WorkTask }) => {
    const assignee = eMap[t.assigneeId], assigner = eMap[t.assignerId]
    return (
      <div className={`rounded-lg border p-3 hover:bg-slate-50/60 transition-colors ${overdue(t) ? 'border-red-200 bg-red-50/40' : 'bg-card'}`}>
        <div className="flex items-start gap-2.5">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <p className="text-sm font-medium truncate">{t.title}</p>
              <Badge variant="outline" className={`text-[9px] ${statusBadge(t.status)}`}>{TASK_STATUS[t.status]}</Badge>
              <Badge variant="outline" className={`text-[9px] ${roleBadge(t.priority)}`}>{PRIORITY[t.priority]}</Badge>
              {t.subDiscipline && <Badge variant="outline" className="text-[9px] border-slate-300 text-slate-500">{t.subDiscipline}</Badge>}
              {overdue(t) && <Badge variant="outline" className="text-[9px] border-red-300 text-red-600">Overdue</Badge>}
            </div>
            <p className="text-xs text-slate-500 mt-1 line-clamp-1">{t.description}</p>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-[11px] text-slate-500">
              {assignee && <span className="flex items-center gap-1"><AseiAvatar name={assignee.name} color={assignee.avatarColor} className="h-4 w-4" /> {assignee.name}</span>}
              {assigner && <span>dari: <b>{assigner.name}</b> ({assigner.role})</span>}
              <span className="flex items-center gap-1"><CalendarClock className="h-3 w-3" /> {fmtDate(t.startDate)} → {fmtDate(t.dueDate)}</span>
              {t.targetQty > 0 && <span>Kuantitas: {t.actualQty}/{t.targetQty} {t.unit}</span>}
              {t.location && <span>📍 {t.location}</span>}
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="text-right w-12">
              <p className={`text-sm font-bold ${scoreColor(t.progress)}`}>{t.progress}%</p>
            </div>
            <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setForm({ ...t, startDate: dateInput(t.startDate), dueDate: dateInput(t.dueDate) })} aria-label="Edit task"><Pencil className="h-3 w-3" /></Button>
            <Button size="sm" variant="outline" className="h-7 w-7 p-0 text-red-600" onClick={() => remove(t)} aria-label="Hapus task"><Trash2 className="h-3 w-3" /></Button>
          </div>
        </div>
        <SimpleBar value={t.progress} color={t.progress >= 100 ? 'bg-emerald-500' : 'bg-orange-500'} height="h-1.5" className="mt-2" />
      </div>
    )
  }

  const groupedByPerson = employees
    .map(e => ({ e, list: filtered.filter(t => t.assigneeId === e.id) }))
    .filter(x => x.list.length > 0)
    .sort((a, b) => b.list.length - a.list.length)

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          ['Total Task', filtered.length, 'text-slate-900'],
          ['Berjalan', byStatus('IN_PROGRESS').length, 'text-amber-600'],
          ['Selesai', byStatus('COMPLETED').length, 'text-emerald-600'],
          ['Terlambat', byStatus('DELAYED').length, 'text-red-600'],
          ['Overdue', filtered.filter(overdue).length, 'text-red-500'],
        ].map(([label, val, color]) => (
          <div key={String(label)} className="rounded-xl border bg-card p-3.5 shadow-sm">
            <p className="text-xs text-slate-500">{label}</p>
            <p className={`text-2xl font-bold ${color}`}>{val}</p>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
          <Input placeholder="Cari task / lokasi..." value={q} onChange={e => setQ(e.target.value)} className="pl-8" />
        </div>
        <Select value={fStatus} onValueChange={setFStatus}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Status</SelectItem>{Object.entries(TASK_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={fDisc} onValueChange={setFDisc}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="ALL">Semua Disiplin</SelectItem>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
        </Select>
        <div className="flex rounded-lg border overflow-hidden">
          <button className={`px-3 py-2 text-xs font-medium ${viewMode === 'LIST' ? 'bg-slate-900 text-white' : 'bg-white'}`} onClick={() => setViewMode('LIST')}>Daftar</button>
          <button className={`px-3 py-2 text-xs font-medium ${viewMode === 'BY_PERSON' ? 'bg-slate-900 text-white' : 'bg-white'}`} onClick={() => setViewMode('BY_PERSON')}>Per Orang</button>
        </div>
        <Button onClick={() => setForm({ ...EMPTY })} className="gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white"><Plus className="h-4 w-4" /> Tugas Baru</Button>
      </div>

      {viewMode === 'LIST' ? (
        <div className="space-y-4">
          {(['IN_PROGRESS', 'PENDING', 'COMPLETED', 'DELAYED', 'CANCELLED'] as const).filter(s => byStatus(s).length > 0).map(s => (
            <Card key={s}>
              <CardHeader className="pb-2 py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <ClipboardList className="h-4 w-4 text-orange-500" /> {TASK_STATUS[s]}
                  <span className="text-xs font-normal text-slate-400">({byStatus(s).length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {byStatus(s).map(t => <TaskRow key={t.id} t={t} />)}
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 && <EmptyState icon={<ClipboardList className="h-10 w-10" />} title="Tidak ada task" sub="Buat tugas baru dengan tombol Tugas Baru" />}
        </div>
      ) : (
        <div className="space-y-2">
          {groupedByPerson.map(({ e, list }) => {
            const open = expanded[e.id] ?? true
            const done = list.filter(t => t.status === 'COMPLETED').length
            const avg = Math.round(list.reduce((s, t) => s + t.progress, 0) / list.length)
            return (
              <Card key={e.id}>
                <button className="w-full flex items-center gap-3 p-3 text-left" onClick={() => setExpanded(x => ({ ...x, [e.id]: !open }))}>
                  {open ? <ChevronDown className="h-4 w-4 text-slate-400" /> : <ChevronRight className="h-4 w-4 text-slate-400" />}
                  <AseiAvatar name={e.name} color={e.avatarColor} className="h-8 w-8" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{e.name} <span className={`ml-1 rounded border px-1 text-[9px] ${roleBadge(e.role)}`}>{e.role}</span></p>
                    <p className="text-[11px] text-slate-500">{list.length} task • {done} selesai • rata-rata progress {avg}%</p>
                  </div>
                  <div className="w-28 hidden sm:block"><SimpleBar value={avg} color={scoreBgLocal(avg)} height="h-2" /></div>
                </button>
                {open && <CardContent className="pt-0 space-y-2 border-t">{list.map(t => <TaskRow key={t.id} t={t} />)}</CardContent>}
              </Card>
            )
          })}
          {groupedByPerson.length === 0 && <EmptyState icon={<UserPlus className="h-10 w-10" />} title="Belum ada penugasan" sub="Klik Tugas Baru untuk menugaskan pekerjaan ke bawahan" />}
        </div>
      )}

      {/* Task form */}
      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Task' : 'Buat & Tugaskan Task'}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2 space-y-1"><Label>Judul Task *</Label><Input value={form?.title ?? ''} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="cth: Welding spool SP-A-014" /></div>
            <div className="sm:col-span-2 space-y-1"><Label>Deskripsi</Label><Textarea rows={2} value={form?.description ?? ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Disiplin</Label>
              <Select value={form?.discipline ?? 'CIVIL'} onValueChange={v => setForm(f => ({ ...f, discipline: v, subDiscipline: '' }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DISCIPLINES.map(d => <SelectItem key={d} value={d}>{DISC_LABEL[d]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {subDiscs.length > 0 && (
              <div className="space-y-1"><Label>Sub-Bagian</Label>
                <Select value={form?.subDiscipline ?? ''} onValueChange={v => setForm(f => ({ ...f, subDiscipline: v }))}>
                  <SelectTrigger><SelectValue placeholder="— pilih —" /></SelectTrigger>
                  <SelectContent>{subDiscs.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1"><Label>Ditugaskan Kepada *</Label>
              <Select value={form?.assigneeId ?? ''} onValueChange={v => setForm(f => ({ ...f, assigneeId: v }))}>
                <SelectTrigger><SelectValue placeholder="— pilih pekerja —" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {employees.map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role} • {x.subDiscipline || x.discipline})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Ditugaskan Oleh</Label>
              <Select value={form?.assignerId ?? ''} onValueChange={v => setForm(f => ({ ...f, assignerId: v }))}>
                <SelectTrigger><SelectValue placeholder="— pilih atasan —" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {employees.map(x => <SelectItem key={x.id} value={x.id}>{x.name} ({x.role})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Prioritas</Label>
              <Select value={form?.priority ?? 'MEDIUM'} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(PRIORITY).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form?.status ?? 'PENDING'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(TASK_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Mulai</Label><Input type="date" value={form?.startDate ? String(form.startDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Tenggat</Label><Input type="date" value={form?.dueDate ? String(form.dueDate).slice(0, 10) : ''} onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))} /></div>
            <div className="space-y-1"><Label>Progress %</Label><Input type="number" min={0} max={100} value={form?.progress ?? 0} onChange={e => setForm(f => ({ ...f, progress: Math.max(0, Math.min(100, Number(e.target.value))) }))} /></div>
            <div className="space-y-1"><Label>Lokasi</Label><Input value={form?.location ?? ''} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="cth: Area Pump" /></div>
            <div className="space-y-1"><Label>Target Kuantitas</Label><Input type="number" value={form?.targetQty ?? 0} onChange={e => setForm(f => ({ ...f, targetQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Realisasi Kuantitas</Label><Input type="number" value={form?.actualQty ?? 0} onChange={e => setForm(f => ({ ...f, actualQty: Number(e.target.value) }))} /></div>
            <div className="space-y-1"><Label>Satuan</Label><Input value={form?.unit ?? ''} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} placeholder="ton / joint / m / pcs" /></div>
            <div className="space-y-1"><Label>Notes</Label><Input value={form?.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setForm(null)}>Batal</Button><Button onClick={save} disabled={saving} className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">{form?.id ? 'Simpan' : 'Tugaskan'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function scoreBgLocal(v: number) {
  return v >= 80 ? 'bg-emerald-500' : v >= 60 ? 'bg-amber-500' : 'bg-red-500'
}
