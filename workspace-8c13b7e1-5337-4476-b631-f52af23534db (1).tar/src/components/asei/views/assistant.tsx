'use client'
import { useEffect, useRef, useState } from 'react'
import { Bot, Send, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { api, activeProjectId } from '@/lib/client'
import { cn } from '@/lib/utils'

type Msg = { role: 'user' | 'assistant'; content: string }

const QUICK = [
  'Bagaimana progress proyek saat ini?',
  'Siapa karyawan dengan performa terbaik bulan ini?',
  'Analisis kendala delivery equipment & rekomendasinya',
  'Buat rencana kegiatan minggu depan untuk tim Mechanical',
  'Bagaimana kondisi K3 & kepatuhan APD pekerja?',
  'Siapa saja yang sering terlambat absensi?',
]

export default function AssistantView() {
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: 'assistant', content: 'Halo! Saya **ASEI AI Assistant** 👷\n\nSaya memahami seluruh data proyek aktif Anda: progress per disiplin, absensi & kepatuhan APD, work task, fabrikasi, equipment delivery, KPI karyawan, hingga laporan harian/mingguan.\n\nTanyakan apa saja — atau klik salah satu pertanyaan cepat di bawah.' },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, loading])

  const send = async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || loading) return
    const next: Msg[] = [...msgs, { role: 'user', content }]
    setMsgs(next); setInput(''); setLoading(true)
    try {
      const j = await api<{ data: { content: string } }>('/api/ai/assistant', {
        method: 'POST',
        body: JSON.stringify({ messages: next.map(m => ({ role: m.role, content: m.content })), projectId: activeProjectId() }),
      })
      setMsgs(m => [...m, { role: 'assistant', content: j.data.content }])
    } catch (e) {
      setMsgs(m => [...m, { role: 'assistant', content: `⚠️ Maaf, terjadi kesalahan: ${String(e)}` }])
    } finally { setLoading(false) }
  }

  return (
    <div className="grid lg:grid-cols-[1fr_280px] gap-4">
      <Card className="flex flex-col h-[calc(100vh-220px)] min-h-[480px]">
        <CardHeader className="pb-2 border-b">
          <CardTitle className="text-sm flex items-center gap-2">
            <div className="rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 p-1.5"><Bot className="h-4 w-4 text-white" /></div>
            ASEI AI Assistant — Project Intelligence
            <span className="ml-auto flex items-center gap-1.5 text-[10px] font-normal text-emerald-600"><span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" /> Terhubung data proyek</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto py-4 space-y-3">
          {msgs.map((m, i) => (
            <div key={i} className={cn('flex gap-2.5 max-w-[85%]', m.role === 'user' && 'ml-auto flex-row-reverse')}>
              <div className={cn('rounded-lg p-1.5 h-8 w-8 shrink-0 flex items-center justify-center', m.role === 'user' ? 'bg-slate-200 text-slate-600' : 'bg-gradient-to-br from-amber-400 to-orange-600 text-white')}>
                {m.role === 'user' ? <span className="text-xs font-bold">You</span> : <Bot className="h-4 w-4" />}
              </div>
              <div className={cn('rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-wrap shadow-sm', m.role === 'user' ? 'bg-slate-900 text-white rounded-tr-sm' : 'bg-slate-100 text-slate-800 rounded-tl-sm')}>
                {m.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-2.5 max-w-[85%]">
              <div className="rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 p-1.5 h-8 w-8 flex items-center justify-center text-white"><Bot className="h-4 w-4" /></div>
              <div className="rounded-2xl rounded-tl-sm bg-slate-100 px-4 py-3"><Loader2 className="h-4 w-4 animate-spin text-orange-500" /></div>
            </div>
          )}
          <div ref={bottomRef} />
        </CardContent>
        <div className="border-t p-3 flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
            placeholder="Tanya apa saja tentang proyek, karyawan, K3, planning..."
            className="flex-1 rounded-full border bg-white px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-amber-400"
          />
          <Button onClick={() => send()} disabled={loading || !input.trim()} className="rounded-full h-10 w-10 p-0 bg-gradient-to-r from-amber-500 to-orange-600 text-white" aria-label="Kirim">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </Card>

      <Card className="h-fit">
        <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Sparkles className="h-4 w-4 text-amber-500" /> Pertanyaan Cepat</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {QUICK.map(q => (
            <button key={q} onClick={() => send(q)} disabled={loading}
              className="w-full text-left rounded-lg border bg-white px-3 py-2 text-xs hover:border-amber-400 hover:bg-amber-50 transition-colors">
              {q}
            </button>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
