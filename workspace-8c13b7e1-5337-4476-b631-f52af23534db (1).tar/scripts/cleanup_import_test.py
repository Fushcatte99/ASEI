import sqlite3
db = sqlite3.connect('/home/z/my-project/db/custom.db')
cur = db.cursor()
cur.execute("SELECT id, name FROM Project WHERE name LIKE '%Impor%'")
rows = cur.fetchall()
for pid, name in rows:
    for t in ['DrawingMark', 'DrawingFile', 'DrawingZone', 'AiSummary', 'KpiRecord',
              'ProjectDocument', 'WeeklyReport', 'DailyReport', 'EquipmentDelivery',
              'FabricationItem', 'QuantityItem', 'WbsTask', 'WorkTask', 'Attendance', 'Employee']:
        cur.execute(f'DELETE FROM {t} WHERE projectId=?', (pid,))
    cur.execute('DELETE FROM Project WHERE id=?', (pid,))
    print('dihapus:', name)
db.commit()
cur.execute('SELECT COUNT(*) FROM Project')
print('proyek tersisa:', cur.fetchone()[0])
cur.execute('SELECT COUNT(*) FROM Employee WHERE projectId=(SELECT id FROM Project WHERE isDefault=1)')
print('karyawan proyek default:', cur.fetchone()[0], '(harus 34)')
