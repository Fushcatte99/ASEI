import sqlite3
db = sqlite3.connect('/home/z/my-project/db/custom.db')
cur = db.cursor()
cur.execute("SELECT id, name FROM Project WHERE name LIKE '%Impor%'")
rows = cur.fetchall()
print('proyek hasil impor UI:', [r[1] for r in rows])
pid = rows[0][0]
src = cur.execute("SELECT id FROM Project WHERE isDefault=1").fetchone()[0]
for t in ['Employee', 'Attendance', 'WorkTask', 'WbsTask', 'QuantityItem', 'FabricationItem',
          'EquipmentDelivery', 'DailyReport', 'WeeklyReport', 'ProjectDocument', 'KpiRecord',
          'AiSummary', 'DrawingZone', 'DrawingFile', 'DrawingMark']:
    cur.execute(f'SELECT COUNT(*) FROM {t} WHERE projectId=?', (src,))
    s = cur.fetchone()[0]
    cur.execute(f'SELECT COUNT(*) FROM {t} WHERE projectId=?', (pid,))
    i = cur.fetchone()[0]
    mark = 'OK' if s == i else 'BEDA!'
    print(f'{t:20s} sumber={s:4d} impor={i:4d} {mark}')
# cek relasi assignee task menunjuk employee proyek impor
cur.execute('SELECT COUNT(*) FROM WorkTask WHERE projectId=? AND assigneeId != "" AND assigneeId IN (SELECT id FROM Employee WHERE projectId=?)', (pid, pid))
print('task assignee valid:', cur.fetchone()[0])
cur.execute('SELECT COUNT(*) FROM WorkTask WHERE projectId=? AND assigneeId != ""', (pid,))
print('task total dgn assignee:', cur.fetchone()[0])
