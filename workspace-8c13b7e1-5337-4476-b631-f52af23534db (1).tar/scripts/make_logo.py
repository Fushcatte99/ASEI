#!/usr/bin/env python3
"""Generate ASEI logo assets from uploaded JPEG: white background -> transparent PNG."""
from PIL import Image
import numpy as np

SRC = '/home/z/my-project/upload/cropped-cropped-cropped-Logo-asei-4.jpeg'

img = Image.open(SRC).convert('RGB')
arr = np.asarray(img).astype(np.float64)

# GIMP-style "color to alpha" (white): alpha = 1 - min(r,g,b)/255
alpha = 1.0 - arr.min(axis=2) / 255.0
alpha = np.clip(alpha, 0, 1)

# Un-multiply color: C = color*alpha + 255*(1-alpha) -> color = (C - 255*(1-alpha)) / alpha
safe = np.maximum(alpha, 1e-6)[..., None]
color = (arr - (1.0 - safe) * 255.0) / safe
color = np.clip(color, 0, 255)

rgba = np.dstack([color, alpha * 255.0]).astype(np.uint8)

# Trim transparent border with small padding
a = rgba[..., 3]
ys, xs = np.where(a > 8)
if len(ys) and len(xs):
    pad = 6
    y0, y1 = max(0, ys.min() - pad), min(rgba.shape[0], ys.max() + 1 + pad)
    x0, x1 = max(0, xs.min() - pad), min(rgba.shape[1], xs.max() + 1 + pad)
    rgba = rgba[y0:y1, x0:x1]

base = Image.fromarray(rgba, 'RGBA')

# Square canvas, centered
def square(im, size):
    im = im.copy()
    im.thumbnail((size, size), Image.LANCZOS)
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.paste(im, ((size - im.width) // 2, (size - im.height) // 2), im)
    return canvas

# 1) Header/sidebar logo: TRIMMED non-square transparent PNG (no letterboxing)
base.save('/home/z/my-project/public/logo-asei.png')

# 2) Favicon (Next.js app/icon.png) + apple icon: OPAQUE white bg (visible on light & dark tab bars)
def opaque(im, size):
    im = im.copy()
    im.thumbnail((size, size), Image.LANCZOS)
    canvas = Image.new('RGB', (size, size), (255, 255, 255))
    canvas.paste(im, ((size - im.width) // 2, (size - im.height) // 2), im)
    return canvas

opaque(base, 256).save('/home/z/my-project/src/app/icon.png')
opaque(base, 180).save('/home/z/my-project/src/app/apple-icon.png')

# 3) White badge preview (simulates sidebar look)
prev = Image.new('RGB', (512, 512), (15, 23, 42))
badge = Image.new('RGB', (400, 400), (255, 255, 255))
lg = square(base, 380)
badge.paste(lg, ((400 - lg.width) // 2, (400 - lg.height) // 2), lg)
prev.paste(badge, (56, 56))
prev.save('/home/z/my-project/scripts/preview_logo_dark.png')

print('OK: logo-asei.png 512px, icon.png 256px, apple-icon.png 180px')
