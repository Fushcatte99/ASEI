import { seed } from '../src/lib/seed'

seed()
  .then((r) => { console.log('Seed selesai:', r); process.exit(0) })
  .catch((e) => { console.error(e); process.exit(1) })
