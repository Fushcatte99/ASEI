/**
 * Seed akun pengguna:
 * - 1 Master Admin : masteradmin09 / Camilan85?
 * - Akun staf untuk SETIAP pekerja: staff1..staffN / staff123 (terhubung ke Employee via employeeId)
 * Idempoten: akun yang sudah ada tidak diubah/diduplikasi.
 * Jalankan: bun scripts/seed-accounts.ts
 */
import { PrismaClient } from '@prisma/client'
import { scryptSync, randomBytes } from 'crypto'

const db = new PrismaClient()

function hashPassword(pw: string): string {
  const salt = randomBytes(16).toString('hex')
  return `${salt}:${scryptSync(pw, salt, 64).toString('hex')}`
}

const MASTER = { username: 'masteradmin09', password: 'Camilan85?', name: 'Master Admin' }
const STAFF_PASSWORD = 'staff123'

async function main() {
  // 1) Master admin
  const existingMaster = await db.userAccount.findUnique({ where: { username: MASTER.username } })
  if (!existingMaster) {
    await db.userAccount.create({
      data: { username: MASTER.username, passwordHash: hashPassword(MASTER.password), name: MASTER.name, role: 'MASTER_ADMIN' },
    })
    console.log(`[OK] Master admin dibuat: ${MASTER.username}`)
  } else {
    console.log(`[SKIP] Master admin sudah ada: ${MASTER.username}`)
  }

  // 2) Akun staf per pekerja (semua proyek), urut NIP -> staff1..staffN
  const employees = await db.employee.findMany({ orderBy: [{ projectId: 'asc' }, { nip: 'asc' }] })
  const accounts = await db.userAccount.findMany()
  const takenUsernames = new Set(accounts.map(a => a.username))
  const linkedEmployeeIds = new Set(accounts.map(a => a.employeeId).filter(Boolean))

  let created = 0
  let counter = 1
  for (const emp of employees) {
    if (emp.id in linkedEmployeeIds || linkedEmployeeIds.has(emp.id)) { counter++; continue }
    let username = `staff${counter}`
    while (takenUsernames.has(username)) { counter++; username = `staff${counter}` }
    await db.userAccount.create({
      data: {
        username,
        passwordHash: hashPassword(STAFF_PASSWORD),
        name: emp.name,
        role: 'STAFF',
        employeeId: emp.id,
      },
    })
    takenUsernames.add(username)
    linkedEmployeeIds.add(emp.id)
    console.log(`[OK] ${username} -> ${emp.nip} ${emp.name}`)
    counter++
    created++
  }
  console.log(`Selesai. Akun staf baru: ${created}. Total akun: ${await db.userAccount.count()}`)
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
