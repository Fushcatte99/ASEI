// Migration: pastikan proyek default ada + stamp projectId ke semua data lama (projectId = '')
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  let project = await prisma.project.findFirst({ where: { isDefault: true } })
  if (!project) {
    project = await prisma.project.create({
      data: {
        code: 'ASEI-EPC-001',
        name: 'EPC Skid Package & Utility Piping',
        client: 'PT. Energi Nusantara',
        location: 'Site Utama - Cilegon',
        description: 'Proyek default bawaan sistem: EPC Skid Package & Utility Piping (Civil • Mechanical • Electrical).',
        status: 'ACTIVE',
        startDate: new Date('2026-07-01'),
        endDate: new Date('2026-11-30'),
        isDefault: true,
      },
    })
    console.log('Default project created:', project.id)
  } else {
    console.log('Default project exists:', project.id)
  }
  const pid = project.id

  const tables = [
    'employee', 'attendance', 'workTask', 'wbsTask', 'quantityItem', 'fabricationItem',
    'equipmentDelivery', 'dailyReport', 'weeklyReport', 'projectDocument', 'kpiRecord', 'aiSummary',
    'drawingFile', 'drawingZone', 'drawingMark',
  ] as const

  for (const t of tables) {
    const m = prisma[t] as unknown as { updateMany: (a: { where: { projectId: string }; data: { projectId: string } }) => Promise<{ count: number }> }
    const r = await m.updateMany({ where: { projectId: '' }, data: { projectId: pid } })
    console.log(`${t}: ${r.count} rows stamped`)
  }
  console.log('Migration done.')
}

main().catch((e) => { console.error(e); process.exit(1) }).finally(() => prisma.$disconnect())
