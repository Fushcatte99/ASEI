#!/usr/bin/env python3
"""Sisipkan auth guard ke semua API route data (idempoten)."""
import re, pathlib

ROOT = pathlib.Path('/home/z/my-project/src/app/api')
IMPORT_LINE = "import { getSessionFromReq, unauthorized, forbidden } from '@/lib/auth'"

# file -> ('all' = semua handler di-guard admin, 'auth' = guard biasa)
TARGETS = {
    'data/[resource]/route.ts': 'auth',
    'data/[resource]/[id]/route.ts': 'auth',
    'dashboard/route.ts': 'auth',
    'projects/route.ts': 'auth',
    'projects/[id]/route.ts': 'auth',
    'drawings/route.ts': 'auth',
    'drawings/[id]/route.ts': 'auth',
    'drawings/[id]/file/route.ts': 'auth',
    'kpi/recalc/route.ts': 'auth',
    'ai/analyze-photo/route.ts': 'auth',
    'ai/plan/route.ts': 'auth',
    'ai/assistant/route.ts': 'auth',
    'ai/summary/route.ts': 'auth',
    'attendance/checkin/route.ts': 'auth',
    'seed/route.ts': 'admin',
}

FUNC_RE = re.compile(r'export async function (GET|POST|PATCH|DELETE|PUT)\(([^)]*)\) \{')

for rel, mode in TARGETS.items():
    path = ROOT / rel
    src = path.read_text()
    if 'getSessionFromReq' in src:
        print(f'[SKIP] {rel} (sudah ada guard)')
        continue
    lines = src.split('\n')
    # sisipkan import setelah baris import terakhir di blok atas
    last_import = max(i for i, l in enumerate(lines) if l.startswith('import '))
    lines.insert(last_import + 1, IMPORT_LINE)

    out = []
    for line in lines:
        m = FUNC_RE.search(line)
        if m:
            params = m.group(2)
            if '_req' in params:
                line = line.replace('_req', 'req')
            elif params.strip() == '':
                line = line.replace('()', '(req: NextRequest)')
            out.append(line)
            if mode == 'admin':
                out.append('  const __session = await getSessionFromReq(req)')
                out.append('  if (!__session) return unauthorized()')
                out.append("  if (__session.role !== 'MASTER_ADMIN') return forbidden()")
            else:
                out.append('  const __session = await getSessionFromReq(req)')
                out.append('  if (!__session) return unauthorized()')
        else:
            out.append(line)
    path.write_text('\n'.join(out))
    print(f'[OK] {rel} -> guard {mode}')

# pastikan file yang pakai forbidden punya NextRequest import (seed/route.ts tidak lagi)
seed = ROOT / 'seed/route.ts'
s = seed.read_text()
if 'NextRequest' not in s.split('\n')[0]:
    s = s.replace("import { NextResponse } from 'next/server'", "import { NextRequest, NextResponse } from 'next/server'", 1)
    seed.write_text(s)
    print('[FIX] seed/route.ts: import NextRequest ditambahkan')
print('Selesai.')
